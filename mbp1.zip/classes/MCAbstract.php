<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('_PS_VERSION_'))
	exit;

class MCAbstractObject extends ObjectModel {
	
	public function getBaseUrl()
	{
		$base_url = _PS_BASE_URL_.__PS_BASE_URI__;
		if(Configuration::get('PS_SSL_ENABLED') && Configuration::get('PS_SSL_ENABLED_EVERYWHERE'))
		{
			$base_url = str_replace('http://', 'https://', $base_url);
		}

		return $base_url;
	}
}
