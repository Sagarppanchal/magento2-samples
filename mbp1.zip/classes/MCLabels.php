<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('_PS_VERSION_'))
  	exit;

include_once (dirname ( __FILE__ ) . '/MCAbstract.php');
class MCLabelsObject extends MCAbstractObject {
	

}
