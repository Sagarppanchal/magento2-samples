<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('_PS_VERSION_'))
    exit;

include_once (dirname ( __FILE__ ) . '/MCAbstract.php');
class MCCategoryWidgetObject extends MCAbstractObject
{
    const SORT_BY_POSITION = 1;
    public $widget_id;
    public $widget_label;
    public $widget_code;
    public $widget_status;
    public $widget_position;

    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'mobicommerce_category_widget3',
        'primary' => 'widget_id',
        'multilang' => false,
        'fields' => array(
            'widget_label' => array(
                'type'     => self::TYPE_STRING,
                'required' => true,
                'lang'     => false
                ),
            'widget_code' => array(
                'type'     => self::TYPE_STRING,
                'required' => false
                ),
            'widget_status' => array(
                'type'     => self::TYPE_INT,
                'required' => false
                ),
            'widget_position' => array(
                'type'     => self::TYPE_INT,
                'required' => false
                )
            ));

    public static function getAll()
    {
        $db = Db::getInstance(_PS_USE_SQL_SLAVE_);
        $results = $db->executeS('
            SELECT *
            FROM ' . _DB_PREFIX_ . self::$definition['table'] . '
          ');

        return $results;
    }

    public function add($autodate = true)
    {
        return parent::add($autodate, true);
    }

    public function update($null_values = false)
    {
        if (parent::update($null_values)) {
            return $this->cleanPositions();
        }

        return false;
    }

    public function delete()
    {
        if (parent::delete())
        {
            return $this->cleanPositions();
        }

        return false;
    }

    public function saveImage($array, $thumbnail_image, $banner_image)
    {
        $_table = 'mobicommerce_category_icon3';

        $sql = 'SELECT * FROM '._DB_PREFIX_.$_table.' WHERE mci_category_id = "'.$array['categoryBox'].'"';
        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);

        if($result)
        {
            $_data = array();
            if($thumbnail_image)
            {
                $_data['mci_thumbnail'] = $thumbnail_image;
            }
            if($banner_image)
            {
                $_data['mci_banner'] = $banner_image;
            }
            
            if($_data)
            {
                Db::getInstance()->update(
                    $_table,
                    $_data,
                    "mci_category_id = '".$array['categoryBox']."'",
                    false
                    );
            }
        }
        else
        {
            $_data = array(
                'mci_category_id' => $array['categoryBox'],
                'mci_thumbnail'   => $thumbnail_image,
                'mci_banner'      => $banner_image,
                );
            Db::getInstance()->insert($_table, $_data, false, false);
        }
    } 
    
    
    public function getCatWidgetImage($category_id)
    {
        $_table = 'mobicommerce_category_icon3';
        $results = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('
            SELECT *
            FROM ' . _DB_PREFIX_ .$_table.' 
          WHERE mci_category_id ="'.$category_id.'"');

        return $results;
    }    
    
    public function getListCatWidget($category_id)
    {
        $_table = 'mobicommerce_category_widget3';
        $results = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('
            SELECT *
            FROM ' . _DB_PREFIX_ . $_table . ' 
            WHERE widget_category_id ="'.$category_id.'" ORDER BY widget_position ASC');

        return $results;
    }

    public function updateWidgetPosition($widget_ids = array())
    {
        if(!empty($widget_ids))
        {
            foreach($widget_ids as $_widget_id => $position)
            {
                $_data = array(
                    'widget_position' => (int) $position
                    );
                Db::getInstance()->update('mobicommerce_category_widget3', $_data, "widget_id = '".$_widget_id."'", false);
            }
        }
    }
}
