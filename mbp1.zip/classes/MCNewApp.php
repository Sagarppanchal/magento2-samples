<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('_PS_VERSION_'))
	exit;

include_once (dirname ( __FILE__ ) . '/MCAbstract.php');
class MCNewAppObject extends MCAbstractObject {

	const SORT_BY_POSITION = 1;
	private $module_name = 'mobicommerce3';

	public $id;
	public $app_name;
	public $app_code;
	public $app_key;
	public $app_license_key;
	public $app_storeid;
	public $app_storegroupid;
	public $created_time;
	public $update_time;
	public $app_mode;
	public $ios_url;
	public $android_url;
	public $ios_status;
	public $android_status;
	public $udid;
	public $delivery_status;
	public $addon_parameters;
	public $webapp_url;

	/**
	* @see ObjectModel::$definition
	*/
	public static $definition = array(
		'table'     => 'mobicommerce_applications3',
		'primary'   => 'id',
		'multilang' => false,
		'fields' => array(
			'app_name'    => array('type' => self::TYPE_STRING, 'required' => true,'lang' => false),
			'app_storeid' => array('type' => self::TYPE_INT,'required' => false,),
		),
	);

	public static function getAll()
	{
		$db = Db::getInstance(_PS_USE_SQL_SLAVE_);
		$results = $db->executeS('
		SELECT *
		FROM '._DB_PREFIX_.self::$definition['table'].'
		');

		return $results;
	}

	public function add($autodate = TRUE, $null_values = false)
	{
		return parent::add($autodate, TRUE);
	}

	public function update($null_values = FALSE)
	{
		if (parent::update($null_values))
		{
			return $this->cleanPositions();
		}

		return FALSE;
	}

	public function delete()
	{
		if (parent::delete())
		{
			return $this->cleanPositions();
		}

		return FALSE;
	}

	/**
	* added by yash
	*/
	public function createNewApp($data)
	{
		$groupId = '1';
		$appcode = $data['app_code'];
		$languages = Language::getLanguages();
		$this->_create_mobi_media_dir($appcode, $data['app_theme_folder_name']);
		/* add data to mobicommerce_application table */
		$_data = array(
			'app_name'         => $data['app_name'],
			'app_code'         => $appcode,
			'app_key'          => $data['app_preview_code'],
			'app_license_key'  => $data['app_license_key'],
			'app_storegroupid' => $groupId,
			'app_mode'         => 'demo',
			'created_time'     => date('Y-m-d H:i:s'),
			'android_url'      => $data['android_url'],
			'android_status'   => $data['android_status'],
			'ios_url'          => $data['ios_url'],
			'ios_status'       => $data['ios_status'],
			'udid'             => $data['udid'],
			'version_type'     => $data['version_type']
			);

		Db::getInstance()->insert('mobicommerce_applications3', $_data, false, false);
		$appid = Db::getInstance()->Insert_ID();

		$_data = serialize(array(
			'bundle_id'			   => 'com.mobicommerce.sampleapp',
			'iosappid'			   => '910995460',
			'android_appname'      => $data['app_name'],
			'android_appweburl'    => 'https://play.google.com/store/apps/details?id=com.mobicommerce.sampleapp',
			'ios_appname'          => $data['app_name'],
			'ios_appweburl'        => 'https://itunes.apple.com/in/app/mobicommerce-mobile-app/id910995460?mt=8',
			'app_description'      => 'Have you tried this app ?',
			'app_share_image'      => '',
			));

		Db::getInstance()->insert('mobicommerce_applications_settings3', array(
			'app_code'     => $appcode,
			'setting_code' => 'appinfo',
			'value'        => $_data
			));

		Db::getInstance()->insert('mobicommerce_applications_settings3', array(
			'app_code'     => $appcode,
			'setting_code' => 'push_testdevices',
			'value'        => ''
			));

		$pushValue = serialize(array(
			'active_push_notification' => 1,
			'android_key'			   => 'AIzaSyAzvHE5MnSBq_R-SmBzgCqMn1vV03Khi2M',
			'android_sender_id'        => '881306584774',
			'upload_iospem_file'       => null,
			'pem_password'             => null,
			'sandboxmode'              => 0
			));

		Db::getInstance()->insert('mobicommerce_applications_settings3', array(
			'app_code'     => $appcode,
			'setting_code' => 'push_notification',
			'value'        => $pushValue
			));

		Db::getInstance()->insert('mobicommerce_applications_settings3', array(
			'app_code'     => $appcode,
			'setting_code' => 'theme_folder_name',
			'value'        => $data['app_theme_folder_name']
			));

		Db::getInstance()->insert('mobicommerce_applications_settings3', array(
			'app_code'     => $appcode,
			'setting_code' => 'theme_android',
			'value'        => $data['theme_android']
			));

		Db::getInstance()->insert('mobicommerce_applications_settings3', array(
			'app_code'     => $appcode,
			'setting_code' => 'theme_ios',
			'value'        => $data['theme_ios']
			));

		$cms_contents = array(
			"contact_information" => array(
				"company_name"    => "Your Company Name",
				"company_address" => "Your company addresss here",
				"phone_number"    => "+0-000-000-0000",
				"email_address"   => "mail@yourdomain.com",
                "menu_icon"       => "",
				"latitude"        => "20.5937",
				"longitude"       => "78.9629",
				"zoom_level"      => "8",
				"pin_color"       => "000",
				),
			"social_media" => array(
				"facebook" => array(
					"checked" => "1",
					"url"     => "https://www.facebook.com/mobi.commerce.platform"
					),
				"twitter" => array(
					"checked" => "1",
					"url"     => "https://twitter.com/mobicommerceapp"
					),
				"linkedin" => array(
					"checked" => "0",
					"url"     => ""
					),
				"googleplus" => array(
					"checked" => "0",
					"url"     => ""
					),
				"youtube" => array(
					"checked" => "0",
					"url"     => ""
					),
				"pinterest" => array(
					"checked" => "0",
					"url"     => ""
					),
				"blog" => array(
					"checked" => "0",
					"url"     => ""
					),
				),
			"cms_pages" => array(),
			);

		$_data = array(
			'app_code'     => $appcode,
			'setting_code' => 'cms_settings',
			'value'        => serialize($cms_contents)
			);

		foreach($languages as $_language)
		{
			$_data['storeid'] = $_language['id_lang'];
			Db::getInstance()->insert('mobicommerce_applications_settings3', $_data);
		}

		$googleanalytics = serialize(array(
			'android' => array(
				'status' => '0',
				'code'   => ''
				),
			'ios' => array(
				'status' => '0',
				'code'   => ''
				),
			));

		Db::getInstance()->insert('mobicommerce_applications_settings3', array(
			'app_code'     => $appcode,
			'setting_code' => 'googleanalytics',
			'value'        => $googleanalytics
			));

		$root = Category::getRootCategory();
		$root_category_id = $root->id_category;
		$categories = array();
		$advanceSettingsCategories = array();
		$rows = Category::getCategories(Context::getContext()->cookie->id_lang);
		foreach ($rows as $row)
		{
			foreach ($row as $item)
			{
				if($item['infos']['id_parent'] == $root_category_id)
				{
					$categories[$item['infos']['id_category']] = 'on';
					$advanceSettingsCategories[] = $item['infos']['id_category'];
				}
			}
		}

		foreach($languages as $_language)
		{
			$_data = array(
				'app_code'     => $appcode,
				'setting_code' => 'homepage_categories',
				'value'        => serialize(array_flip($advanceSettingsCategories))
				);
			$_data['storeid'] = $_language['id_lang'];
			Db::getInstance()->insert('mobicommerce_applications_settings3', $_data);
		}

		$_data = array(
			'app_code'     => $appcode,
			'setting_code' => 'advance_settings',
			'value'        => serialize(array(
				"image"      => array(
					"category_ratio_width"  => "1",
					"category_ratio_height" => "1",
					"product_ratio_width"   => "1",
					"product_ratio_height"  => "1",
					),
				"miscellaneous" => array(
					"enable_rating"                => "0",
					"enable_wishlist"              => Module::isInstalled('blockwishlist') ? "1" : "0",
					"enable_socialsharing"         => "1",
					"enable_discountcoupon"        => "1",
					"enable_productsearch"         => "1",
					"enable_qrcodescan"			   => "0",
					"enable_nfcscan"			   => "0",
					"enable_guestcheckout"         => "0",
					"enable_estimatedshippingcost" => "0",
					"enable_categoryicon"          => "0",
					"enable_categorywidget"        => "0",
					"enable_sociallogin"           => "1",
					"show_push_in_preferences"     => "0",
					"show_max_subcategory"         => "3",
					),
				"productlist" => array(
					"showname"                => "1",
					"showprice"               => "1",
					"showrating"              => "1",
					"enablesort"              => "1",
					"default_sorting"         => "popularity",
					"default_view"            => "list",
					"persistent_view"		  => "1",
					"enablechangeproductview" => "1",
					"enablefilter"            => "1",
					"enablemasonry"           => "1",
					),
				"productdetail" => array(
					"enable_productzoom"        => "1",
					"enable_endless_slider"     => "0",
					"enable_youmaylike_slider"  => "1",
					"show_max_related_products" => "4",
					"showattribute"             => array(),
					"showattribute_popup"       => array(),
					"show_max_attributes"       => "3",
					)
				))
			);
		
		Db::getInstance()->insert('mobicommerce_applications_settings3', $_data);

		$this->setDefaultWidgetData($appcode, $data['version_type'], $data['app_theme_folder_name'], $categories);
		return $appid;
	}

	public function setDefaultWidgetData($appcode, $version_type, $theme, $categories)
	{
		$base_url = $this->getBaseUrl();
		//professional
		if($version_type == '001')
		{
			@copy(_PS_MODULE_DIR_. $this->module_name.'/views/img/mobi_assets/v/3/theme_files/'.$theme.'/enterprise/banners/banner1.jpg', _PS_MODULE_DIR_. $this->module_name.'/media/mobi_commerce/'.$appcode.'/home_banners/banner1.jpg');
			@copy(_PS_MODULE_DIR_. $this->module_name.'/views/img/mobi_assets/v/3/theme_files/'.$theme.'/enterprise/banners/banner2.jpg', _PS_MODULE_DIR_. $this->module_name.'/media/mobi_commerce/'.$appcode.'/home_banners/banner2.jpg');
			@copy(_PS_MODULE_DIR_. $this->module_name.'/views/img/mobi_assets/v/3/theme_files/'.$theme.'/enterprise/banners/banner3.jpg', _PS_MODULE_DIR_. $this->module_name.'/media/mobi_commerce/'.$appcode.'/home_banners/banner3.jpg');

			$widgets = array(
				// image banner
				array(
					'widget_label'    => 'Top Banners',
					'widget_code'     => 'widget_image_slider',
					'widget_status'   => '1',
					'widget_position' => '1',
					'widget_data'     => array(
						'title'                    => '',
						'title_align'              => 'center',
						'slider_type'			   => 'sideview',
						'slide_auto_play'		   => '0',
						'slide_auto_play_interval' => '5000',
						'banners'                  => array(
							array(
								'banner_options'  => '1',
								'banner_url'      => $base_url.'modules/'.$this->module_name.'/media/mobi_commerce/'.$appcode.'/home_banners/banner1.jpg',
								'banner_position' => '1',
								'banner_status'   => '1',
								'banner_link'     => null,
								'banner_delete'   => '0'
								),
							array(
								'banner_options'  => '2',
								'banner_url'      => $base_url.'modules/'.$this->module_name.'/media/mobi_commerce/'.$appcode.'/home_banners/banner2.jpg',
								'banner_position' => '2',
								'banner_status'   => '1',
								'banner_link'     => null,
								'banner_delete'   => '0'
								),
							array(
								'banner_options'  => '2',
								'banner_url'      => $base_url.'modules/'.$this->module_name.'/media/mobi_commerce/'.$appcode.'/home_banners/banner3.jpg',
								'banner_position' => '3',
								'banner_status'   => '1',
								'banner_link'     => null,
								'banner_delete'   => '0'
								),
							)
						)
					),
				// category widget
				array(
					'widget_label'    => 'Shop by Category',
					'widget_code'     => 'widget_category',
					'widget_status'   => '1',
					'widget_position' => '2',
					'widget_data'     => array(
						'title'                      => 'SHOP BY CATEGORY',
						'title_align'                => 'left',
						'cat_layout'                 => 'list',
						'category_force_product_nav' => '0',
						'show_thumbnail'             => '0',
						'show_name'                  => '1',
						'categories'                 => null,
						)
					),
				// product slider widget
				array(
					'widget_label'    => 'New Arrivals',
					'widget_code'     => 'widget_product_slider',
					'widget_status'   => '1',
					'widget_position' => '3',
					'widget_data'     => array(
						'title'              => 'NEW ARRIVALS',
						//'title_align'        => 'left',
						'type'               => 'grid',
						'maxItems'			 => 4,
						'limit'				 => 10,
						'show_name'          => '1',
						'show_price'         => '1',
						'show_review'        => '1',
						'productslider_type' => 'newarrivals',
						'products'           => Tools::jsonEncode(array()),
						)
					),
				// product slider widget
				array(
					'widget_label'    => 'Best Selling',
					'widget_code'     => 'widget_product_slider',
					'widget_status'   => '1',
					'widget_position' => '4',
					'widget_data'     => array(
						'title'              => 'BEST SELLING',
						//'title_align'        => 'left',
						'type'               => 'list',
						'maxItems'			 => 3,
						'limit'				 => 15,
						'show_name'          => '1',
						'show_price'         => '1',
						'show_review'        => '1',
						'productslider_type' => 'bestseller',
						'products'           => Tools::jsonEncode(array()),
						)
					),
				// product slider widget
				array(
					'widget_label'    => 'Hot Deals',
					'widget_code'     => 'widget_product_slider',
					'widget_status'   => '1',
					'widget_position' => '5',
					'widget_data'     => array(
						'title'              => 'HOT DEALS',
						//'title_align'        => 'left',
						'type'               => 'full',
						'maxItems'			 => 2,
						'limit'				 => 10,
						'show_name'          => '1',
						'show_price'         => '1',
						'show_review'        => '1',
						'productslider_type' => 'selected',
						'products'           => Tools::jsonEncode(array()),
						)
					),
				// product slider widget
				array(
					'widget_label'    => 'Recently viewed Products',
					'widget_code'     => 'widget_product_slider',
					'widget_status'   => '1',
					'widget_position' => '6',
					'widget_data'     => array(
						'title'              => 'RECENTLY VIEWED',
						//'title_align'        => 'left',
						'type'               => 'grid',
						'maxItems'			 => 4,
						'limit'				 => 10,
						'show_name'          => '1',
						'show_price'         => '1',
						'show_review'        => '1',
						'productslider_type' => 'productviewed',
						'products'           => Tools::jsonEncode(array()),
						)
					),
			);
		}
		// enterprise
		else if($version_type == '002')
		{
			@copy(_PS_MODULE_DIR_. $this->module_name.'/views/img/mobi_assets/v/3/theme_files/'.$theme.'/enterprise/banners/banner1.jpg', _PS_MODULE_DIR_. $this->module_name.'/media/mobi_commerce/'.$appcode.'/home_banners/banner1.jpg');
			@copy(_PS_MODULE_DIR_. $this->module_name.'/views/img/mobi_assets/v/3/theme_files/'.$theme.'/enterprise/banners/banner2.jpg', _PS_MODULE_DIR_. $this->module_name.'/media/mobi_commerce/'.$appcode.'/home_banners/banner2.jpg');
			@copy(_PS_MODULE_DIR_. $this->module_name.'/views/img/mobi_assets/v/3/theme_files/'.$theme.'/enterprise/banners/banner3.jpg', _PS_MODULE_DIR_. $this->module_name.'/media/mobi_commerce/'.$appcode.'/home_banners/banner3.jpg');

			$promotional_images = array(
				'promo1.jpg',
				'promo2.jpg',
				'promo3.jpg',
				'promo4.jpg',
				'promo5.jpg',
				'promo6.jpg',
				);

			foreach($promotional_images as $_image) {
				@copy(_PS_MODULE_DIR_. $this->module_name.'/views/img/mobi_assets/v/3/theme_files/'.$theme.'/enterprise/image/'.$_image, _PS_MODULE_DIR_. $this->module_name.'/media/mobi_commerce/widget_image/'.$appcode.$_image);
			}

			$widgets = array(
				// image banner
				array(
					'widget_label'    => 'Top Banners',
					'widget_code'     => 'widget_image_slider',
					'widget_status'   => '1',
					'widget_position' => '1',
					'widget_data'     => array(
						'title'                    => '',
						'title_align'              => 'center',
						'slider_type'			   => 'sideview',
						'banners'                  => array(
							array(
								'banner_options'  => '1',
								'banner_url'      => $base_url.'modules/'.$this->module_name.'/media/mobi_commerce/'.$appcode.'/home_banners/banner1.jpg',
								'banner_position' => '1',
								'banner_status'   => '1',
								'banner_link'     => null,
								'banner_delete'   => '0'
								),
							array(
								'banner_options'  => '2',
								'banner_url'      => $base_url.'modules/'.$this->module_name.'/media/mobi_commerce/'.$appcode.'/home_banners/banner2.jpg',
								'banner_position' => '2',
								'banner_status'   => '1',
								'banner_link'     => null,
								'banner_delete'   => '0'
								),
							array(
								'banner_options'  => '2',
								'banner_url'      => $base_url.'modules/'.$this->module_name.'/media/mobi_commerce/'.$appcode.'/home_banners/banner3.jpg',
								'banner_position' => '3',
								'banner_status'   => '1',
								'banner_link'     => null,
								'banner_delete'   => '0'
								),
							)
						)
					),
				// category widget
				array(
					'widget_label'    => 'Shop by Category',
					'widget_code'     => 'widget_category',
					'widget_status'   => '1',
					'widget_position' => '2',
					'widget_data'     => array(
						'title'                      => 'SHOP BY CATEGORY',
						'title_align'                => 'left',
						'cat_layout'                 => 'list',
						'category_force_product_nav' => '0',
						'show_thumbnail'             => '0',
						'show_name'                  => '1',
						'categories'                 => null,
						)
					),
				// product slider widget
				array(
					'widget_label'    => 'New Arrivals',
					'widget_code'     => 'widget_product_slider',
					'widget_status'   => '1',
					'widget_position' => '3',
					'widget_data'     => array(
						'title'              => 'NEW ARRIVALS',
						//'title_align'        => 'left',
						'type'               => 'grid',
						'maxItems'			 => 4,
						'limit'				 => 10,
						'show_name'          => '1',
						'show_price'         => '1',
						'show_review'        => '1',
						'productslider_type' => 'newarrivals',
						'products'           => Tools::jsonEncode(array()),
						)
					),
				// product slider widget
				array(
					'widget_label'    => 'Hot Deals',
					'widget_code'     => 'widget_product_slider',
					'widget_status'   => '1',
					'widget_position' => '4',
					'widget_data'     => array(
						'title'              => 'HOT DEALS',
						//'title_align'        => 'left',
						'type'               => 'full',
						'maxItems'			 => 2,
						'limit'				 => 10,
						'show_name'          => '1',
						'show_price'         => '1',
						'show_review'        => '1',
						'productslider_type' => 'selected',
						'products'           => Tools::jsonEncode(array()),
						)
					),
				// image widget
				array(
					'widget_label'    => 'Promotional Banner 1',
					'widget_code'     => 'widget_image',
					'widget_status'   => '1',
					'widget_position' => '5',
					'widget_data'     => array(
						'title'        => '',
						'title_align'  => 'center',
						'mapcode' => '<img src="'.$base_url.'modules/'.$this->module_name.'/media/mobi_commerce/widget_image/'.$appcode.'promo1.jpg" alt="" usemap="#map'.$appcode.'promo1.jpg"><map id="map'.$appcode.'promo1.jpg" name="map'.$appcode.'promo1.jpg"><area shape="rect" coords="2,2,494,495" title="undefined" alt="undefined" href="__CATEGORY_LINK__" target="_self"><area shape="rect" coords="500,4,999,245" title="undefined" alt="undefined" href="" target="_self"><area shape="rect" coords="504,254,1004,495" title="undefined" alt="undefined" href="__CATEGORY_LINK__" target="_self"><area shape="rect" coords="1002,493,1003,494" alt="Image HTML map generator" title="HTML Map creator" href="" target="_self"></map>',
						'widget_image' => $base_url.'modules/'.$this->module_name.'/media/mobi_commerce/widget_image/'.$appcode.'promo1.jpg',
						)
					),
				// product slider widget
				array(
					'widget_label'    => 'Trending now',
					'widget_code'     => 'widget_product_slider',
					'widget_status'   => '1',
					'widget_position' => '6',
					'widget_data'     => array(
						'title'              => 'TRENDING NOW',
						//'title_align'        => 'left',
						'type'               => 'slider',
						'maxItems'			 => 10,
						'limit'				 => 20,
						'show_name'          => '1',
						'show_price'         => '1',
						'show_review'        => '1',
						'productslider_type' => 'selected',
						'products'           => Tools::jsonEncode(array()),
						)
					),
				// image widget
				array(
					'widget_label'    => 'Promo 2',
					'widget_code'     => 'widget_image',
					'widget_status'   => '1',
					'widget_position' => '7',
					'widget_data'     => array(
						'title'        => '',
						'title_align'  => 'center',
						'mapcode'	   => '<img src="'.$base_url.'modules/'.$this->module_name.'/media/mobi_commerce/widget_image/'.$appcode.'promo2.jpg" alt="">',
						'widget_image' => $base_url.'modules/'.$this->module_name.'/media/mobi_commerce/widget_image/'.$appcode.'promo2.jpg',
						)
					),
				// image widget
				array(
					'widget_label'    => 'Promo 3',
					'widget_code'     => 'widget_image',
					'widget_status'   => '1',
					'widget_position' => '8',
					'widget_data'     => array(
						'title'        => '',
						'title_align'  => 'center',
						'mapcode'  	   => '<img src="'.$base_url.'modules/'.$this->module_name.'/media/mobi_commerce/widget_image/'.$appcode.'promo3.jpg" alt="" usemap="#map'.$appcode.'promo3.jpg"><map id="map'.$appcode.'promo3.jpg" name="map'.$appcode.'promo3.jpg"><area shape="rect" coords="8,11,1590,636" title="undefined" alt="undefined" href="__CATEGORY_LINK__" target="_self"><area shape="rect" coords="1598,648,1599,649" alt="Image HTML map generator" title="HTML Map creator" href="" target="_self"></map>',
						'widget_image' => $base_url.'modules/'.$this->module_name.'/media/mobi_commerce/widget_image/'.$appcode.'promo3.jpg',
						)
					),
				// image widget
				array(
					'widget_label'    => 'Promo 4',
					'widget_code'     => 'widget_image',
					'widget_status'   => '1',
					'widget_position' => '9',
					'widget_data'     => array(
						'title'        => '',
						'title_align'  => 'center',
						'mapcode'	   => '<img src="'.$base_url.'modules/'.$this->module_name.'/media/mobi_commerce/widget_image/'.$appcode.'promo4.jpg" alt="">',
						'widget_image' => $base_url.'modules/'.$this->module_name.'/media/mobi_commerce/widget_image/'.$appcode.'promo4.jpg',
						)
					),
				// image widget
				array(
					'widget_label'    => 'Promo 5',
					'widget_code'     => 'widget_image',
					'widget_status'   => '1',
					'widget_position' => '10',
					'widget_data'     => array(
						'title'        => '',
						'title_align'  => 'center',
						'mapcode'	   => '<img src="'.$base_url.'modules/'.$this->module_name.'/media/mobi_commerce/widget_image/'.$appcode.'promo5.jpg" alt="">',
						'widget_image' => $base_url.'modules/'.$this->module_name.'/media/mobi_commerce/widget_image/'.$appcode.'promo5.jpg',
						)
					),
				// product slider widget
				array(
					'widget_label'    => 'Best Selling',
					'widget_code'     => 'widget_product_slider',
					'widget_status'   => '1',
					'widget_position' => '11',
					'widget_data'     => array(
						'title'              => 'BEST SELLING',
						//'title_align'        => 'left',
						'type'               => 'list',
						'maxItems'			 => 3,
						'limit'				 => 15,
						'show_name'          => '1',
						'show_price'         => '1',
						'show_review'        => '1',
						'productslider_type' => 'bestseller',
						'products'           => Tools::jsonEncode(array()),
						)
					),
				// image widget
				array(
					'widget_label'    => 'Promo 6',
					'widget_code'     => 'widget_image',
					'widget_status'   => '1',
					'widget_position' => '12',
					'widget_data'     => array(
						'title'        => '',
						'title_align'  => 'center',
						'mapcode'	   => '<img src="'.$base_url.'modules/'.$this->module_name.'/media/mobi_commerce/widget_image/'.$appcode.'promo6.jpg" alt="">',
						'widget_image' => $base_url.'modules/'.$this->module_name.'/media/mobi_commerce/widget_image/'.$appcode.'promo6.jpg',
						)
					),
				// product slider widget
				array(
					'widget_label'    => 'Recently viewed Products',
					'widget_code'     => 'widget_product_slider',
					'widget_status'   => '1',
					'widget_position' => '13',
					'widget_data'     => array(
						'title'              => 'RECENTLY VIEWED',
						//'title_align'        => 'left',
						'type'               => 'grid',
						'maxItems'			 => 4,
						'limit'				 => 10,
						'show_name'          => '1',
						'show_price'         => '1',
						'show_review'        => '1',
						'productslider_type' => 'productviewed',
						'products'           => Tools::jsonEncode(array()),
						)
					),
			);
		}
		$languages = Language::getLanguages();
		foreach($languages as $_langugae)
		{
			foreach($widgets as $value)
			{
				$_widget = $value;
				$_widget['widget_app_code'] = $appcode;
				$_widget['widget_store_id'] = $_langugae['id_lang'];
				//as category should be store group wise
				if($_widget['widget_code'] == 'widget_image_slider') {
					foreach ($_widget['widget_data']['banners'] as $_banner_key => $_banner_value) {
						$_widget['widget_data']['banners'][$_banner_key]['banner_link'] = $this->getBannerLink($categories);
					}
				}

				if($_widget['widget_code'] == 'widget_category')
				{
					$_widget['widget_data']['categories'] = Tools::jsonEncode($categories);
				}
				
				if($_widget['widget_code'] == 'widget_image')
				{
					$_widget['widget_data']['mapcode'] = str_replace(
						'__CATEGORY_LINK__',
						$this->getBannerLink($categories),
						$_widget['widget_data']['mapcode']
						);
				}

				if($_widget['widget_code'] == 'widget_product_slider')
				{
					if($_widget['widget_data']['productslider_type'] == 'selected'){
						$_products = $this->_getRandomProducts(10);
						$_widget['widget_data']['products'] = Tools::jsonEncode($_products);
					}
				}
				$_widget['widget_data'] = serialize($_widget['widget_data']);
				Db::getInstance()->insert('mobicommerce_widget3', $_widget, false, false);
			}
		}
	}

	protected function getBannerLink($categories)
	{
		if(!empty($categories))
		{
			return 'category||'.array_rand($categories);
		}
		return '';
	}

	protected function _create_mobi_media_dir($app_code = null, $app_theme_folder_name = null)
	{
		$base_dir = _PS_ROOT_DIR_.'/modules/'.$this->module_name;
		$media_dir = $base_dir.'/media';

		if(!(is_dir($media_dir) && file_exists($media_dir)))
			mkdir($media_dir, 0777, true);

		if(!(is_dir($media_dir.'/mobi_commerce') && file_exists($media_dir.'/mobi_commerce')))
		{
			mkdir($media_dir.'/mobi_commerce', 0777, true);
		}

		if(!(is_dir($media_dir.'/mobi_commerce/widget_image') && file_exists($media_dir.'/mobi_commerce/widget_image')))
		{
			mkdir($media_dir.'/mobi_commerce/widget_image', 0777, true);
		}

		if(!(is_dir($media_dir.'/mobi_commerce/'.$app_code) && file_exists($media_dir.'/mobi_commerce/'.$app_code)))
		{
			mkdir($media_dir.'/mobi_commerce/'.$app_code, 0777, true);
		}

		if(!(is_dir($media_dir.'/mobi_commerce/'.$app_code.'/home_banners') && file_exists($media_dir.'/mobi_commerce/'.$app_code.'/home_banners')))
		{
			mkdir($media_dir.'/mobi_commerce/'.$app_code.'/home_banners', 0777, true);
		}

		if(!(is_dir($media_dir.'/mobi_commerce/'.$app_code.'/appinfo') && file_exists($media_dir.'/mobi_commerce/'.$app_code.'/appinfo')))
		{
			mkdir($media_dir.'/mobi_commerce/'.$app_code.'/appinfo', 0777, true);
		}

		if(!(is_dir($media_dir.'/mobi_commerce/'.$app_code.'/certificates') && file_exists($media_dir.'/mobi_commerce/'.$app_code.'/certificates')))
		{
			mkdir($media_dir.'/mobi_commerce/'.$app_code.'/certificates', 0777, true);
		}

		if(!(is_dir($media_dir.'/mobi_commerce/'.$app_code.'/personalizer') && file_exists($media_dir.'/mobi_commerce/'.$app_code.'/personalizer')))
		{
			mkdir($media_dir.'/mobi_commerce/'.$app_code.'/personalizer', 0777, true);

			if(!empty($app_theme_folder_name))
			{
				@copy($base_dir.'/views/img/mobi_assets/v/3/theme_files/'.$app_theme_folder_name.'/personalizer/personalizer.xml', $media_dir.'/mobi_commerce/'.$app_code.'/personalizer/personalizer.xml');
				@copy($base_dir.'/views/css/mobi_assets/v/3/theme_files/'.$app_theme_folder_name.'/personalizer/personalizer.css', $media_dir.'/mobi_commerce/'.$app_code.'/personalizer/personalizer.css');
			}
		}
	}

	public function _getRandomProducts($limit=10)
	{
		$category = new Category(Context::getContext()->shop->getCategory(), (int)Context::getContext()->language->id);
        $products = $category->getProducts((int)Context::getContext()->language->id, 1, $limit);
        $randomProducts = array();
        if($products)
        {
        	foreach($products as $_product)
        	{
        		$randomProducts[$_product['id_product']] = '0';
        	}
        }
        return $randomProducts;
	}
}