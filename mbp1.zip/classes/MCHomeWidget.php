<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

include_once (dirname ( __FILE__ ) . '/MCAbstract.php');
class MCHomeWidgetObject extends MCAbstractObject
{
	const SORT_BY_POSITION = 1;
	public $widget_id;
	/**
	* @see ObjectModel::$definition
	*/
	public static $definition = array(
		'table'           => 'mobicommerce_widget',
		'primary'         => 'id',
		'multilang'       => false,
		'fields'          => array(
			'widget_position' => array('type' => self::TYPE_STRING, 'required' => false),
			'widget_label'    => array('type' => self::TYPE_STRING,'required' => true),
			'widget_code'     => array('type' => self::TYPE_STRING,'required' => false)
			)
		);

	public static function getAll()
	{
		$db = Db::getInstance(_PS_USE_SQL_SLAVE_);
		$results = $db->executeS('
			SELECT *
			FROM '._DB_PREFIX_.self::$definition['table'].'
			');

		return $results;
	}

	public function add($autodate = TRUE)
	{
		return parent::add($autodate, TRUE);
	}

	public function update($null_values = FALSE)
	{
		if (parent::update($null_values))
		{
			return $this->cleanPositions();
		}

		return FALSE;
	}

	public function delete()
	{
		if (parent::delete()) {
			return $this->cleanPositions();
		}

		return FALSE;
	}
}
