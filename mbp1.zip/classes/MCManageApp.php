<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('_PS_VERSION_'))
	exit;

include_once (dirname ( __FILE__ ) . '/MCAbstract.php');
class MCManageAppObject extends MCAbstractObject
{
	const SORT_BY_POSITION = 1;

	public $id;
	public $app_name;
	public $app_code;
	public $app_key;
	public $app_logo;
	public $app_license_key;
	public $app_storeid;
	public $app_storegroupid;
	public $created_time;
	public $update_time;
	public $app_mode;
	public $ios_url;
	public $android_url;
	public $ios_status;
	public $android_status;
	public $udid;
	public $delivery_status;
	public $addon_parameters;
	public $webapp_url;
	public $version_type;

	/**
	* @see ObjectModel::$definition
	*/
	public static $definition = array(
		'table'       => 'mobicommerce_applications3',
		'primary'     => 'id',
		'multilang'   => false,
		'fields'      => array(
			'app_name'    => array('type' => self::TYPE_STRING, 'required' => true,'lang' => true),
			'app_storeid' => array('type' => self::TYPE_INT,'required' => false,),
			'app_logo'    => array('type' => self::TYPE_STRING,'required' => false,),
			));

	public function changePosition($widget_id, $position, $type)
	{
		if($type=="widget_category") $_table = "mobicommerce_category_widget3";
		else if($type=="widget_home") $_table = "mobicommerce_widget3";
		
		$_data = array(
			'widget_position' => $position
			);

		Db::getInstance()->update(
			$_table,
			$_data,
			"widget_id = '".$widget_id."'",
			false
			);

		return true;
	}

	public function updateWidgetPosition($widget_ids = array())
	{
		if(!empty($widget_ids)){
			foreach($widget_ids as $_widget_id => $position){
				$_data = array(
					'widget_position' => (int) $position
					);
				Db::getInstance()->update(
					'mobicommerce_widget3',
					$_data,
					"widget_id = '".$_widget_id."'",
					false
					);
			}
		}
	}

	public function addCategoryWidget($data,$object)
	{
		$widgetData = $data['widget']['widget_data'];
		if(isset($data['categoryBox']) && !empty($data['categoryBox'])){
			$categories = array();
			$sort = 1;
			foreach($data['categoryBox'] as $_category){
				$categories[$_category] = $sort;
				$sort++;
			}
			$widgetData['categories'] = Tools::jsonEncode($categories);
		}

		if(isset($widgetData['banners'])){
			if(!empty($widgetData['banners'])){
				$sort_pos = array();
				$sort_secondpos = array();
				foreach($widgetData['banners'] as $_key => $_banner){
					if(isset($_banner['banner_status'])){
						$widgetData['banners'][$_key]['banner_status'] = '1';
					}
					
					$sort_pos[] = $_banner['banner_position'];
					$sort_secondpos[] = $_key;
				}
				array_multisort($sort_pos, SORT_ASC, $sort_secondpos, SORT_ASC, $widgetData['banners']);
			}
		}

		if(isset($widgetData['products'])){
			$widgetData['products'] = Tools::unSerialize($widgetData['products']);
		}

		$widgetDataEncoded = serialize($widgetData);
		$_table = "mobicommerce_widget3";
		$_data = array(
			'widget_store_id' => $data['widget']['lang_id'],
			'widget_label'    => $data['widget']['name'],
			'widget_code'     => $data['widget']['selected_widget'],
			'widget_status'   => $data['widget']['enable'],
			'widget_position' => '0',
			'widget_data'     => $widgetDataEncoded
			);
		
		if(isset($data['widget']['widget_category_id']) && !empty($data['widget']['widget_category_id']))
		{
			$_table = "mobicommerce_category_widget3";
			$_data['widget_category_id'] = $data['widget']['widget_category_id'];
		}
		else
		{
			$_data['widget_app_code'] = $object->app_code;
		}

		Db::getInstance()->insert($_table, $_data, false, false);
		return true;
	}

	public function updateCategoryWidget($data)
	{
		$widgetData = $data['widget']['widget_data'];
		if(isset($data['categoryBox']) && !empty($data['categoryBox'])){
			$categories = array();
			$sort = 1;
			foreach($data['categoryBox'] as $_category){
				$categories[$_category] = $sort;
				$sort++;
			}
			$widgetData['categories'] = Tools::jsonEncode($categories);
		}

		if(isset($widgetData['banners'])){
			if(!empty($widgetData['banners'])){
				$sort_pos = array();
				$sort_secondpos = array();
				foreach($widgetData['banners'] as $_key => $_banner){
					if(isset($_banner['banner_status'])){
						$widgetData['banners'][$_key]['banner_status'] = '1';
					}
					else{
						$widgetData['banners'][$_key]['banner_status'] = '0';
					}
					$sort_pos[] = $_banner['banner_position'];
					$sort_secondpos[] = $_key;
				}
				array_multisort($sort_pos, SORT_ASC, $sort_secondpos, SORT_ASC, $widgetData['banners']);
			}
		}
		
		if(isset($widgetData['products'])){
			$widgetData['products'] = Tools::unSerialize($widgetData['products']);
		}
		
		$_data = array(
			'widget_label'  => $data['widget']['name'],
			'widget_code'   => $data['widgetCode'],
			'widget_status' => $data['widget']['enable'],
			'widget_data'   => serialize($widgetData)
			);

		if(isset($data['widget']['widget_category_id']) && !empty($data['widget']['widget_category_id'])) {
			$_table = "mobicommerce_category_widget3";
		}
		else {
			$_table = "mobicommerce_widget3";
		}

		Db::getInstance()->update($_table, $_data, "widget_id = '".$data['widget_id']."'", false);
		return true;
	}

	public function addProductWidget($data, $object)
	{
		$widgetData = $data['widget']['widget_data'];

		$_data = array(
			'widget_label'       => $data['widget']['name'],
			'widget_code'        => $data['widget']['selected_widget'],
			'widget_status'      => $data['widget']['enable'],
			'widget_position'    => '0',
			'widget_data'        => serialize($widgetData)
			);

		$_table = "mobicommerce_widget3";
		if(isset($data['widget']['widget_category_id']) && !empty($data['widget']['widget_category_id']))
		{
			$_table = "mobicommerce_category_widget3";

			$_data['lang_id'] = $data['widget']['lang_id'];
			$_data['widget_category_id'] = $data['widget']['widget_category_id'];  
		}
		else
		{
			$_data['widget_app_code'] = $object->app_code;
			$_data['widget_store_id'] = $data['languageSelected'];
		}

		Db::getInstance()->insert($_table, $_data, false, false);
		return true;
	}

	public function getWidgetList($data, $app_code)
	{
		$_table = 'mobicommerce_widget3';
		$lang_id = $data['lang_id'];
		if(empty($lang_id)){
			$context = Context::getContext();
        	$lang_id = $context->cookie->id_lang;
		}
		$sql = '
			SELECT *
			FROM `'._DB_PREFIX_.$_table.'`
			WHERE `widget_app_code` = "'.$app_code.'" and widget_store_id="'.$lang_id.'" ORDER BY widget_position ASC	
			';
		return Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
	}

	public function getWidgetData($widget_id, $cat="")
	{
		$_table = "mobicommerce_widget3";
		if(isset($cat) && !empty($cat))
		{
			$_table = "mobicommerce_category_widget3";
		}
		$sql = '
			SELECT c.*
			FROM `'._DB_PREFIX_.$_table.'` c   
			WHERE c.`widget_id` = "'.$widget_id.'"; 
			';
		$result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
		return $result['0'];
	}

	public function deleteWidget($widget_id, $cat="")
	{
		$_table = "mobicommerce_widget3";
		if(isset($cat) && !empty($cat))
		{
			$_table = "mobicommerce_category_widget3";
		}
		Db::getInstance()->delete($_table, 'widget_id = '. $widget_id, 1, false);
		return true;
	}

	public function getSettings($app_code, $setting_code, $language = '')
	{
		$sql = '
			SELECT c.*
			FROM `'._DB_PREFIX_.'mobicommerce_applications_settings3` c    
			WHERE c.`app_code` = "'.$app_code.'" and c.`setting_code` = "'.$setting_code.'" 
			';
		if(in_array($setting_code, array('cms_settings'))){
			$sql .= ' AND storeid = "'.$language.'"';
		}
		$result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
		return $result;
	}

	public function updatePushSetting($data, $appcode)
	{
		Db::getInstance()->update(
			'mobicommerce_applications_settings3',
			array('value' => serialize($data)),
			"app_code = '".$appcode."' AND setting_code='push_notification'",
			false
			);
	}

	public function updateAppinfo($data, $appcode)
	{
		Db::getInstance()->update(
			'mobicommerce_applications_settings3',
			array('value' => serialize($data)),
			"app_code = '".$appcode."' AND setting_code='appinfo'",
			false
			);
	}

	public function updateCMSContents($data, $appcode, $language = '')
	{
		$sql = "SELECT * FROM "._DB_PREFIX_."mobicommerce_applications_settings3 WHERE app_code = '".$appcode."' AND setting_code='cms_settings' AND storeid = '".$language."'";

		if ($results = Db::getInstance()->ExecuteS($sql)){
			Db::getInstance()->update(
				'mobicommerce_applications_settings3',
				array('value' => serialize($data)),
				"app_code = '".$appcode."' AND setting_code='cms_settings' AND storeid = '".$language."'",
				false
				);
		}
		else {
			$_data = array(
				'app_code'     => $appcode,
				'setting_code' => 'cms_settings',
				'storeid'      => $language,
				'value'        => serialize($data)
				);
			Db::getInstance()->insert("mobicommerce_applications_settings3", $_data, false, false);
		}
	}

	public function updateGoogleAnalytics($data, $appcode)
	{
		Db::getInstance()->update(
			'mobicommerce_applications_settings3',
			array('value' => serialize($data)),
			"app_code = '".$appcode."' AND setting_code='googleanalytics'",
			false
			);
	}

	public function getDeviceTokens($appcode, $type='both')
	{
		$where = array();
		$where[] = "md_appcode = '$appcode'";
		if(in_array($type, array('android', 'ios'))){
			$where[] = "md_devicetype = '$type'";
		}
		$sql = 'SELECT * FROM '._DB_PREFIX_.'mobicommerce_devicetokens WHERE '.implode(' AND ', $where);
		return Db::getInstance()->ExecuteS($sql);
	}

	public function updateAdvanceSettings($data, $appcode)
	{
		Db::getInstance()->update(
			'mobicommerce_applications_settings3',
			array('value' => serialize($data)),
			"app_code = '".$appcode."' AND setting_code='advance_settings'",
			false
			);
	}

	public function updateHomepageCategories($data, $appcode)
	{
		$sql = "SELECT * FROM "._DB_PREFIX_."mobicommerce_applications_settings3 WHERE app_code = '".$appcode."' AND setting_code='homepage_categories'";
		if ($results = Db::getInstance()->ExecuteS($sql)){
			Db::getInstance()->update(
				'mobicommerce_applications_settings3',
				array('value' => serialize($data)),
				"app_code = '".$appcode."' AND setting_code='homepage_categories'",
				false
				);
		}
		else {
			$_data = array(
				'app_code'     => $appcode,
				'setting_code' => 'homepage_categories',
				'value'        => serialize($data)
				);
			Db::getInstance()->insert("mobicommerce_applications_settings3", $_data, false, false);
		}
	}

	public static function getAll()
	{
		$db = Db::getInstance(_PS_USE_SQL_SLAVE_);
		$results = $db->executeS('
			SELECT *
			FROM '._DB_PREFIX_.self::$definition['table'].'
			');

		return $results;
	}

	public function add($autodate = TRUE, $null_values = FALSE)
	{
		return parent::add($autodate, TRUE);
	}

	public function update($null_values = FALSE)
	{
		if (parent::update($null_values)) {
			return $this->cleanPositions();
		}

		return FALSE;
	}

	public function delete()
	{
		if (parent::delete())
		{
			return $this->cleanPositions();
		}

		return FALSE;
	}

	public function savePushNotification($data)
	{
		Db::getInstance()->insert('mobicommerce_pushhistory', $data, false, false);
	}
}
