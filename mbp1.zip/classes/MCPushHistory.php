<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('_PS_VERSION_'))
	exit;

class MCPushHistory extends ObjectModel
{
	public static $definition = array(
        'table' => 'mobicommerce_pushhistory',
        'primary' => 'id',
        'multilang' => false,
        'multilang_shop' => false,
        'fields' => array(
            'appcode' => array('type' => self::TYPE_STRING, 'validate' => 'isString'),
            'device_type' => array('type' => self::TYPE_STRING, 'validate' => 'isString'),
            'heading' => array('type' => self::TYPE_STRING, 'validate' => 'isString'),
        )
    );
}
