<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE')) {
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_voucher_get_action extends BaseAction
{
    public function execute()
    {
        $p = (int)$this->getParam('page');
        $n = (int)$this->getParam('limit');
        $result = ServiceFactory::factory('Voucher')->getVoucherPoints($p, $n);
        $this->setSuccess(array(
            'voucher'             => $result['list'],
            'totalCount'          => $result['count'],
            'category_text'       => $result['category_text'],
            'transformation_text' => $result['transformation_text'],
            //'minimalLoyalty'    => $minimalLoyalty
        	));
    }
}
