<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE')) {
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_shoppingcart_shippingmethods_get_action extends BaseAction
{
    public function execute()
    {
        $carriers = array();
        $checkoutService = ServiceFactory::factory('Checkout');
        $shippingMethodes =  $checkoutService->getOrderShippingMethods($carriers);
        $methods = array();
        if(!empty($shippingMethodes)){
        	foreach ($shippingMethodes as $value) {
        		$_method = array(
                    'code'          => $value['sm_id'],
                    'carrier'       => $value['sm_id'],
                    'method_title'  => $value['title'],
                    'price'         => $value['price'],
                    'price_tax_exc' => $value['price_tax_exc'],
                    'logo'          => $value['logo'],
                    'instructions'  => $value['instructions'],
                    'carrier_index' => '2'
        			);
        		$methods[] = $_method;
        	}
        }

        $info = array();
        $info['shipping_methods'] = $methods;
        $info['cart_details'] = ServiceFactory::factory('ShoppingCart')->get();
        $this->setSuccess($info);
    }
}
