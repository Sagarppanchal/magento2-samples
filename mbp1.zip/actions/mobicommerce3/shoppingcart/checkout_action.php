<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_shoppingcart_checkout_action extends UserAuthorizedAction
{
    public function execute()
    {
        $payment = trim($_REQUEST['payment']['method']);
        $message = Tools::getValue('message');
        switch ($payment)
        {
            case 'paypalwpp':
                $this->paypalwpp();
                break;
            
            default:
                $this->payorder($payment, $message);
                break;
        }
    }

    public function paypalwpp()
    {
        //paypal express checkout
        $expressCheckout = ServiceFactory::factory('PaypalExpressCheckout');
        $paypal_express = new PaypalExpressCheckout(Tools::getValue('return_url'), Tools::getValue('cancel_url'), 'payment_cart');
        $result = $expressCheckout->startExpressCheckout($paypal_express);
        $result['paypal_redirect_url'] = str_replace('continue', 'commit', $result['paypal_redirect_url']);

        if (is_array($result) && isset($result['token']))
        {
            $this->setSuccess($result);
        }
        else
        {
            $this->setError('', (join('<br/>', $paypal_express->logs)));
        }
    }

    public function paypal()
    {
        //Website Payments Standard
        if (Module::isInstalled('paypal') && Configuration::get('PAYPAL_BUSINESS'))
        {
            $paypal = ServiceFactory::factory('PaypalWps');
            list($result, $response) = $paypal->buildWpsRedirectParams(Tools::getValue('return_url'), Tools::getValue('cancel_url'));
            if ($result == false)
            {
                $this->setError('0xFFFF', $response);
            }
            else
            {
                $this->setSuccess(array(
                    'paypal_redirect_url' => $paypal->getPaypalUrl(),
                    'paypal_params' => $response
                ));
            }
        }
        else
        {
            $this->setError('0xFFFF', 'Paypal is Unavailable.');
        }
    }

    public function payorder($method, $order_message = '')
    {
        if (empty($method))
        {
            $this->setError('', 'Error: payment_method_id is empty.');
        }
        elseif (!$this->context->cart->id || $this->context->cart->nbProducts() < 1)
        {
            $this->setError('', 'Error: ShoppingCart is empty.');
        }
        else
        {
            $this->context->cookie->__order_from_platform = 'mobicommerce';

            $payment = ServiceFactory::factory('MobicommercePayment');
            $external_payments = $payment->getExternalPaymentMethods();
            
            if ($this->context->cart->getOrderTotal() <= 0){
                $payment = ServiceFactory::factory('MobicommercePayment'); 
                $payment->placeOrder($method, $order_message);
                $orderService = ServiceFactory::factory('Order');
                $info = $orderService->getPaymentOrderInfo($order);
                $info['message'] = '';
                $this->setSuccess($info);
            }

            else if(!in_array(Tools::strtolower($method), $external_payments))
            {
                list($result, $order, $message) = $payment->placeOrder($method, $order_message);
                if ($result === true)
                {
                    $orderService = ServiceFactory::factory('Order');
                    $info = $orderService->getPaymentOrderInfo($order);
                    $info['message'] = $message;
                    $this->setSuccess($info);
                }
                else
                {
                    is_array($message) && $message = join('<br>', $message);
                    $this->setError('', $message);
                }
            }
            else
            {
                $info = array();
                $info['message'] = $message;
                $this->setSuccess($info);
            }
        }
    }
}
