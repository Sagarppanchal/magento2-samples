<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_shoppingcart_coupons_update_action extends BaseAction
{
    public function execute()
    {
        $checkoutService = ServiceFactory::factory('Checkout');
        $couponCode = $_REQUEST['coupon_code'];
        $error = $checkoutService->updateCoupon($couponCode);
        $shoppingCartInfo = ServiceFactory::factory('ShoppingCart')->get();
        if(count($error))
        {
            $this->setError(MobicommerceResult::ERROR_CART_INPUT_PARAMETER, 'Coupon code "'.$couponCode.'" is not valid.',array("cart_details"=>$shoppingCartInfo,"version_support"=>true));
            return;
        }
        
        $info = array();
        $info['cart_details'] = $shoppingCartInfo;
        $info['version_support'] = true;

        $this->setSuccess($info);
    }
}
