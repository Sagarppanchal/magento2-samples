<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_shoppingcart_checkout_detail_action extends UserAuthorizedAction
{
    public function validate()
    {
        if ($this->getParam('payment_method_id') == 'paypalwpp')
        {
            $expressCheckout = ServiceFactory::factory('PaypalExpressCheckout');
            $paypal_express = new PaypalExpressCheckout($_REQUEST['return_url'], $_REQUEST['cancel_url']);
            $expressCheckout->returnFromPaypal($paypal_express);
            return true;
        }
        else
        {
            return parent::validate();
        }
    }

    public function execute()
    {
        if (!$this->context->cart->id || $this->context->cart->nbProducts() < 1) {
            $this->setSuccess(array(
                'redirect_to_page' => 'shopping_cart',
                'messages' => array('Shopping Cart is empty.')
            ));
        }
        else
        {
            $this->setSuccess(ServiceFactory::factory('Checkout')->detail());
        }
    }
}
