<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_shoppingcart_remove_action extends BaseAction
{
    public function validate()
    {
        if (!parent::validate()) {
            return false;
        }

        $item_id = $this->getParam('item_id');
        $items = $this->getParam('items');
        if (empty($item_id) && empty($items))
        {
            $this->setError(MobicommerceResult::ERROR_CART_INPUT_PARAMETER, 'cart item id is not specified .');
            return false;
        }
        return true;
    }

    public function execute()
    {
        $items = Tools::getValue('items');
        $cartService = ServiceFactory::factory('ShoppingCart');
        if($items)
        {
            foreach($items as $_item)
            {
                $cartService->remove($_item);
            }
        }
        else
        {
            $item_id = $this->getParam('item_id');
            $products = $this->context->cart->getProducts();
            foreach($products as $_product)
            {
                $_item_id = $_product['id_product'] . ':' . $_product['id_product_attribute'] . ':' . $_product['minimal_quantity'];
                if($_item_id == $_item_id)
                {
                    $info['product_id'] = $_product['id_product'];
                }
            }
            $cartService->remove($item_id);
        }
        $info = array();

        $info['cart_details'] = ServiceFactory::factory('ShoppingCart')->get();
        $info['version_support'] = true;
        $this->setSuccess($info);
    }
}
