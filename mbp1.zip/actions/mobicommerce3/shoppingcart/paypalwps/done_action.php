<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_shoppingcart_paypalwps_done_action extends BaseAction
{
    public function execute()
    {
        $paypal = Module::getInstanceByName('paypal');
        $id_cart = $this->context->cookie->id_cart;
        $id_module = $paypal->id;
        $id_order = Order::getOrderByCartId((int)$id_cart);
        $order = new Order((int)$id_order);

        if (!$id_order OR !$id_module OR !Validate::isLoadedObject($order) OR $order->id_customer != $this->context->cookie->id_customer)
        {
            $items = array();
            foreach ($this->context->cart->getProducts() as $product)
            {
                $items[] = array(
                    'item_id' => $product['id_product'],
                    'order_item_key' => $product['id_product'],
                    'item_title' => $product['name'],
                    'category_name' => '',
                    'home_currency_price' => $product['price'],
                    'qty' => $product['cart_quantity']
                );
            }
            $orderItem = array(
                'display_id'       => $id_order,
                'shipping_address' => array(),
                'price_infos'      => array(),
                'order_items'      => $items
            );

            $currency = isset($this->context->cookie->pay_currency) ? $this->context->cookie->pay_currency : $this->context->cookie->currency;
            if (isset($_REQUEST['mc_gross']) && $_REQUEST['mc_gross'])
            {
                $total = $_REQUEST['mc_gross'];
            }
            else
            {
                $cart = new Cart($id_cart);
                $costtotal = $cart->getOrderTotal();
                $from = Currency::getCurrent();
                $to = new Currency(Currency::getIdByIsoCode($currency));
                $total = $costtotal / $from->conversion_rate * $to->conversion_rate;
            }

            $info = array(
                'transaction_id' => $_REQUEST['txn_id'],
                'payment_total'  => $total,
                'currency'       => $currency,
                'order_id'       => $id_order,
                'orders'         => array($orderItem)
            );
            $this->setSuccess($info);
        }
        else
        {
            $tx = max($_REQUEST['tx'], $_REQUEST['txn_id']);
            $orderService = ServiceFactory::factory('Order');
            $info = $orderService->getPaymentOrderInfo($order, $tx);
            $this->setSuccess($info);
        }

        unset($this->context->cookie->pay_currency);
    }
}
