<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_shoppingcart_add_action extends BaseAction
{
    public function validate()
    {
        if (!parent::validate())
        {
            return false;
        }
        $itemId = $this->getParam('product');
        $qty = $this->getParam('qty');

        if (!isset($itemId))
        {
            $errMesg = 'Item id is not specified .';
        }
        if (!is_numeric($qty) || (int)$qty <= 0)
        {
            $errMesg = 'Incorrect number of product.';
        }

        if ($errMesg)
        {
            $this->setError(MobicommerceResult::ERROR_CART_INPUT_PARAMETER, $errMesg);
            return false;
        }
        return true;
    }

    public function execute()
    {
        $itemId = $this->getParam('product');
        $qty = $this->getParam('qty');
      
        $attributes = $_REQUEST['attributes'];
        $option = array();
        $errMesg = array();
        if ($attributes) {
            foreach ($attributes as $attribute_id => $attribute_value) {
                $optionId = $attribute_id;
                $option[$optionId] = $attribute_value;
            }
        }
        
        $producToAdd = new Product($itemId, true, $this->context->cookie->id_lang);
        $productTranslator = ServiceFactory::factory('ProductTranslator');
        $ipa = Tools::getValue('ipa');
        if($ipa)
        {
            $idProductAttribute = $ipa;
        }
        else
        {
            $idProductAttribute = $productTranslator->getIdProductAttribut($option, $itemId);
        }

        //  print_r($idProductAttribute);  exit;
        $cartService = ServiceFactory::factory('ShoppingCart');

        if(!$producToAdd->id OR !$producToAdd->active)
        {
            $errMesg[] = Tools::displayError('This product is no longer available.', false);
        }
        else
        {
            if (!$producToAdd->isAvailableWhenOutOfStock($producToAdd->out_of_stock) && $producToAdd->hasAttributes() && !Attribute::checkAttributeQty($idProductAttribute, $qty))
            {
                $errMesg[] = Tools::displayError('There isn\'t enough product in stock.', false);
            }
            
            $addResult = $cartService->add($itemId, $idProductAttribute, (int)$qty);
            if ($addResult < 0 && empty($errMesg))
            {
                $errMesg[] = Tools::displayError('You must add', false) . ' ' . $producToAdd->minimal_quantity . ' ' . Tools::displayError('Minimum quantity', false);
            }
            if (!$addResult && empty($errMesg))
            {
                //$errMesg[] = Tools::displayError('You already have the maximum quantity available for this product.', false);
                $errMesg[] = Tools::displayError('There isn\'t enough product in stock.', false);
            }
        }

        $info = array();
        $info['cart_details'] = $cartService->get();
        $info['messages'] = $errMesg;
        if(empty($errMesg))
        {
            $this->setSuccess($info);
        }
        else
        {
            $this->setError(MobicommerceResult::ERROR_ITEM_INPUT_PARAMETER, implode(',', $errMesg));
        }
    }
}
