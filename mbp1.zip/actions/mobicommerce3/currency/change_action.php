<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_currency_change_action extends BaseAction
{
    public function execute()
    {
        if(isset($_REQUEST['currency']) && !empty($_REQUEST['currency']))
        {
            $currency = ServiceFactory::factory('Mobicommerce')->getCurrencyByCode($_REQUEST['currency']);
            if(!empty($currency))
            {
                $this->context->cookie->id_currency = (int) $currency['id_currency'];
            }
        }

        $this->setSuccess();
    }
}
