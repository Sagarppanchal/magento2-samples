<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_item_get_action extends BaseAction
{
    public function execute()
    {
        $productId = (int)$this->getParam('product_id');
        if($productId)
        {            
            $productTranslator = ServiceFactory::factory('ProductTranslator');
            $productTranslator->loadProductById($productId);
            $product = $productTranslator->getFullItemInfo();

            if ($product)
            {
                $this->_setProductInCookie($productId);
                $this->setSuccess(array('product_details' => $product));
            }
            else
            {
                $this->setError(MobicommerceResult::ERROR_ITEM_INPUT_PARAMETER);
            }
        }
        else
        {
            $this->setError(MobicommerceResult::ERROR_ITEM_INPUT_PARAMETER, 'product_not_available');
        }
    }

    /**
     * to set recently viewed products in cookie
     */
    protected function _setProductInCookie($id_product)
    {
        $productsViewed = (isset($this->context->cookie->viewed) && !empty($this->context->cookie->viewed)) ? array_slice(array_reverse(explode(',', $this->context->cookie->viewed)), 0, Configuration::get('PRODUCTS_VIEWED_NBR')) : array();

        if ($id_product && !in_array($id_product, $productsViewed))
        {
            $product = new Product((int)$id_product);
            if ($product->checkAccess((int)$this->context->customer->id))
            {
                if (isset($this->context->cookie->viewed) && !empty($this->context->cookie->viewed))
                    $this->context->cookie->viewed .= ','.(int)$id_product;
                else
                    $this->context->cookie->viewed = (int)$id_product;
            }
        }
    }
}
