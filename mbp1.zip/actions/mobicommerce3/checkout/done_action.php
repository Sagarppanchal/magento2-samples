<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_checkout_done_action extends UserAuthorizedAction
{
    public function execute()
    {
        switch (Tools::getValue('checkout_type'))
        {
            case 'cart':
                if (Tools::getValue('payment_method_id') == 'paypal')
                {
                    $actionInstance = ActionFactory::factory('KanCart.ShoppingCart.PayPalWPS.Done');
                    $actionInstance->init();
                    $actionInstance->execute();
                    $this->result = $actionInstance->getResult();
                }
                else if (Tools::getValue('payment_method_id') == 'paypalwpp')
                {
                    $actionInstance = ActionFactory::factory('KanCart.ShoppingCart.PayPalEC.Pay');
                    $actionInstance->init();
                    $actionInstance->execute();
                    $this->result = $actionInstance->getResult();
                }
                else
                {
                    $mobicommercePaymentService = ServiceFactory::factory('MobicommercePayment');
                    list($result, $order) = $mobicommercePaymentService->mobicommercePaymentDone(Tools::getValue('order_id'), Tools::getValue('custom_kc_comments'), Tools::getValue('payment_status'));
                    if ($result === TRUE)
                    {
                        $info = ServiceFactory::factory('Order')->getPaymentOrderInfo($order);
                        $this->setSuccess($info);
                    }
                    else
                    {
                        $this->setError('0xFFFF', $order);
                    }
                }
            case 'order':
                break;
            default:
                break;
        }
    }
}
