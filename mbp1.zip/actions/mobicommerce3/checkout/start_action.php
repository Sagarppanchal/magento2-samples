<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_checkout_start_action extends UserAuthorizedAction
{
    public function validate()
    {
        if ($this->getParam('payment_method_id') == 'paypalec')
        {
            return true;
        }
        else
        {
            return parent::validate();
        }
    }

    public function execute()
    {
        switch (Tools::getValue('checkout_type'))
        {
            case 'cart':
                $paymentMethodID = $this->getParam('payment_method_id');
                if(!$paymentMethodID)
                {
                    $this->setError('', 'Payment_method_id is empty.');
                }
                else if($paymentMethodID == 'paypalec')
                {
                    $actionInstance = ActionFactory::factory('KanCart.ShoppingCart.PaypalEC.Start');
                    $actionInstance->init();
                    $actionInstance->execute();
                    $this->result = $actionInstance->getResult();
                }
                else
                {
                    $actionInstance = ActionFactory::factory('KanCart.ShoppingCart.Checkout');
                    $actionInstance->init();
                    $actionInstance->execute();
                    $this->result = $actionInstance->getResult();
                }
                break;
            case 'order':
                break;
            default:
                break;
        }
    }
}
