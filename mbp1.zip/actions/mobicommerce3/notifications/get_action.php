<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}


class mobicommerce3_notifications_get_action extends BaseAction
{
    protected $limit = 50;
    
    public function execute()
    {
        $customer_id = (int) $this->context->cookie->id_customer;
        $appcode = Tools::getValue('appcode');
        $_table = 'mobicommerce_pushhistory';

        if ($customer_id)
        {
            $store = $this->context->cookie->id_lang;
            $customer = new Customer($customer_id);
            $customer_group_id = $customer->id_default_group;

            $sql = "SELECT * FROM "._DB_PREFIX_ . $_table . " WHERE 
                appcode = '".$appcode."' AND store_id IN ('0', '".$store."') AND (send_to_type ='all' OR ";
            $sql .= "(send_to_type = 'specific_customer' AND FIND_IN_SET( '" . $customer_id . "', send_to)) OR ";
            $sql .= "(send_to_type = 'customer_group' AND FIND_IN_SET( '" . $customer_group_id . "', send_to))) ORDER BY `id` DESC";
            $sql .= " LIMIT " . ($this->limit);
        }
        else
        {
            $sql = "SELECT * FROM "._DB_PREFIX_ . $_table . " WHERE appcode = '".$appcode."' AND store_id IN ('0', '".$store."') AND send_to_type ='all' AND device_type IN ('both', '".Tools::getValue('device')."') ORDER BY id DESC";
            $sql .= " LIMIT " . ($this->limit);
        }
        $collection = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);

        $notifications = array();
        if ($collection) {
            foreach ($collection as $_collection) {
                $send_time = $_collection['date_submitted'];
                $_notification = array(
                    'id'        => $_collection['id'],
                    'heading'   => $_collection['heading'],
                    'message'   => $_collection['message'],
                    'deeplink'  => $_collection['deeplink'],
                    'image_url' => $_collection['image'],
                    'send_time' => $send_time
                    );
                addImageRatio($_notification);
                $notifications[] = $_notification;
            }
        }

        $info = $array;
        $info['notifications'] = $notifications;
        $this->setSuccess($info);
    }
}
