<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_review_get_action extends BaseAction
{
    public function execute()
    {
        $product_id = Tools::getValue('product_id');
        $p = Tools::getValue('page');
        $n = Tools::getValue('limit');

        $info = array();
        $service = ServiceFactory::factory('ProductTranslator');
        $info['product_id'] = $product_id;
        $info['reviews'] = $service->getProductReviews($product_id, $p, $n);
        $info['token'] = Tools::getValue('token');
        $this->setSuccess($info);
    }
}
