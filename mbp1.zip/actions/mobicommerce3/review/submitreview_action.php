<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

include_once _PS_MODULE_DIR_.'productcomments/productcomments.php';
include_once _PS_MODULE_DIR_.'productcomments/ProductComment.php';
include_once _PS_MODULE_DIR_.'productcomments/ProductCommentCriterion.php'; 

class mobicommerce3_review_submitreview_action extends BaseAction
{
    protected $key = "d0a7e7997b6d5fcd55f4b5c32611b87cd923e88837b63bf2941ef819dc8ca282";

    public function execute()
    {
        $module_instance = new ProductComments();
        $id_guest = 0;
        if(isset($_REQUEST['autologinid']) && !empty($_REQUEST['autologinid'])){
            $id_customer = $this->decrypt($_REQUEST['autologinid']);
        }
        if (!$id_customer)
            $id_guest = $this->context->cookie->id_guest;  

        $errors = array();   

        if (!Validate::isInt(Tools::getValue('productId')))
            $errors[] = $module_instance->l('Product ID is incorrect', 'default');
        if (!Tools::getValue('title') || !Validate::isGenericName(Tools::getValue('title')))
            $errors[] = $module_instance->l('Title is incorrect', 'default');
        if (!Tools::getValue('detail') || !Validate::isMessage(Tools::getValue('detail')))
            $errors[] = $module_instance->l('Comment is incorrect', 'default');
        if (!$id_customer && (!Tools::isSubmit('nickname') || !Tools::getValue('nickname') || !Validate::isGenericName(Tools::getValue('nickname'))))
            $errors[] = $module_instance->l('Customer name is incorrect', 'default');
        if (!count(Tools::getValue('ratings')))
            $errors[] = $module_instance->l('You must give a rating', 'default');

        $product = new Product(Tools::getValue('productId'));
        if (!$product->id)
            $errors[] = $module_instance->l('Product not found', 'default');

        if (!count($errors))
        {
            $customer_comment = ProductComment::getByCustomer(Tools::getValue('productId'), $id_customer, true, $id_guest);
            if (!$customer_comment || ($customer_comment && (strtotime($customer_comment['date_add']) + (int)Configuration::get('PRODUCT_COMMENTS_MINIMAL_TIME')) < time()))
            {
                $comment = new ProductComment();
                $comment->content = strip_tags(Tools::getValue('detail'));
                $comment->id_product = (int)Tools::getValue('productId');
                $comment->id_customer = (int)$id_customer;
                $comment->id_guest = $id_guest;
                $comment->customer_name = Tools::getValue('nickname');
                if (!$comment->customer_name)
                    $comment->customer_name = pSQL($this->context->customer->firstname.' '.$this->context->customer->lastname);
                $comment->title = Tools::getValue('title');
                $comment->grade = 0;
                $comment->validate = 0;
                $comment->save();

                $grade_sum = 0;
                foreach(Tools::getValue('ratings') as $id_product_comment_criterion => $grade)
                {
                    $grade_sum += $grade;
                    $product_comment_criterion = new ProductCommentCriterion($id_product_comment_criterion);
                    if ($product_comment_criterion->id)
                        $product_comment_criterion->addGrade($comment->id, $grade);
                }

                if (count(Tools::getValue('ratings')) >= 1)
                {
                    $comment->grade = $grade_sum / count(Tools::getValue('ratings'));
                    // Update Grade average of comment
                    $comment->save();
                }

                $info = array();
                $info['message'] = 'Your Comment is Uploaded Succesfully';
                $productService = ServiceFactory::factory('Product');
                $product = $productService->getProduct((int)Tools::getValue('productId'));
                if($product){
                    $info['product_details'] = $product;
                }
                $this->setSuccess($info);
            }
            else
            {
               $this->setError(MobicommerceResult::ERROR_ITEM_INPUT_PARAMETER); 
            }
        }else{
            $this->setError('', join('<br/>', $errors));
        }        
    }

    public function decrypt($string)
    {
        $decrypt = explode('|', $string.'|');
        $decoded = base64_decode($decrypt[0]);
        $iv = base64_decode($decrypt[1]);
        if(Tools::strlen($iv)!==mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_CBC)){ return false; }
        $key = $this->key;
        $key = pack('H*', $key);
        $decrypted = trim(mcrypt_decrypt(MCRYPT_RIJNDAEL_256, $key, $decoded, MCRYPT_MODE_CBC, $iv));
        $mac = Tools::substr($decrypted, -64);
        $decrypted = Tools::substr($decrypted, 0, -64);
        $calcmac = hash_hmac('sha256', $decrypted, Tools::substr(bin2hex($key), -32));
        if($calcmac!==$mac){ return false; }
        return $decrypted;
    }
}
