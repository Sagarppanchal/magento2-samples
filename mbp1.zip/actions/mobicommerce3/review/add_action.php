<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_review_add_action extends BaseAction
{
    public function validate()
    {
        if (parent::validate())
        {
            $content = $this->getParam('content');
            if (!isset($content) || $content == '')
            {
                $this->setError(MobicommerceResult::ERROR_USER_INPUT_PARAMETER);
                return false;
            }
            $item_id = $this->getParam('item_id');
            if (!isset($item_id) || $item_id == '')
            {
                $this->setError(MobicommerceResult::ERROR_USER_INPUT_PARAMETER);
                return false;
            }
        }
        return true;
    }

    public function execute()
    {
        $this->setError (array(array('This system does not support comments.')));   
    }
}
