<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE')) {
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_address_remove_action extends UserAuthorizedAction
{
    public function execute()
    {
        $address_id = (int) Tools::getValue('id');
        if ($address_id) {
            $result = ServiceFactory::factory('User')->deleteAddress($address_id);
            if (true === $result)
            {
                $this->setSuccess(
                    array(
                        'cart_details' => ServiceFactory::factory('ShoppingCart')->get(),
                        'userdata'     => ServiceFactory::factory('User')->getUserInfo($this->context->cookie->email),
                        )
                    );
                return;
            }
            $this->setError(MobicommerceResult::ERROR_USER_INPUT_PARAMETER, join(',', $result));
        }
        $this->setError(MobicommerceResult::ERROR_USER_INPUT_PARAMETER, 'Address book is empty');
    }
}
