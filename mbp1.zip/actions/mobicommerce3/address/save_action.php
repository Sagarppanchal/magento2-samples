<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE')) {
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_address_save_action extends BaseAction
{
    public function execute()
    {
        $userService = ServiceFactory::factory('User');
        
        $street = Tools::getValue('street', array('', ''));
        $address = array(
            'address_id'   => Tools::getValue('id', null),
            'alias'        => Tools::getValue('alias', ''),
            'lastname'     => Tools::getValue('lastname', ''),
            'firstname'    => Tools::getValue('firstname', ''),
            'company'      => Tools::getValue('company', ''),
            'country_id'   => Tools::getValue('country_id', ''),
            'id_state'     => Tools::getValue('region_id', ''),
            'city'         => Tools::getValue('city', ''),
            'address_1'    => $street[0],
            'address_2'    => $street[1],
            'postcode'     => Tools::getValue('postcode', ''),
            'phone'        => Tools::getValue('phone', ''),
            'phone_mobile' => Tools::getValue('phone_mobile', ''),
        );

        $updateResult = $userService->updateAddress($address);
        if (!is_array($updateResult))
        {
            $this->setSuccess(array(
                'cart_details' => ServiceFactory::factory('ShoppingCart')->get(),
                'userdata'     => ServiceFactory::factory('User')->getUserInfo($this->context->cookie->email),
                'message'      => $updateResult
                ));
            return;
        }
        $this->setError(MobicommerceResult::ERROR_USER_INPUT_PARAMETER, implode(',', $updateResult));
    }
}
