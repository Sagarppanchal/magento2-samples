<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
	header('HTTP/1.1 404 Not Found');
	die();
}

class mobicommerce3_orders_get_action extends UserAuthorizedAction
{
	public function execute()
	{
		$pageNo = $this->getParam('page');
		$pageSize = $this->getParam('limit');

		$parameter = array('page_no'=>(isset($pageNo) && is_numeric($pageNo) ? (int)$pageNo : 1),
			'page_size'   => (isset($pageSize) && is_numeric($pageSize) ? ((int)$pageSize > 30 ? 30 : (int)$pageSize) : 10),
			'status_id'   => $this->getParam('status_id'),
			'customer_id' => $this->context->cookie->id_customer);

		$info = array();
		$info = ServiceFactory::factory('Order')->getOrderInfos($parameter);
		$info['token'] = Tools::getValue('token');
		$this->setSuccess($info);
	}
}
