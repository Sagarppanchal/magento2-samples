<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_payments_paywithamazon_redirect_action extends BaseAction
{
    public function execute()
    {
    	$this->hookDisplayShoppingCart();
        exit;
    }

    public function hookDisplayShoppingCart()
    {
        $str = '';
        $_dir = _PS_ROOT_DIR_.'/modules/pwapresta';
        //echo $_dir;exit;
        $context = Context::getContext();
        //check PWA is enable if yes then show Pay With Amazon button on cart page
        if ( Configuration::get('PWAPRESTA_PWAPRESTA_ENABLE') )
        { 
            if( Configuration::get('PWAPRESTA_PWAPRESTA_SHOW_CART_BUTTON') )            
            {
                if( Configuration::get('PWAPRESTA_PWAPRESTA_BTN_SHOW') == 'loggeed' && $context->customer->isLogged())
                {
                    if ( ! defined( 'PWA_MODULE_DIR' ) ) {
                        define( 'PWA_MODULE_DIR' , dirname($_dir.'/pwapresta.php'));
                    }
                    include_once( $_dir.'/'.'includes/class-pwapresta.php' );
                    $cba = new PWA_Cba();   
                    $str = $cba->pay_with_amazon_button('cart');
                }
        
                if( Configuration::get('PWAPRESTA_PWAPRESTA_BTN_SHOW') == 'notlogged')
                {
                    if ( ! defined( 'PWA_MODULE_DIR' ) ) {
                        define( 'PWA_MODULE_DIR' , dirname($_dir.'/pwapresta.php'));
                    }
                    include_once( $_dir.'/'.'includes/class-pwapresta.php' );
                    $cba = new PWA_Cba();   
                    $str = $cba->pay_with_amazon_button('cart');
                }
            }
        }
        ?>
        <div style="display:none">
            <?php
            echo $str;
            ?>
        </div>
        <script>
        setTimeout(function(){
            document.images[0].click();
        }, 1000);
        </script>
        <?php
    }
}
