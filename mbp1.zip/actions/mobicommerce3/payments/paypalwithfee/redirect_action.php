<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_payments_paypalwithfee_redirect_action extends BaseAction
{
    public function execute()
    {
        $params = array();
        $params['cart'] = $this->context->cart;
        $html = Module::getInstanceByName('paypalwithfee')->hookPayment($params);
        echo $html;
        ?>
        <script>
            document.forms[0].submit();
        </script>
        <?php
        exit;
    }
}
