<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_payments_common_redirect_action extends BaseAction
{
    public function execute()
    {
        $payment_method = Tools::getValue('payment_method');
        $method = '';
        switch ($payment_method) {            
            default:
                $method = $payment_method;
                break;
        }
        
        $params = array();
        $params['cart'] = $this->context->cart;
        $html = Module::getInstanceByName($method)->hookPayment($params);
        echo $html;
        ?>
        <script>
            if(document.forms.length > 0) {
                document.forms[0].submit();
            }
            else if(document.getElementsByTagName('a').length == 1) {
                document.getElementsByTagName('a')[0].click();
            }
        </script>
        <?php
        exit;
    }
}
