<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_payments_payfortfort_redirect_action extends BaseAction
{
    public function execute()
    {
        $url = Tools::getValue('url');
        $params = Tools::getValue('params');

        $merchant_identifier = Tools::getValue('merchant_identifier');
        $access_code         = Tools::getValue('access_code');
        $merchant_reference  = Tools::getValue('merchant_reference');
        $language            = Tools::getValue('language');
        $service_command     = Tools::getValue('service_command');
        $return_url          = Tools::getValue('return_url');
        $return_url          = "https://www.josooq.com/index.php?fc=module&module=payfortfort&controller=payment&action=merchantPageResponse";
        $signature           = Tools::getValue('signature');

        $card_holder_name = Tools::getValue('card_holder_name');
        $card_number = Tools::getValue('card_number');
        $expiry_date = Tools::getValue('expiry_date');
        $expiry_year = Tools::getValue('expiry_year');
        $card_security_code = Tools::getValue('card_security_code');

        $expiry_date = $expiry_year.$expiry_date;
    	?>

        <form method="post" action="<?php echo $url; ?>">
            <input type="hidden" name="merchant_identifier" value="<?php echo $merchant_identifier; ?>" />
            <input type="hidden" name="access_code" value="<?php echo $access_code; ?>" />
            <input type="hidden" name="merchant_reference" value="<?php echo $merchant_reference; ?>" />
            <input type="hidden" name="language" value="<?php echo $language; ?>" />
            <input type="hidden" name="service_command" value="<?php echo $service_command; ?>" />
            <input type="hidden" name="return_url" value="<?php echo $return_url; ?>" />
            <input type="hidden" name="signature" value="<?php echo $signature; ?>" />

            <input type="hidden" name="card_holder_name" value="<?php echo $card_holder_name; ?>" />
            <input type="hidden" name="card_number" value="<?php echo $card_number; ?>" />
            <input type="hidden" name="expiry_date" value="<?php echo $expiry_date; ?>" />
            <input type="hidden" name="card_security_code" value="<?php echo $card_security_code; ?>" />
        </form>
		<script>
			document.forms[0].submit();
		</script>
		<?php
		exit;
    }
}
