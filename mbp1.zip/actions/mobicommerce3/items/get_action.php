<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_items_get_action extends BaseAction
{
    public function execute()
    {
        if (Tools::getValue('order_by'))
        {
            $sortOptions = explode(':', Tools::getValue('order_by'));
            $_REQUEST['sort_by'] = $sortOptions[0];
            $sortOptions[1] ? $_REQUEST['sort_order'] = $sortOptions[1] : $_REQUEST['sort_order'] = 'desc';
        }
        if (Tools::getValue('sort'))
        {
            switch(Tools::getValue('sort'))
            {
                case "price-h-l" : 
                    $_REQUEST['sort_by'] = "price";
                    $_REQUEST['sort_order'] = 'desc';

                    /* for latered navigation */
                    $_GET['orderby'] = "price";
                    $_GET['orderway'] = 'desc';
                    /* for latered navigation - upto here */
                    break;
                case "price-l-h" : 
                    $_REQUEST['sort_by'] = "price";
                    $_REQUEST['sort_order'] = 'asc';

                    /* for latered navigation */
                    $_GET['orderby'] = "price";
                    $_GET['orderway'] = 'asc';
                    /* for latered navigation - upto here */
                    break;
                case "position" : 
                    $_REQUEST['sort_by'] = "position";
                    $_REQUEST['sort_order'] = 'desc';
                    break;
                case "popularity" : 
                    $_REQUEST['sort_by'] =  "price";
                    $_REQUEST['sort_order'] = 'desc';
                    break;
                case "rating-h-l" : 
                    $_REQUEST['sort_by'] = "price";
                    $_REQUEST['sort_order'] = 'desc';
                    break;
                case "name-a-z" : 
                    $_REQUEST['sort_by'] = "name";
                    $_REQUEST['sort_order'] = 'asc';

                    /* for latered navigation */
                    $_GET['orderby'] = "name";
                    $_GET['orderway'] = 'asc';
                    /* for latered navigation - upto here */
                    break; 
                case "name-z-a" : 
                    $_REQUEST['sort_by'] = "name";
                    $_REQUEST['sort_order'] = 'desc';

                    /* for latered navigation */
                    $_GET['orderby'] = "name";
                    $_GET['orderway'] = 'desc';
                    /* for latered navigation - upto here */
                    break;
                case "newest":
                    $_REQUEST['sort_by'] =  "date_add";
                    $_REQUEST['sort_order'] = 'desc';
                    break;
                default :  
                    $_REQUEST['sort_by'] = "";
                    $_REQUEST['sort_order'] = '';
                    break;
            }
        }

        if(isset($_REQUEST['page']) && isset($_REQUEST['limit']))
        {
            $_GET['p'] = $_REQUEST['page'];
            $_GET['n'] = $_REQUEST['limit'];
        }
        
        if ($_REQUEST['item_ids'])
        {
            $_REQUEST['item_ids'] = explode(',', $_REQUEST['item_ids']);
        }
        
        $productService = ServiceFactory::factory('Product');
        $category_id = Tools::getValue('category_id');
        $_token = Tools::getValue('token');

        $_GET['id_category'] = $category_id;

        $info = $productService->getProducts($_REQUEST);
        if($category_id)
        {
            $info['category_id'] = $category_id;
        }

        $info['token'] = $_token;

        $this->setSuccess($info);
    }
}
