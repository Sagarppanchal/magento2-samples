<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_items_search_action extends BaseAction
{
    public function execute()
    {
        if ($_REQUEST['order_by'])
        {
            $sortOptions = explode(':', $_REQUEST['order_by']);
            $_REQUEST['sort_by'] = $sortOptions[0];
            $sortOptions[1] ? $_REQUEST['sort_order'] = $sortOptions[1] : $_REQUEST['sort_order'] = 'desc';
        }
        if ($_REQUEST['order'])
        {
            switch($_REQUEST['order'])
            {
                case "price-h-l" : 
                    $_REQUEST['sort_by'] = "price";
                    $_REQUEST['sort_order'] = 'desc';

                    /* for latered navigation */
                    $_GET['orderby'] = "price";
                    $_GET['orderway'] = 'desc';
                    /* for latered navigation - upto here */

                    break;
                case "price-l-h" : 
                    $_REQUEST['sort_by'] = "price";
                    $_REQUEST['sort_order'] = 'asc';

                    /* for latered navigation */
                    $_GET['orderby'] = "price";
                    $_GET['orderway'] = 'asc';
                    /* for latered navigation - upto here */
                    break;
                case "position" : 
                    $_REQUEST['sort_by'] = "position";
                    $_REQUEST['sort_order'] = 'desc';
                    break;
                case "popularity" : 
                    $_REQUEST['sort_by'] =  "price";
                    $_REQUEST['sort_order'] = 'desc';
                    break;
                case "rating-h-l" : 
                    $_REQUEST['sort_by'] = "price";
                    $_REQUEST['sort_order'] = 'desc';
                    break;
                case "name-a-z" : 
                    $_REQUEST['sort_by'] = "name";
                    $_REQUEST['sort_order'] = 'asc';

                    /* for latered navigation */
                    $_GET['orderby'] = "name";
                    $_GET['orderway'] = 'asc';
                    /* for latered navigation - upto here */
                    break; 
                case "name-z-a" : 
                    $_REQUEST['sort_by'] = "name";
                    $_REQUEST['sort_order'] = 'desc';

                    /* for latered navigation */
                    $_GET['orderby'] = "name";
                    $_GET['orderway'] = 'desc';
                    /* for latered navigation - upto here */
                    break;
                case "newest":
                    $_REQUEST['sort_by'] =  "date_add";
                    $_REQUEST['sort_order'] = 'desc';
                    break;
                default :
                    $_REQUEST['sort_by'] = "";
                    $_REQUEST['sort_order'] = '';
                    break;
            }
        }

        if(isset($_REQUEST['page']) && isset($_REQUEST['limit']))
        {
            $_GET['p'] = $_REQUEST['page'];
            $_GET['n'] = $_REQUEST['limit'];
        }
        
        if ($_REQUEST['item_ids'])
        {
            $_REQUEST['item_ids'] = explode(',', $_REQUEST['item_ids']);
        }

        $_token = Tools::getValue('token');
        
        $info = array();
        $info = ServiceFactory::factory('Product')->searchProducts($_REQUEST);
        $info['token'] = $_token;

        $this->setSuccess($info);
    }
}
