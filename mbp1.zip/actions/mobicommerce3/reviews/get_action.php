<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_reviews_get_action extends BaseAction
{
    public function validate()
    {
        if (parent::validate())
        {
            $itemId = $this->getParam('item_id');
            if (!isset($itemId) || $itemId == '')
            {
                $this->setError(MobicommerceResult::ERROR_USER_INPUT_PARAMETER);
                return false;
            }
        }
        return true;
    }

    public function execute()
    {
       $this->setError (array(array('This system does not support comments.')));
    }
}
