<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_cms_get_action extends BaseAction
{
    public function execute()
    {
        $id = Tools::getValue('id');
        if(!$id)
        {
            $id = Tools::getValue('page_id');
        }
        
        $info = ServiceFactory::factory('Mobicommerce')->getCMSDetail($id);
        if ($info)
        {
            $this->setSuccess($info);
        }
        else
        {
            $this->setError(MobicommerceResult::ERROR_ITEM_INPUT_PARAMETER);
        }
    }
}
