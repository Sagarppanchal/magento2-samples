<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_user_forgotpwd_action extends BaseAction
{
    public function execute()
    {
        $username = Tools::getValue('email');
        $customer = new Customer();
        
        if (empty($username) || !Validate::isEmail($username))
        {
            $this->setError(MobicommerceResult::ERROR_USER_INVALID_USER_DATA, array(Tools::displayError('Invalid e-mail address')));
            return;
        }

        $customer->getByEmail($username);

        if (!Validate::isLoadedObject($customer))
        {
			$this->setError(MobicommerceResult::ERROR_USER_INVALID_USER_DATA, array(Tools::displayError('There is no account registered for this email address.')));
            return;
        }
		else if(!$customer->active)
        {
			$this->setError(MobicommerceResult::ERROR_USER_INVALID_USER_DATA, array(Tools::displayError('You cannot regenerate the password for this account.')));
            return;
		}
		else if ((strtotime($customer->last_passwd_gen.'+'.($min_time = (int)Configuration::get('PS_PASSWD_TIME_FRONT')).' minutes') - time()) > 0)
        {
			$this->setError(MobicommerceResult::ERROR_USER_INVALID_USER_DATA, array(sprintf(Tools::displayError('You can regenerate your password only every %d minute(s)'), (int)$min_time)));
            return;
		}
		$context = Context::getContext();
        $mail_params = array(
            '{email}'     => $customer->email,
            '{lastname}'  => $customer->lastname,
            '{firstname}' => $customer->firstname,
            '{url}'       => $context->link->getPageLink('password', true, null, 'token='.$customer->secure_key.'&id_customer='.(int)$customer->id)
		);
		if (Mail::Send($context->language->id, 'password_query', Mail::l('Password query confirmation'), $mail_params, $customer->email, $customer->firstname.' '.$customer->lastname))
        {
			$this->setSuccess(array('cart_details' => ServiceFactory::factory('ShoppingCart')->get()));
		}
		else
        {
		 	$this->setError(MobicommerceResult::ERROR_USER_INVALID_USER_DATA, array(Tools::displayError('An error occurred while sending the email.')));
            return;
        }
    }
}
