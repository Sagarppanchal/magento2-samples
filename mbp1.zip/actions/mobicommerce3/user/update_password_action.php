<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_user_update_password_action extends UserAuthorizedAction
{
    public function execute()
    {
        $currentPassword = Tools::getValue('current_password');   
        $NewPassword = Tools::getValue('password');
        $confirmPassword = Tools::getValue('confirmation');

        if(empty($NewPassword))
        {
            $this->setError(MobicommerceResult::ERROR_USER_INVALID_USER_DATA, array('password_required_error'));
            return;
        }
        else if (Tools::encrypt($currentPassword) != $this->context->cookie->passwd)
        {
            $this->setError(MobicommerceResult::ERROR_USER_INVALID_USER_DATA, array(Tools::displayError('The password you entered is incorrect.')));
            return;
        }
        elseif ($NewPassword != $confirmPassword)
        {
            $this->setError(MobicommerceResult::ERROR_USER_INVALID_USER_DATA, array(Tools::displayError('The password and confirmation do not match.')));
            return;
        }
        else
        {
        	$customer = new Customer((int)$this->context->cookie->id_customer);
        	$customer->passwd = md5(_COOKIE_KEY_.$NewPassword);
        	$customer->update();

        	$this->context->cookie->passwd = $customer->passwd;
        }

        $info = array();
        $info['cart_details'] = ServiceFactory::factory('ShoppingCart')->get();
        $info['userdata'] = ServiceFactory::factory('User')->getUserInfo($this->context->cookie->email);
        $this->setSuccess($info);
    }
}
