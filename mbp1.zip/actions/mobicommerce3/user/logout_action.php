<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_user_logout_action extends UserAuthorizedAction
{
    public function execute()
    {
        ServiceFactory::factory('User')->logout();

        $info = array();
        $info['cart_details'] = ServiceFactory::factory('ShoppingCart')->get();
        $this->setSuccess($info);
    }
}
