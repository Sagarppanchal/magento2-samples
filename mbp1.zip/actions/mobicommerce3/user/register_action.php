<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_user_register_action extends BaseAction
{
    public function execute()
    {
        $userService = ServiceFactory::factory('User');
        $username = is_null($this->getParam('email')) ? '' : trim($this->getParam('email'));
        $enCryptedPassword = is_null($this->getParam('password')) ? '' : trim($this->getParam('password'));
        $password = $enCryptedPassword;

        $customer = new Customer();
        
        if (empty($username) || !Validate::isEmail($username))
        {
            $this->setError(MobicommerceResult::ERROR_USER_INVALID_USER_DATA, array(Tools::displayError('Invalid e-mail address')));
            return;
        }

        $customer->getByEmail($username);

        if ($customer->id)
        {
            $this->setError(MobicommerceResult::ERROR_USER_INVALID_USER_DATA, array(Tools::displayError('An account already exists for this email address:')));
            return;
        }

        if (empty($password))
        {
            $this->setError(MobicommerceResult::ERROR_USER_INVALID_USER_DATA, array(Tools::displayError('Password is required')));
            return;
        }
        if (!Tools::getValue('is_new_customer', 1) && !Configuration::get('PS_GUEST_CHECKOUT_ENABLED'))
        {
             $this->setError(MobicommerceResult::ERROR_USER_AUTHENTICATION_PROBLEM, array(Tools::displayError('You cannot create a guest account.')));
             return;
        }
        $name = trim($this->getParam('lastname'));
        $firstname = is_null($this->getParam('firstname')) ? '  ' : trim($this->getParam('firstname'));
        $customAttributes = $this->getParam('customAttributes');
        $lastname = empty($name) ? '  ' : $name;
        $regisetInfo = array(
            'firstname'        => $firstname,
            'lastname'         => $lastname,
            'email'            => $username,
            'password'         => $password,
            'customAttributes' => $customAttributes
        );
        $result = $userService->register($regisetInfo);
        if ($result!==true)
        {
            $this->setError(MobicommerceResult::ERROR_USER_INVALID_USER_DATA, $result);
            return;
        }

        $this->setSuccess(
            array(
                'cart_details' => ServiceFactory::factory('ShoppingCart')->get(),
                'userdata' => ServiceFactory::factory('User')->getUserInfo()
                )
            );
    }
}
