<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE')) {
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_user_sociallogin_action extends BaseAction
{
    public function execute()
    {
        $type = Tools::getValue('type');
        switch ($type)
        {
            case 'facebook':
                $result = $this->doFacebookLogin();
                break;

            case 'google':
                $result = $this->doGoogleLogin();
                break;

            default:
                $result = $this->errorStatus("oops");
                break;
        }

        return $result;
    }

    public function doFacebookLogin($data)
    {
        $user_data = array(
            'firstname' => Tools::getValue('first_name'),
            'lastname'  => Tools::getValue('last_name'),
            'email'     => Tools::getValue('email')
            );

        $actionAfterLogin = array();
        if(isset($data['actionAfterLogin']))
        {
            $actionAfterLogin = $data['actionAfterLogin'];
        }

        return $this->loginProcess($user_data, $actionAfterLogin);
    }

    public function doGoogleLogin($data)
    {
        $user_data = array(
            'firstname' => Tools::getValue('givenName'),
            'lastname'  => Tools::getValue('familyName'),
            'email'     => Tools::getValue('email')
            );

        $actionAfterLogin = array();
        if(isset($data['actionAfterLogin']))
        {
            $actionAfterLogin = $data['actionAfterLogin'];
        }

        return $this->loginProcess($user_data, $actionAfterLogin);
    }

    public function loginProcess($data, $actionAfterLogin)
    {
        $userService = ServiceFactory::factory('User');
        $customer = new Customer();
        if($customer->getByEmail($data['email']))
        {
            if (!$userService->login(null, $customer->id))
            {
                $this->setError(MobicommerceResult::ERROR_USER_INPUT_PARAMETER, array(Tools::displayError('Authentication failed')));
                return;
            }
            else
            {
                $info = array();
                $info['cart_details'] = ServiceFactory::factory('ShoppingCart')->get();
                $info['userdata'] = ServiceFactory::factory('User')->getUserInfo();
                $this->setSuccess($info);
            }
        }
        else
        {
            $data['password'] = uniqid();
            $result = $userService->register($data);

            if ($result!==true)
            {
                $this->setError(MobicommerceResult::ERROR_USER_INVALID_USER_DATA, $result);
                return;
            }

            $this->setSuccess(
                array(
                    'cart_details' => ServiceFactory::factory('ShoppingCart')->get(),
                    'userdata' => ServiceFactory::factory('User')->getUserInfo()
                    )
                );
        }
    }
}
