<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE')) {
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_user_update_profile_action extends UserAuthorizedAction
{
    public function execute()
    {
        $userService = ServiceFactory::factory('User');
        $data = array(
            'firstname' => Tools::getValue('firstname'),
            'lastname'  => Tools::getValue('lastname'),
            'email'     => Tools::getValue('email'),
        );
        
        try
        {
            $result = $userService->update($data);
        }
        catch(Exception $e)
        {
            $this->setError(MobicommerceResult::ERROR_USER_INVALID_USER_DATA, $e->getMessage());
            return;
        }

        if (!$result['status'])
        {
            $this->setError(MobicommerceResult::ERROR_USER_INVALID_USER_DATA, $result['message']);
            return;
        }

        $info = array();
        $info['cart_details'] = ServiceFactory::factory('ShoppingCart')->get();
        $info['userdata'] = ServiceFactory::factory('User')->getUserInfo();
        $info['message'] = $result['message'];
        $this->setSuccess($info);
    }
}
