<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_user_login_action extends BaseAction
{
    public function execute()
    {
        $errors = array();
        $userService = ServiceFactory::factory('User');
        if (!$this->context->cookie->logged)
        {
            $username = is_null($this->getParam('username')) ? '' : trim($this->getParam('username'));
            if (empty($username))
            {
                $errors[] = Tools::displayError('E-mail address required');
            }
            else if (!Validate::isEmail($username))
            {
                $errors[] = Tools::displayError('Invalid e-mail address');
            }

            $encryptedPassword = is_null($this->getParam('password')) ? '' : trim($this->getParam('password'));
            $password = $encryptedPassword;
            
            if (empty($password))
            {
                $errors[] = Tools::displayError('Password is required');
            }
            else if (Tools::strlen($password) > 32)
            {
                $errors[] = Tools::displayError('Password is too long');
            }
            else if (!Validate::isPasswd($password))
            {
                $errors[] = Tools::displayError('Invalid password');
            }
          
            if (sizeof($errors))
            {
                $this->setError(MobicommerceResult::ERROR_USER_INPUT_PARAMETER, $errors);
                return;
            }

            $loginInfo = array(
                'email' => $username,
                'password' => $password
            );

            if (!$userService->login($loginInfo))
            {
                $this->setError(MobicommerceResult::ERROR_USER_INPUT_PARAMETER, array(Tools::displayError('Authentication failed')));
                return;
            }
        }

        $info = array();
        $info['cart_details'] = ServiceFactory::factory('ShoppingCart')->get();
        $info['userdata'] = ServiceFactory::factory('User')->getUserInfo();
        
        $this->setSuccess($info);
    }
}
