<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE')) {
    header('HTTP/1.1 404 Not Found');
    die();
}

class mobicommerce3_wishlist_get_action extends BaseAction
{
    public function execute()
    {    
        $ids = is_null($this->getParam('ids')) ? '' : trim($this->getParam('ids'));
        $ids = array_filter(explode(',', $ids));
        $finalProductArray = array();
        if(!empty($ids))
        {
            foreach($ids as $_id)
            {
                $productTranslator = ServiceFactory::factory('ProductTranslator');
                $productTranslator->loadProductById($_id);
                //$finalProductArray[$_id] = $productTranslator->getFullItemInfo();
                $_product = $productTranslator->getFullItemInfo();
                $_product['wishlist_item_id'] = $_product['product_id'];
                $_product['qty'] = 1;
                $finalProductArray[$_id] = $_product;
            }
        }
        $finalProductArray = array_values($finalProductArray);
		$this->setSuccess(array(
            'cart_details' => ServiceFactory::factory('ShoppingCart')->get(),
            'wishlist' => $finalProductArray
            ));
    }
}
