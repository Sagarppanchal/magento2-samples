<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class BaseAction
{
    protected $params = array();
    protected $paramSources = array('_GET', '_POST');
    protected $result = null;
    protected $context;

    public function getParamSources()
    {
        return $this->paramSources;
    }

    public function init()
    {
        $this->context = Context::getContext();
        $this->result = new MobicommerceResult();
    }

    public function getParam($keyName)
    {
        $this->getParamSources();
        if (isset($this->_params[$keyName]))
        {
            return $this->_params[$keyName];
        } 
        return Tools::getValue($keyName, null);
    }

    public function setParam($key, $val)
    {
        if (isset($key)) {
            $this->params[$key] = $val;
        }
    }

    public function setSuccess($info = null)
    {
        if (!is_null($this->result))
        {
            $this->result->setSuccess($info);
        }
    }

    public function setError($code, $msg = null, $info = array())
    {
        if (!is_null($this->result))
        {
            $this->result->setError($code, $msg, $info);
        }
    }

    public function getResult()
    {
        return $this->result;
    }

    public function execute()
    {
        
    }

    private function validateRequestSign(array $requestParams)
    {
        if (!isset($requestParams['sign']) || $requestParams['sign'] == '')
        {
            return false;
        }
        $sign = $requestParams['sign'];
        unset($requestParams['sign']);
        unset($requestParams['XDEBUG_SESSION_START']);
        ksort($requestParams);
        reset($requestParams);
        $tempStr = "";
        foreach ($requestParams as $key => $value)
        {
            if(is_array($value))
            {
				foreach($value as $k => $v)
                {
					$tempStr = $tempStr . $key. '[' . $k . ']' . Tools::stripslashes($v);
				}
			}
            else
            {
				$tempStr = $tempStr . $key . Tools::stripslashes($value);
			}
        }
        $tempStr = $tempStr . MOBICOMMERCE_APP_SECRET;
        return strtoupper(md5($tempStr)) === $sign;
    }

    public function validate()
    {
        if (defined('KC_DEBUG_MODE') && KC_DEBUG_MODE)
        {
            return true;
        }

        if (!$this->checkAPIKey($this->getParam('appcode')))
        {
            die('MobiCommerce OpenAPI v' . API_VERSION . ' is installed on Prestashop v' . _PS_VERSION_ . '. Prestashop Plugin v' . MOBICOMMERCE_PLUGIN_VERSION);
        }
        
        return true;
    }
    
    public function checkAPIKey($appcode)
    {
        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('
    		SELECT c.*
    		FROM `'._DB_PREFIX_.'mobicommerce_applications3` c 
    		WHERE c.`app_code` = "'.$appcode.'"	
    		');
        
        if(isset($result['0']['id']))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}
