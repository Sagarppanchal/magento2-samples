<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class UserAuthorizedAction extends BaseAction
{
    public function validate()
    {
        if (!parent::validate())
        {
            return false;
        }
        /*
        if ($cookie->isLogged(true))
        {
            return true;
        }
        */
        if ($this->context->cookie->logged)
        {
            return true;
        }
        $this->setError(MobicommerceResult::ERROR_SYSTEM_INVALID_SESSION_KEY);
        return false;
    }
}
