<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

include_once(dirname(__FILE__).'/../../classes/MCHomeWidget.php');
include_once (dirname ( __FILE__ ) . '/MCAbstract.php');
class MCHomeWidgetController extends MCAbstract
{    
    public $bootstrap = true;
    public $module;
    public $position;
    
	public function __construct()
	{
        $this->addRowAction('edit'); //add an edit button
        $this->addRowAction('delete'); //add a delete button
        $this->bulk_actions = array('delete' => array('text' => $this->l('Delete selected'), 'confirm' => $this->l('Delete selected items?')));
        $this->explicitSelect = true;
        $this->context = Context::getContext();
        $this->id_lang = $this->context->language->id;
        $this->path = _MODULE_DIR_."mobicommerce";
        $this->controller_type = 'moduleadmin';
        
        $this->bootstrap = true;
        $this->lang = false;
        $this->default_form_language = $this->context->language->id;
        $this->table = 'mobicommerce_widget'; //define the main table
        $this->className = 'MCManageAppObject'; //define the module entity
        $this->identifier = "widget_id"; //the primary key
        $this->list_id = 'mchomewidget';
        $this->module = 'mobicommerce';
 
        //and define the field to display in the admin table
        $this->fields_list = array(
            'widget_id' => array(
				'title' => $this->l('ID'),
				'align' => 'center',
    			),
            'widget_label' => array(
                'title' => $this->l('Lable'),
                'align' => 'left',
                'width' => 50
            ),
            'widget_code' => array(
                'title' => $this->l('Code'),
                'align' => 'left',
                'width' => 50
            )
        );  

        parent::__construct();
	}   
}
