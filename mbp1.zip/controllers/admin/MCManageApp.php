<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

include_once (dirname ( __FILE__ ) . '/../../classes/MCManageApp.php');
include_once (dirname ( __FILE__ ) . '/../../../../classes/Mail.php');

if (method_exists ( 'ImageType', 'getFormatedName' ))
{
	define ( 'PIC_NAME_SUFFIX', ImageType::getFormatedName ( '' ) );
}
else
{
	define ( 'PIC_NAME_SUFFIX', '' );
}

include_once (dirname ( __FILE__ ) . '/MCAbstract.php');
class MCManageAppController extends MCAbstract {
	
	public $bootstrap = true;
	public $module;
	public $position;
	
	// public $admin_cms;
	/**
	 *
	 * @var string name of the tab to display
	 */
	protected $tab_display;
	protected $current_lang;
	protected $tab_display_module;
	
	/**
	 * The order in the array decides the order in the list of tab.
	 * If an element's value is a number, it will be preloaded.
	 * The tabs are preloaded from the smallest to the highest number.
	 *
	 * @var array Product tabs.
	 */
	protected $available_tabs = array ();
	protected $default_tab = 'overview';
	protected $available_tabs_lang = array ();
	
	// protected $submitted_tabs;
	public function __construct()
	{
		$this->addRowAction('edit');
		$this->show_toolbar = false;
		$this->explicitSelect = true;
		$this->context = Context::getContext();
		$this->id_lang = $this->context->language->id;
		
		$this->bootstrap = true;
		$this->lang = false;

		$languages = Language::getLanguages ();
		$this->default_form_language = $languages[0]['id_lang'];
		$this->current_lang = $languages[0]['id_lang'];

		$this->table = 'mobicommerce_applications3'; // define the main table
		$this->className = 'MCManageAppObject'; // define the module entity
		$this->identifier = "id"; // the primary key
		$this->tab_display = '';
		$this->tpl_folder = 'mcmanageapp';

		parent::__construct();

		$this->path = _MODULE_DIR_ .'/'.$this->module->name;
		
		$this->fields_list = array (
			'id' => array (
				'title'  => $this->l ( 'ID' ),
				'align'  => 'center' ,
				'width'  => 20,
				'search' => false
				),
			'app_name' => array (
				'title' => $this->l ( 'App Name' ),
				'align' => 'left'
				),
			'app_key' => array (
				'title' => $this->l ( 'App Key' ),
				'align' => 'left',
				'width' => 50 
				));

		$this->fields_list['version_type'] = array (
			'title'    => $this->l ( 'MobiCommerce Version' ),
			'align'    => 'left',
			'callback' => 'getMobicommerceVersionTitle',
			'width'    => 50,
			'orderby'  => false,
			'search'   => false,
			);
		
		$this->fields_list['app_mode'] = array (
			'title'   => $this->l ( 'License Type' ),
			'align'   => 'left',
			'width'   => 50,
			'orderby' => false,
			'search'  => false
			);
				
		$this->fields_list['android_status'] = array (
			'title'   => $this->l ( 'Android status' ),
			'align'   => 'left',
			'width'   => 50,
			'orderby' => false,
			'search'  => false
			);

		parent::__construct ();
		
		// @since 1.5 : translations for tabs
		$this->available_tabs_lang = array (
			'Overview'          => $this->l ( 'Overview' ),
			'GeneralSettings'   => $this->l ( 'General Settings' ),
			'Colorscheme'       => $this->l ( 'Color Scheme' ),
			'AdvanceSettings'   => $this->l ( 'Advance Settings' ),
			'HomePageWidgets'   => $this->l ( 'Home Page Widgets' ),
			'CMSContents'       => $this->l ( 'CMS Contents' ),
			'GoogleAnalytics'   => $this->l ( 'Google Analytics' ),
			'PushNotifications' => $this->l ( 'Push Notificaitons' ) 
			);
		
		$this->available_tabs = array_merge ( $this->available_tabs, array (
			'Overview'          => 0,
			'GeneralSettings'   => 1,
			'Colorscheme'       => 2,
			'AdvanceSettings'   => 3,
			'HomePageWidgets'   => 4,
			'CMSContents'       => 5,
			'GoogleAnalytics'   => 6,
			'PushNotifications' => 7 
			));

		$this->addNewAddedTabs();
	}

	public function getMobicommerceVersionTitle($version_code = null)
	{
		if(!in_array($version_code, array('001', '002')))
		{
        	return $this->l('Professional');
		}
        else if($version_code == '001')
        {
        	return $this->l('Professional');
        }
        else if($version_code == '002')
        {
        	return $this->l('Enterprise');
        }
	}

	public function setMedia()
	{
		parent::setMedia ();
		$this->addjQueryPlugin (array (
			'validate'
			));
		
		$this->addJS ( array (
			_PS_JS_DIR_ . 'tiny_mce/tiny_mce.js',
			_PS_JS_DIR_ . 'admin/tinymce.inc.js',
			_PS_MODULE_DIR_ . $this->module->name.'/views/js/validationFunctions.js',
			_PS_MODULE_DIR_ . $this->module->name.'/views/js/jquery-ui.min.js',
			_PS_MODULE_DIR_ . $this->module->name.'/views/js/functions.js'
			));

		$this->addCSS(_PS_MODULE_DIR_.$this->module->name.'/views/css/admin/main.css');
	}

	public function initProcess()
	{
		if (! isset ( $_REQUEST ['action'] ))
		{
			parent::initProcess ();
		}
		else
		{
			$this->id_object = ( int ) Tools::getValue ( $this->identifier );
		}
		
		if (isset ( $this->available_tabs [Tools::getValue ( 'key_tab' )] ))
		{
			$this->tab_display = Tools::getValue ( 'key_tab' );
		}
		
		if (! $this->tab_display && isset ( $_GET ['tab_display'] ))
		{
			if (in_array ( $_GET ['tab_display'], array_keys ( $this->available_tabs ) ))
			{	
				$this->tab_display = Tools::strtolower ( $_GET ['tab_display'] );
			}
		}	
			// And if still not set, use default
		if (! $this->tab_display)
		{
			if (in_array ( $this->default_tab, $this->available_tabs ))
			{
				$this->tab_display = $this->default_tab;
			}
			else
			{
				$this->tab_display = key ( $this->available_tabs );
			}
		}
	}

	public function initContent($token = null)
	{
		$current_object = $this->loadObject(true);

		if ($this->display == 'edit' || $this->display == 'add')
		{
			$this->fields_form = array ();
			if (method_exists ( $this, 'initForm' . $this->tab_display ))
			{
				$this->tpl_form = Tools::strtolower ( $this->tab_display ) . '.tpl';
			}
			
			if ($this->ajax || Tools::getValue('ajax') == 1)
			{
				$this->content_only = true;
			}
			else
			{
				$product_tabs = array ();
				
				// tab_display defines which tab to display first
				
				foreach ( $this->available_tabs as $product_tab => $value )
				{
					if($product_tab == 'HomePageWidgets')
					{
						if($current_object->version_type == '001')
						{
							$this->available_tabs_lang [$product_tab] = $this->l ( 'Home Page Controls' );
						}
					}

					$product_tabs [$product_tab] = array (
						'id'       => $product_tab,
						'selected' => (Tools::strtolower($product_tab) == Tools::strtolower($this->tab_display) || (isset($this->tab_display_module) && 'module' . $this->tab_display_module == Tools::strtolower($product_tab))),
						'name'     => $this->available_tabs_lang [$product_tab],
						'href'     => self::$currentIndex . '&id=' . (int) Tools::getValue('id') . '&updatemobicommerce_applications&token=' . $this->token 
						);
				}
				$this->tpl_form_vars['product_tabs'] = $product_tabs;
			}
		}
		else
		{
			if (Tools::getValue('ajax') == 1)
			{
				$this->content_only = true;
				$this->{'ajaxProcess' . Tools::getValue('action')}();
			}
		}
		
		return parent::initContent();
	}

	public function renderForm()
	{
		$id = Tools::getValue('id');
		if(!$id)
		{
			Tools::redirectAdmin($this->context->link->getAdminLink('MCNewApp'));
		}
		
		$languages = Language::getLanguages();
		$lang_selectd = $languages[0]['id_lang'];

		if (Tools::getValue('lang'))
		{
			$lang_selectd = Tools::getValue('lang');
		}
		
		$lang_info = Language::getLanguage ( $lang_selectd );
		$lang_code = $lang_info ['language_code'];
		
		$this->tpl_form_vars ['lang_code'] = $lang_code;
		$this->tpl_form_vars ['lang_selectd'] = $lang_selectd;
		$this->tpl_form_vars ['tabs_preloaded'] = $this->available_tabs;

		$this->fields_form = array (
			'legend' => array (
				'title' => $this->l ( 'Push Notifications [Website]' ) 
				),
			
			'input' => array (
				array (
					'type'         => 'textarea',
					'label'        => $this->l ( "Enable Wishlist Feature " ) . " :",
					'name'         => 'cms',
					'autoload_rte' => true 
					),
				array (
					'type'  => 'color',
					'label' => $this->l ( "Enable Wishlist Feature " ) . " :",
					'name'  => 'colore' 
					)
				)
			);
		
		// add the save button
		$this->fields_form ['submit'] = array (
			'title' => $this->l ( '   Save   ' ),
			'class' => 'btn btn-default pull-right' 
			);
		
		$current_object = $this->loadObject ( true );
		
		if (!$current_object)
		{
			return;
		}

		$app_code = $current_object->app_code;
		$app_info_obj = $current_object->getSettings($app_code, "appinfo");
		$app_info = Tools::unSerialize( $app_info_obj[0]['value'] );
		
		$advance_settings_obj = $current_object->getSettings($app_code, "advance_settings");
		$advance_settings = Tools::unSerialize( $advance_settings_obj [0] ['value'] );
		
		$cms_settings_obj = $current_object->getSettings ( $app_code, "cms_settings", $lang_selectd );
		$cms_settings = Tools::unSerialize($cms_settings_obj[0]['value']);
		
		$push_notification_obj = $current_object->getSettings ( $app_code, "push_notification" );
		$push_notification = Tools::unSerialize( $push_notification_obj [0] ['value'] );
		
		$googleanalytics_obj = $current_object->getSettings ( $app_code, "googleanalytics" );
		$googleanalytics = Tools::unSerialize( $googleanalytics_obj [0] ['value'] );
		
		// Get theme information
		$themeName = "shopper";
		
		$file_personalizer_parent = _PS_MODULE_DIR_ . $this->module->name.'/views/img/mobi_assets/v/3/theme_files/' . $themeName . '/personalizer/personalizer.xml';
		$file_personalizer_child = _PS_MODULE_DIR_ . $this->module->name.'/media/mobi_commerce/' . $current_object->app_code . '/personalizer/personalizer.xml';
		$code_personalizer_parent = simplexml_load_file ( $file_personalizer_parent ) or die ( "Error: Cannot create object" );
		$code_personalizer_child = simplexml_load_file($file_personalizer_child);

		$social_icons = array(
            "facebook"   => array("img" => "soci-facebook.gif"),
            "twitter"    => array("img" => "soci-twitter.gif"),
            "linkedin"   => array("img" => "soci-linkedin.gif"),
            "pinterest"  => array("img" => "soci-pinterest.gif"),
            "youtube"    => array("img" => "soci-youtube.gif"),
            "blog"       => array("img" => "soci-blog.gif"),
            "googleplus" => array("img" => "soci-googleplus.gif"),
            "instagram"  => array("img" => "soci-instagram.gif"),
            "telegram"   => array("img" => "soci-telegram.png"),
	    	);
		
		//$attribute_groups = AttributeGroup::getAttributesGroups ( $this->current_lang );
		$front_features = Feature::getFeatures($this->current_lang);
		$selected_categories = array();

		$homepage_categories = $current_object->getSettings($app_code, "homepage_categories");
		if ($homepage_categories) {
			$selected_categories = array_flip(Tools::unSerialize($homepage_categories[0]['value']));
		}

		if(!$selected_categories)
		{
			$selected_categories = array();
		}
		
		$category = Tools::getValue ( 'category', Category::getRootCategory ()->id );
		$categories = new HelperTreeCategories('subtree_associated_categories', null, (int)$category, null, false);

		$categories
			->setRootCategory($category)
			->setSelectedCategories($selected_categories)
			->setUseSearch(true)
			->setInputName('homepage_categories')
			->setUseCheckBox(true);
			
		if(in_array(_PS_VERSION_, array('1.6.0.6', '1.6.0.8', '1.6.0.9', '1.6.0.11', '1.6.0.14')))
		{
			
		}
		else
		{
			$categories
				->setFullTree(true)
				->setChildrenOnly(true);
		}

		$_vars = array(
			'baseurl'                  => $this->getBaseUrl(),
			'modulename'               => $this->module->name,
			'moduledir'                => _PS_MODULE_DIR_,
			'modulepath'               => _PS_MODULE_DIR_.'/'.$this->module->name,
			'app'                      => $current_object,
			'app_info'                 => $app_info,
			'app_code'                 => $app_code,
			'advance_settings'         => $advance_settings,
			'cms_settings'             => $cms_settings,
			'social_icons'             => $social_icons,
			'push_notification'        => $push_notification,
			'analyticsSettings'        => $googleanalytics,
			'code_personalizer_parent' => $code_personalizer_parent,
			'code_personalizer_child'  => $code_personalizer_child,
			'languages'                => $languages,
			"categories"               => $categories,
			"currentTab"               => $this->tab_display,
			//"attribute_groups"         => $attribute_groups,
			"front_features"		   => $front_features,
			"http_host"                => $_SERVER ['HTTP_HOST'],
			"module_default_wishlist"  => true,//(Module::isInstalled('blockwishlist') ? true : false),
			);
		//echo '<pre>';print_r($_vars);exit;
		$_vars = array_merge($_vars, $this->tpl_form_vars);
		
		$this->context->smarty->assign($_vars);
		return $this->module->display($this->path, 'views/templates/admin/editapplication.tpl');
	}

	public function postProcess()
	{
		if (Tools::isSubmit ('updateApp'))
		{
			$this->checkUpdateApplication();
		    if (!empty($this->errors))
		    {
		        $this->display = 'edit';
		        $this->tab_display = Tools::getValue('updateApp');
		        return false;
		    }

		    $processes = array(
		    	'AdvanceSettings',
		    	'CMSContents',
		    	'GeneralSettings',
		    	'GoogleAnalytics',
		    	'HomePageWidgets',
		    	'PushNotifications',
		    	'Colorscheme'
		    	);
		    foreach($processes as $process_action)
		    {
		    	$this->{'postProcess' . $process_action} ();
		    }

			$this->display = 'edit';
		}
	}

	protected function checkUpdateApplication()
	{
		/* general settings */
		if(isset($_FILES['app_info']['name']['app_share_image']) && !empty($_FILES['app_info']['name']['app_share_image']))
		{
			$ext = Tools::strtolower(PATHINFO($_FILES['app_info']['name']['app_share_image'], PATHINFO_EXTENSION));
			if(!in_array($ext, array('jpg','gif','png','jpeg')))
			{
				$this->errors[] = sprintf(
		        	Tools::displayError('This app share image image field is requires file with jpg, gif, png, jpeg extension only')
		          	);
			}
		}
		
		if(isset($_FILES['pushnotification']['name']['upload_iospem_file']) && !empty($_FILES['pushnotification']['name']['upload_iospem_file']))
		{
			$ext = Tools::strtolower(PATHINFO($_FILES['pushnotification']['name']['upload_iospem_file'], PATHINFO_EXTENSION));
			if(!in_array($ext, array('pem'))){
				$this->errors[] = sprintf(
		        	Tools::displayError('This ios pem file field is requires file with pem extension only')
		          	);
			}
		}
		/* general settings - upto here */

		/* check for push settings */
		if(Tools::getValue('pushheading') || Tools::getValue('pushnotifications') || (isset($_FILES['pushfile']['name']) && !empty($_FILES['pushfile']['name'])))
		{
			if(Tools::getValue('pushheading') == '')
			{
				$this->errors[] = sprintf(
		        	Tools::displayError('This pushnotification heading field is required')
		          	);
			}
			if(Tools::getValue('pushnotifications') == '')
			{
				$this->errors[] = sprintf(
		        	Tools::displayError('This pushnotification message field is required')
		          	);
			}

			if(isset($_FILES['pushfile']['name']) && !empty($_FILES['pushfile']['name']))
			{
				$ext = Tools::strtolower(PATHINFO($_FILES['pushfile']['name'], PATHINFO_EXTENSION));
				if(!in_array($ext, array('jpg','gif','png','jpeg'))){
					$this->errors[] = sprintf(
			        	Tools::displayError('This pushnotification image field is requires file with jpg, gif, png, jpeg extension only')
			          	);
				}
			}
		}
		/* check for push settings - upto here */

		/* push notifications */
		if(isset($_FILES['pushfile']['name']) && !empty($_FILES['pushfile']['name'])){
			$ext = Tools::strtolower(PATHINFO($_FILES['pushfile']['name'], PATHINFO_EXTENSION));
			if(!in_array($ext, array('jpg','gif','png','jpeg')))
			{
				$this->errors[] = sprintf(
		        	Tools::displayError('This push file field is requires file with jpg, gif, png, jpeg extension only')
		          	);
			}
		}
		/* push notifications - upto here */
	}

	public function postProcessHomePageWidgets()
	{
		if (Tools::isSubmit('widgetAdd'))
		{
			if(Tools::getValue('widgetType'))
			{
				$this->{'postProcessAddWidget' . Tools::getValue('widgetType')} ();
			}
		}

		/**
		 * update widget position
		 */
		if(Tools::getValue('widget_position_list'))
		{
			$current_object = $this->loadObject(true);
			$current_object->updateWidgetPosition(Tools::getValue('widget_position_list'));
		}
	}

	public function postProcessAddWidgetcategory()
	{
		if (isset ( $_POST ['widget']['name'] ) && empty ( $_POST ['widget']['name'] ))
		{
			$this->errors [] = Tools::DisplayError ( 'Please enter name' );
		}
		
		if (! isset ( $_POST ['categoryBox'] ) && count ( $_POST ['categoryBox'] ) == 0)
		{
			$this->errors [] = Tools::DisplayError ( 'Please select category' );
		}
		
		if (count ( $this->errors ) == 0)
		{
			$current_object = $this->loadObject(true);
			if (Tools::getValue('widget_id'))
			{
				$current_object->updateCategoryWidget($_POST, $current_object);
			}
			else
			{
				if ($current_object->addCategoryWidget($_POST, $current_object))
				{
				
				}
				else
				{
					$this->errors[] = Tools::DisplayError('Error in widget Add');
				}
			}
			if (isset ( $_POST ['widget'] ['widget_category_id'] ) && ! empty ( $_POST ['widget'] ['widget_category_id'] ))
			{
				$this->redirect_after = $this->context->link->getAdminLink ( 'MCCategoryWidget' ) . "&lang=" . $_POST ['widget'] ['lang_id'] . "&id_category=" . $_POST ['widget'] ['widget_category_id'];
			}
		}
	}
	
	public function postProcessAddWidgetimage()
	{
		if (isset ( $_POST ['widget'] ['name'] ) && empty ( $_POST ['widget'] ['name'] ))
		{
			$this->errors [] = Tools::DisplayError ( 'Please enter name' );
		}
		
		if (count ( $this->errors ) == 0)
		{
			$_POST ['widget'] ['widget_data'] ['widget_image'] = $_POST ['widget_image_hidden'];
			
			$current_object = $this->loadObject ( true );
			if (Tools::getValue('widget_id'))
			{
				$current_object->updateCategoryWidget ( $_POST, $current_object );
			}
			else
			{
				if ($current_object->addCategoryWidget ( $_POST, $current_object ))
				{
					// $this->sucess[]= Tools::DisplayError ('Error in widget Add');
				}
				else
				{
					$this->errors [] = Tools::DisplayError ( 'Error in widget Add' );
				}
			}
		}
		
		if (isset($_POST['widget']['widget_category_id']) && !empty($_POST ['widget'] ['widget_category_id']))
		{
			$this->redirect_after = $this->context->link->getAdminLink ( 'MCCategoryWidget' ) . "&lang=" . $_POST ['widget'] ['lang_id'] . "&id_category=" . $_POST ['widget'] ['widget_category_id'];
		}
	}

	public function postProcessAddWidgetimageSlider()
	{
		$current_object = $this->loadObject(true);
		if (isset($_POST['widget']['name']) && empty($_POST['widget']['name']))
		{
			$this->errors[] = Tools::DisplayError( 'Please enter name');
		}
		
		if (count ( $this->errors ) == 0)
		{
			if(isset($_POST['widget']['widget_category_id']) && !empty($_POST['widget']['widget_category_id']))
			{
				$media_path = _PS_MODULE_DIR_ . $this->module->name.'/media/mobi_commerce/category/';
			}
			else
			{
				$appCode = $current_object->app_code;
				$media_path = _PS_MODULE_DIR_ . $this->module->name.'/media/mobi_commerce/' . $appCode . '/home_banners/';
			}

			$allowed_files_arr = array (
				'jpg',
				'jpeg',
				'gif',
				'png' 
			);

			foreach($_FILES['banner']['name'] as $key => $files)
			{
				if (isset($files) && !empty($files))
				{
					$shareImagename = uniqid () . '.' . PATHINFO ( $files, PATHINFO_EXTENSION );
					
					$file_ext = PATHINFO ( $files, PATHINFO_EXTENSION );
					// changed by yash
					if (isset($_POST['widget']['widget_category_id']) && !empty($_POST['widget']['widget_category_id']))
					{
						$_POST['widget']['widget_data']['banners'][$key]['banner_url'] = $this->getBaseUrl() . 'modules/'.$this->module->name.'/media/mobi_commerce/category/' . $shareImagename;
					}
					else
					{
						$_POST['widget']['widget_data']['banners'][$key]['banner_url'] = $this->getBaseUrl() . 'modules/'.$this->module->name.'/media/mobi_commerce/' . ($current_object->app_code) . '/home_banners/' . $shareImagename;
					}
					
					if(!empty($_FILES['banner']['tmp_name'][$key]) && in_array(Tools::strtolower($file_ext), $allowed_files_arr))
					{
						$tmp_name = $_FILES["banner"]["tmp_name"][$key];
						if (!move_uploaded_file($tmp_name, "$media_path$shareImagename"))
						{
							$this->errors[] = Tools::DisplayError('Error in widget Image Upload');
						}
					}
				}
			}
			
			if (count($this->errors) == 0)
			{
				if(Tools::getValue('widget_id'))
				{
					$current_object->updateCategoryWidget($_POST, $current_object);
				}
				else
				{
					if($current_object->addCategoryWidget($_POST, $current_object))
					{
						// $this->sucess[]= Tools::DisplayError ('Error in widget Add');
					}
					else
					{
						$this->errors[] = Tools::DisplayError('Error in widget Add');
					}
				}
			}
		}
		
		if (isset($_POST['widget']['widget_category_id']) && !empty($_POST['widget']['widget_category_id']))
		{
			$this->redirect_after = $this->context->link->getAdminLink ( 'MCCategoryWidget' ) . "&lang=" . $_POST['widget']['lang_id'] . "&id_category=" . $_POST['widget']['widget_category_id'];
		}
	}

	public function postProcessAddWidgetproductSlider()
	{
		if(isset($_POST['widget']['name']) && empty($_POST['widget']['name']))
		{
			$this->errors[] = Tools::DisplayError('Please enter name');
		}
		
		if (isset ( $_POST ['widget'] ['widget_data'] ['productslider_type'] ) && empty ( $_POST ['widget'] ['widget_data'] ['productslider_type'] ))
		{
			$this->errors[] = Tools::DisplayError ( 'Please select slider Type' );
		}
		
		if (count ( $this->errors ) == 0)
		{	
			$current_object = $this->loadObject(true);
			if (Tools::getValue('widget_id'))
			{
				$current_object->updateCategoryWidget($_POST, $current_object);
			}
			else
			{
				if ($current_object->addCategoryWidget($_POST, $current_object))
				{
					// $this->sucess[]= Tools::DisplayError ('Error in widget Add');
				}
				else
				{
					$this->errors[] = Tools::DisplayError('Error in widget Add');
				}
			}
		}
		
		if (isset ($_POST['widget']['widget_category_id']) && !empty($_POST['widget']['widget_category_id']))
		{
			$this->redirect_after = $this->context->link->getAdminLink('MCCategoryWidget') . "&lang=" . $_POST['widget']['lang_id'] . "&id_category=" . $_POST['widget']['widget_category_id'];
		}
	}

	public function postProcessGeneralSettings()
	{
		$current_object = $this->loadObject(true);
		$appcode = Tools::getValue('appcode');

		// push notification
		$data = Tools::getValue('pushnotification');
		$file_attachment = Tools::fileAttachment('upload_iospem_file');
		if($file_attachment)
		{
			if($file_attachment['error'] == 0)
			{
				$media_path = _PS_MODULE_DIR_.$this->module->name.'/media/mobi_commerce/' . $appcode . '/appinfo/';
				$_image = uniqid ().'.'.PATHINFO ( $file_attachment['name'], PATHINFO_EXTENSION);
				move_uploaded_file($file_attachment['tmp_name'], $media_path.'/'.$_image);
			}
			$data['upload_iospem_file'] = $_image;
		}
		$current_object->updatePushSetting($data, $appcode);

		// appinfo
		$data = Tools::getValue('app_info');
		$file_attachment = Tools::fileAttachment('app_share_image');
		if($file_attachment)
		{
			if($file_attachment['error'] == 0)
			{
				$media_path = _PS_MODULE_DIR_.$this->module->name.'/media/mobi_commerce/' . $appcode . '/appinfo/';
				$_image = uniqid ().'.'.PATHINFO ( $file_attachment['name'], PATHINFO_EXTENSION);
				move_uploaded_file($file_attachment['tmp_name'], $media_path.'/'.$_image);
			}
			$data['app_share_image'] = $_image;
		}
		
		$current_object->updateAppinfo($data, $appcode);
	}

	public function postProcessCMSContents()
	{
		$current_object = $this->loadObject(true);
		
		$appcode = Tools::getValue('appcode');
		$data = Tools::getValue('cms_settings');
                
		// menu_icon
		$file_attachment = Tools::fileAttachment('menu_icon');
		if($file_attachment)
		{
			if($file_attachment['error'] == 0)
			{
				$dir_path = _PS_MODULE_DIR_.$this->module->name.'/';
				$media_path = 'media/mobi_commerce/' . $appcode . '/appinfo/';
				$_image = uniqid ().'.'.PATHINFO ( $file_attachment['name'], PATHINFO_EXTENSION);
				move_uploaded_file($file_attachment['tmp_name'], $dir_path  .$media_path . '/' . $_image);
			}
            $data['contact_information']['menu_icon'] = $media_path . $_image;
		}
                
		$_lang = Tools::getValue('cmslanguageSelected');
		$current_object->updateCMSContents($data, $appcode, $_lang);
	}

	public function postProcessGoogleAnalytics()
	{
		$current_object = $this->loadObject (true);
		$app_code = $current_object->app_code;
		$analyticsSettings = Tools::getValue('analyticsSettings');
		$current_object->updateGoogleAnalytics($analyticsSettings, $app_code);
	}

	public function postProcessColorscheme()
	{
		$current_object = $this->loadObject(true);
		$appcode = $current_object->app_code;
		$themename = Tools::getValue('themename');
		$personalizer = Tools::getValue('personalizer');

		$file_personalizer_parent = _PS_MODULE_DIR_ . $this->module->name.'/views/img/mobi_assets/v/3/theme_files/' . $themename . '/personalizer/personalizer.xml';
		$file_personalizer_child = _PS_MODULE_DIR_ . $this->module->name.'/media/mobi_commerce/' . $appcode . '/personalizer/personalizer.xml';

		$file_personalizer_css_child = _PS_MODULE_DIR_ . $this->module->name.'/media/mobi_commerce/'.$appcode.'/personalizer/personalizer.css';
			
		$xml_personalizer_child = new DOMDocument('1.0');
		$xml_personalizer_child->formatOutput = true;
		$root = $xml_personalizer_child->createElement('mobicommerce_personalizer');
		$root = $xml_personalizer_child->appendChild($root);
		
        foreach($personalizer as $personalizer_key => $personalizer_value)
        {
			$xml_personalizer_key = $xml_personalizer_child->createElement($personalizer_key);
			$new_xml_personalizer_child = $root->appendChild($xml_personalizer_key);
		    
			$current_value_key = $xml_personalizer_child->createElement('current_value');       
			$current_value = $xml_personalizer_child->createTextNode($personalizer_value);
			$current_value_key->appendChild($current_value);
			$new_xml_personalizer_child->appendChild($current_value_key);
		}
		$xml_personalizer_child->save($file_personalizer_child);

		//save css
		$css = array();
		if(file_exists($file_personalizer_parent))
		{
			$code_personalizer_parent = simplexml_load_file($file_personalizer_parent);
			foreach ($code_personalizer_parent as $option => $value)
			{
				if((string)$value->type == 'css')
				{
					$_color = isset($personalizer[$option]) ? $personalizer[$option] : '';
					$_css = (string)$value->css;
					$_css = str_replace('--COLOR--', $_color, $_css);
					$_css = implode("\r\n", explode('|', $_css));
					$css[] = $_css;
				}
			}
		}

		if(!empty($css))
		{
			file_put_contents($file_personalizer_css_child, implode("\r\n", $css));
		}
		//save css - upto here

		if(Tools::getValue('change_personalizer') == '1')
		{
			$url = 'http://build3.build.mobi-commerce.net/build/updatePersonalizer'; 
			$curldata = array(
				'appcode'      => $appcode,
				'appkey'       => Tools::getValue('appkey'),
				'personalizer' => array(
					'android_primary_theme'   => $personalizer['android_primary_theme'],
					'android_secondary_theme' => $personalizer['android_secondary_theme'],
					'ios_primary_theme'       => $personalizer['ios_primary_theme'],
					)
				);

			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_HEADER, FALSE);
			curl_setopt($ch, CURLOPT_NOBODY, TRUE);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT , 15); 
			curl_setopt($ch, CURLOPT_TIMEOUT, 15);
			curl_setopt($ch, CURLOPT_POST, count($curldata));
			curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($curldata));
			$result = curl_exec($ch);
			//$info = curl_getinfo($ch);
			curl_close($ch);
			//echo '<pre>';print_r($result);print_r($info);exit;
			$result = Tools::jsonDecode($result, TRUE);
			if($result['status'] == 'success')
			{
				$this->displayInformation($result['message']);
			}
			else
			{
				$this->errors[] = sprintf(
		        	Tools::displayError($result['message'])
		          	);
			}
		}
	}

	public function postProcessPushNotifications()
	{
		$current_object = $this->loadObject(true);
		$appcode = Tools::getValue('appcode');
		if(Tools::getValue('pushheading') && Tools::getValue('pushnotifications'))
		{
			$whom = Tools::getValue('whom');
			$sendto = '';
			$devices = array();

			switch ($whom)
			{
				case 'customer_group':
					$sendto = Tools::getValue('ids_customer_group');
					break;

				case 'specific_customer':
					$sendto = Tools::getValue('ids_customer');
					break;
				
				default:
					# code...
					break;
			}
			$sendto = implode(',', array_unique(array_filter(explode(',', $sendto))));
			//echo '<pre>';print_r($sendto);exit;
			$data = array(
				'appcode'        => $appcode,
				'date_submitted' => date('Y-m-d'),
				'store_id'       => (int) Tools::getValue('push_store_id'),
				'device_type'    => Tools::getValue('push_device_type'),
				'heading'        => Tools::getValue('pushheading'),
				'message'        => Tools::getValue('pushnotifications'),
				'deeplink'       => Tools::getValue('pushdeeplink'),
				'image'          => '',
				'send_to_type'   => $whom,
				'send_to'        => ','.$sendto.','
				);

			$imageurl = '';
			if(isset($_FILES['pushfile']['name']) && !empty($_FILES['pushfile']['name']))
			{
				$media_path = _PS_MODULE_DIR_ . $this->module->name.'/media/mobi_commerce/' . $appcode . '/pushnotification/';
				if(!file_exists($media_path))
				{
					mkdir($media_path, 0777, true);
				}

				$pushfile = uniqid().'.'.PATHINFO($_FILES ['pushfile']['name'], PATHINFO_EXTENSION);

				$tmp_name = $_FILES["pushfile"]["tmp_name"];
				if (!move_uploaded_file($tmp_name, "$media_path/$pushfile"))
				{
					
				}

	            $imageurl = $this->getBaseUrl().'modules/'.$this->module->name.'/media/mobi_commerce/'.$appcode.'/pushnotification/'.$pushfile;
			}

			$pushsizeArray = $pushparams;
			$pushsize = serialize($pushsizeArray);
			if (function_exists('mb_strlen'))
			{
			    $pushsize = mb_strlen($pushsize, '8bit');
			}
			else
			{
			    $pushsize = Tools::strlen($pushsize);
			}

			if($pushsize > 4096)
			{
				$this->errors[] = sprintf(
		        	Tools::displayError('Push notification size is '.$pushsize.' bytes. It should not be greater then 4096 bytes')
		          	);
			}
			else
			{
				$data['image'] = $imageurl;
				$current_object->savePushNotification($data);
			
				$pushparams = array(
					'heading'   => $data['heading'],
					'message'   => $data['message'],
					'deeplink'  => $data['deeplink'],
					'image_url' => $imageurl
					);

				$push_notification_obj = $current_object->getSettings ( $current_object->app_code, "push_notification");
				$pushNotificationData = Tools::unSerialize($push_notification_obj[0]['value']);
				if(!empty($pushNotificationData['upload_iospem_file']))
				{
					$pushNotificationData['upload_iospem_file'] = _PS_MODULE_DIR_ .$this->module->name. '/media/mobi_commerce/' . $appcode . '/appinfo/'.$pushNotificationData['upload_iospem_file'];
				}

				$sql = '';
				if(in_array($whom, array('customer_group', 'specific_customer')))
				{
					if($whom == 'specific_customer')
					{
						$sql = 'SELECT *
							FROM '._DB_PREFIX_.'mobicommerce_devicetokens WHERE md_userid IN ('.$sendto.')';
					}
					else if($whom == 'customer_group')
					{
						$sql = 'SELECT GROUP_CONCAT(c.id_customer) AS customers FROM '._DB_PREFIX_.'customer_group AS cg JOIN '._DB_PREFIX_.'customer AS c ON (c.id_customer = cg.id_customer) WHERE id_group IN ('.$send_to.')';
						$result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
						$customers = $result[0]['customers'];
						$sql = 'SELECT *
							FROM '._DB_PREFIX_.'mobicommerce_devicetokens WHERE md_userid IN ('.$customers.')';
					}
				}
				else
				{
					$sql = 'SELECT *
							FROM '._DB_PREFIX_.'mobicommerce_devicetokens';
				}

				$android_devices = array();
				$ios_devices = array();

				$device_collection = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
				
				if($device_collection)
				{
					foreach($device_collection as $_device)
					{
						if($_device['md_devicetype'] == 'android')
						{
							$android_devices[] = $_device['md_devicetoken'];
						}
						else if($_device['md_devicetype'] == 'ios')
						{
							$ios_devices[] = $_device['md_devicetoken'];
						}
					}
				}

				if($data['device_type'] == 'android')
				{
					$ios_devices = array();
				}
				if($data['device_type'] == 'ios')
				{
					$android_devices = array();
				}

				$this->androidpushnotification($pushparams, $pushNotificationData, $android_devices);
				$this->iospushnotification($pushparams, $pushNotificationData, $ios_devices);
			}
		}
	}

	public function androidpushnotification($pushparams, $pushdata, $devices = array())
	{
		$log = array();

		$android_key = $pushdata['android_key'];
		if(!empty($android_key) && !empty($devices) && !empty($pushparams['heading']) && !empty($pushparams['message']))
		{
			$msg = array(
				'message'  => $pushparams['message'],
				'title'    => $pushparams['heading'],
				'deeplink' => $pushparams['deeplink'],
				'imageurl' => $pushparams['image_url'],
				'vibrate'  => 1,
				'sound'    => 1,
				'notId'    => time()
			);

			$fields = array(
				'registration_ids' => $devices,
				'data'             => $msg
			);

			$headers = array(
				'Authorization: key=' . $android_key,
				'Content-Type: application/json'
			);
			
			$androidDevices = array_chunk($devices, 1000);

			foreach($androidDevices as $adevices)
			{
				$fields = array(
					'registration_ids' => $adevices,
					'data'             => $msg
				);
				
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL, 'https://android.googleapis.com/gcm/send' );
				curl_setopt($ch, CURLOPT_POST, true);
				curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($ch, CURLOPT_POSTFIELDS, Tools::jsonEncode($fields));
				$result = curl_exec($ch);
				curl_close($ch);

				$log[] = 'Android Msg array: ';
				$log[] = $msg;
				$log[] = 'Android List of devices: ';
				$log[] = $adevices;
				$log[] = 'Android google response';
				$log[] = $result;
			}
		}
		$this->printPushLog($log);
	}

	public function iospushnotification($pushparams, $pushdata, $devices = array())
	{
		$log = array();

		$sandboxmode = false;
		$passphrase = $pushdata ['pem_password'];
		$pemFile = $pushdata ['upload_iospem_file'];

		$log[] = 'iOS PEM file URL : '.$pemFile;
		if(file_exists($pemFile)) {
			$log[] = 'iOS PEM file Exists.';
		}
		else {
			$log[] = 'iOS PEM file Does not Exist.';
		}
		$log[] = 'iOS PEM Password : '.$passphrase;
		
		if (isset ( $pushdata ['sandboxmode'] ) && $pushdata ['sandboxmode'] == '1')
		{
			$sandboxmode = true;
		}

		$log[] = 'iOS Sandbox mode: '.($sandboxmode ? 'ON' : 'OFF');
		
		if (! empty ( $pemFile ) && ! empty ( $pushparams ['message'] ))
		{
			$ctx = stream_context_create ();
			stream_context_set_option ( $ctx, 'ssl', 'local_cert', $pemFile );
			stream_context_set_option ( $ctx, 'ssl', 'passphrase', $passphrase );
			
			// Open a connection to the APNS server
			$push_url = "ssl://gateway.push.apple.com:2195";
			if ($sandboxmode)
			{
				$push_url = "ssl://gateway.sandbox.push.apple.com:2195";
			}
			
			$log[] = 'iOS Push URL: '.$push_url;

			if(!empty($devices))
			{
				$fp = stream_socket_client(
					$push_url, $err,
					$errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);

				$log[] = "telnet gateway.push.apple.com 2195 command reply";
				$log[] = exec("telnet gateway.push.apple.com 2195", $a);

				if(!$fp)
				{
					$log[] = "Failed to connect: $err $errstr" . PHP_EOL;
					//return "Failed to connect: $err $errstr" . PHP_EOL;
				}
				else
				{
					$log[] = "iOS status connected";

					//echo 'Connected to APNS' . PHP_EOL;
					$body = array();
					$body['aps'] = array(
						//'alert'    => $pushparams['message'],
						'alert' => array('title' => $pushparams['heading'], 'body' => $pushparams['message']),
						'sound'    => 'default',
						'deeplink' => $pushparams['deeplink']
						);
					$payload = json_encode($body);
					
					$log[] = "Devices: ";
					$log[] = $devices;

					$iosDevices = array_chunk($devices, 10);
					foreach ($iosDevices as $_device) {
						$fp = stream_socket_client(
						$push_url, $err,
						$errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);
						
						$msg = "";
						foreach ($_device as $value) {
							$msg .= chr(0) . pack('n', 32) . pack('H*', $value) . pack('n', strlen($payload)) . $payload;
						}
						$result = fwrite($fp, $msg, strlen($msg));
						if(!$result){
							//echo 'Message not delivered' . PHP_EOL;
							$log[] = 'Message not delivered' . PHP_EOL;
						}
						else{
							//echo 'Message successfully delivered' . PHP_EOL;
							$log[] = 'Message successfully delivered' . PHP_EOL;
						}
						fclose($fp);
					}
				}
			}
		}
		$this->printPushLog($log);
	}

	public function printPushLog($log = array())
	{
		if(Configuration::get('MC_DEBUG_PUSHNOTIFICATION')) {
			d($log);
		}
	}

	public function postProcessAdvanceSettings()
	{
		$appcode = Tools::getValue('appcode');
		$data = Tools::getValue('advancesettings');

		$all_attributes = array();
		//$attributes = AttributeGroup::getAttributesGroups($this->current_lang);
		$front_features = Feature::getFeatures($this->current_lang);
		if($front_features)
		{
			foreach($front_features as $_attr)
			{
				$all_attributes[] = $_attr['id_feature'];
			}
		}

		if(!isset($data['productdetail']['showattribute']))
		{
			$data['productdetail']['showattribute'] = array();
		}

		$show_attributes = $data['productdetail']['showattribute'];
		$hidden_attributes = array_diff($all_attributes, $show_attributes);
		$data['productdetail']['showattribute'] = array_flip($hidden_attributes);

		if(!isset($data['productdetail']['showattribute_popup']))
		{
			$data['productdetail']['showattribute_popup'] = array();
		}
		$show_attributes = $data['productdetail']['showattribute_popup'];
		$hidden_attributes = array_diff($all_attributes, $show_attributes);
		$data['productdetail']['showattribute_popup'] = array_flip($hidden_attributes);
		
		$current_object = $this->loadObject(true);
		$current_object->updateAdvanceSettings($data, $appcode);

		$homepage_categories = Tools::getValue('homepage_categories');
		$homepage_categories = array_flip($homepage_categories);
		$current_object->updateHomepageCategories($homepage_categories, $appcode);
	}
	
	public function ajaxProcesslistHomepageWidget()
	{
		$current_object = $this->loadObject (true);
		$widgetLists = $current_object->getWidgetList($_POST, $current_object->app_code);
		$this->context->smarty->assign ( array (
			'moduledir'   => _PS_MODULE_DIR_,
			'app'         => $current_object,
			'widgetLists' => $widgetLists 
			));
		$this->context->smarty->assign($this->tpl_form_vars);
		$more = $this->module->display($this->path, 'views/templates/admin/listHomeWidget.tpl');
		die ($more);
	}

	public function ajaxProcesssendEmail()
	{
		$postData = $_POST;
		$from = $this->context->employee->firstname;
		
		$to = $postData ['emailid'];
		if ($postData ['templatetype'] == 'android')
		{	
			$templateName = 'mobicommerce_android_url';
			$templateVars = array (
				'{appurl}' => $postData ['appurl'],
				'{from}' => $from 
			);
		}
		else if($postData ['templatetype'] == 'ios')
		{	
			$templateName = 'mobicommerce_ios_url';
			$templateVars = array (
				'{appurl}' => $postData ['appurl'],
				'{from}' => $from 
			);
		}
		
		$subject = "Mobicommerce App URL";
		$langID = '1';
		
		if (Mail::Send ( $langID, $templateName, $subject, $templateVars, $to ))
		{
			echo "Successfully sent Email.";
		}
		else
		{
			echo "Unable to send email.";
		}
	}
	
	public function ajaxProcessaddHomepageWidget()
	{
		$current_object = $this->loadObject (true);
		$cat = "";
		$lang = Context::getContext()->cookie->id_lang;
		$appId = "";
		
		if (Tools::getValue('id'))
		{
			$appId = Tools::getValue('id');
		}

		$this->tpl_form_vars ['appId'] = $appId;
		
		if (Tools::getValue('lang_id'))
		{
			$lang = Tools::getValue('lang_id');
		}
		
		if (Tools::getValue('cat'))
		{
			$cat = Tools::getValue('cat');
		}
		
		$this->tpl_form_vars ['cat'] = $cat;
		$this->tpl_form_vars ['lang'] = $lang;
		
		$this->context->smarty->assign ( $this->tpl_form_vars );
		
		if (Tools::getValue('widget_id'))
		{
			$widgetData = $current_object->getWidgetData (Tools::getValue('widget_id'), $cat );
			$widgetCode = $widgetData ['widget_code'];
		}
		
		$this->context->smarty->assign ( array (
			'widget_id'   => Tools::getValue('widget_id'),
			'widget_code' => $widgetCode,
			'app'         => $current_object 
			));
		$more = $this->module->display ( $this->path, 'views/templates/admin/addHomeWidget.tpl' );
		die ( $more );
	}
	
	public function ajaxProcessdeleteHomepageWidget()
	{
		$current_object = $this->loadObject (true);
		$this->context->smarty->assign($this->tpl_form_vars);
		$cat = Tools::getValue('cat', '');
		$current_object->deleteWidget(Tools::getValue('widget_id'), $cat);
	}
	
	public function ajaxProcessuploadWidgetimage()
	{
		if (0 < $_FILES ['file'] ['error'])
		{
			echo 'Error: ' . $_FILES ['file'] ['error'] . '<br>';
		}
		else
		{	
			if (Tools::getValue('cat'))
			{
				$media_path = _PS_MODULE_DIR_ .$this->module->name. '/media/mobi_commerce/category/widget_image';
				$media_url = '../modules/'.$this->module->name.'/media/mobi_commerce/category/widget_image/';
			}
			else
			{
				$current_object = $this->loadObject ( true );
				$appCode = $current_object->app_code;
				$media_path = _PS_MODULE_DIR_ .$this->module->name. '/media/mobi_commerce/' . $appCode . '/widget_image';
				$media_url = '../modules/'.$this->module->name.'/media/mobi_commerce/' . $appCode . '/widget_image/';
			}
			
			$allowed_files_arr = array (
				'jpg',
				'jpeg',
				'gif',
				'png' 
				);

			if(!file_exists($media_path))
			{
				mkdir($media_path, 0777, true);
			}
			
			$shareImagename = uniqid () . '.' . PATHINFO ( $_FILES ['file'] ['name'], PATHINFO_EXTENSION );
			$file_ext = PATHINFO ( $_FILES ['file'] ['name'], PATHINFO_EXTENSION );
			
			if (! empty ( $_FILES ['file'] ['tmp_name'] ) && in_array ( $file_ext, $allowed_files_arr ))
			{
				$tmp_name = $_FILES ["file"] ["tmp_name"];
				if (move_uploaded_file ( $tmp_name, "$media_path/$shareImagename" ))
				{
					$media_url .= $shareImagename;
					$response ['image_url'] = $media_url;
					echo Tools::jsonEncode($response);
				}
				else
				{
					echo 'Error: Error in uploading, Please try Again...<br>';
				}
			}
		}
	}
	
	public function ajaxProcessimageMap()
	{
		$this->content_only = false;
		$this->context->smarty->assign($this->tpl_form_vars);
		$this->context->smarty->assign (array(
			'moduledir' => __PS_BASE_URI__ . 'modules/',
			'_request' => $_REQUEST
		));
		
		$more = $this->module->display($this->path, 'views/templates/admin/widget/image/imagemap.tpl');
		die ($more);
	}
	
	public function ajaxProcessgetHomepageWidgetForm()
	{
		$current_object = $this->loadObject(true);
		$widgetData = $selectedCategoryArr = array ();
		if (Tools::getValue('widget_id')) {
			$cat = "";
			if (Tools::getValue('cat')) {
				$cat = Tools::getValue('cat');
			}
			$widgetDataArr = $current_object->getWidgetData(Tools::getValue('widget_id'), $cat);
			if (Tools::getValue('cat'))
			{
				$path = '../modules/'.$this->module->name.'/media/mobi_commerce/category/';
			}
			else
			{	
				$this->tpl_form_vars ['app'] = $current_object;
				$app_code = $widgetDataArr ['widget_app_code'];
				$path = '../modules/'.$this->module->name.'/media/mobi_commerce/' . $app_code . '/home_banners/';
			}
			$widgetData = Tools::unSerialize($widgetDataArr ['widget_data']);
			if (Tools::getValue('widget_code') == 'widget_category')
			{
				$selectedCategoryArr = $widgetData ['categories'];
			}
		}
		
		if (Tools::getValue('cat'))
		{
			$cat = Tools::getValue('cat');
			$category = Tools::getValue ( 'category', $cat );
		}
		else
		{
			$cat = "";
			$category = Tools::getValue ( 'category', Category::getRootCategory ()->id );
		}

		$this->tpl_form_vars ['cat'] = $cat;
		$lang = "";
		if (Tools::getValue('lang_id'))
		{
			$lang = Tools::getValue('lang_id');
		}
		$this->tpl_form_vars ['lang'] = $lang;
		$selected = Tools::getValue ( 'selected', $selectedCategoryArr );
		
		if(isset($selected) && !empty($selected))
		{
			$_selected = Tools::jsonDecode($selected, true);
			if(!empty($_selected))
			{
				$selected = array(); 
				foreach($_selected as $_key => $_sel)
				{
					$selected[] = $_key;
				}
			}
		}

		$_name = 'subtree_associated_categories_widget_new';
		if(Tools::getValue('widget_id'))
		{
			$_name = 'subtree_associated_categories_widget_'.Tools::getValue('widget_id');
		}

		if(empty($selected))
		{
			$selected = array();
		}
		
		$categories = new HelperTreeCategories($_name, null, (int)$category, null, false);
		$categories
			->setRootCategory($category)
			->setSelectedCategories($selected)
			->setUseSearch(false)
			->setInputName('categoryBox')
			->setUseCheckBox(true);
			
		if(in_array(_PS_VERSION_, array('1.6.0.6', '1.6.0.8', '1.6.0.9', '1.6.0.11', '1.6.0.14')))
		{
			
		}
		else
		{
			$categories
				->setFullTree(true)
				->setChildrenOnly(true);
		}
		
		$widget_image = $map_coords = $map_href = '';
		if (Tools::getValue('widget_code') == 'widget_image')
		{
			$image_widget_data = Tools::unSerialize( $widgetDataArr ['widget_data'] );
			$widget_image = $image_widget_data ['widget_image'];
			$mapcode = $image_widget_data ['mapcode'];
			
			$map_coords = array ();
			$map_href = array ();
			$matches = explode ( '<area', htmlspecialchars_decode ( $mapcode ) );
			if (! empty ( $matches ))
			{
				for($i = 0; $i < (count ( $matches ) - 1); $i ++)
				{
					$_match = $matches [$i];
					if (! empty ( $_match ))
					{
						$start = strpos ( $_match, 'coords="' );
						$end = strpos ( $_match, '" title=' );
						if ($start !== FALSE && $end !== FALSE)
						{
							$href_start = strpos ( $_match, 'href="' );
							$href_end = strpos ( $_match, '" target=' );
							
							$map_coords [] = Tools::substr ( $_match, $start + 8, $end - 8 - $start );
							$map_href [] = Tools::substr ( $_match, $href_start + 6, $href_end - 6 - $href_start );
						}
					}
				}
			}
			$map_coords = array_unique ( $map_coords );
			$map_href = array_unique ( $map_href );
			
			$map_coords = implode ( '__SEPRATER__', $map_coords );
			$map_href = implode ( '__SEPRATER__', $map_href );
		}

		$this->context->smarty->assign ( array (
			'moduledir'     => _PS_MODULE_DIR_,
			'app'           => $current_object,
			'categories'    => $categories,
			'widgetData'    => $widgetData,
			'widgetDataArr' => $widgetDataArr,
			'widget_id'     => Tools::getValue('widget_id'),
			'map_coords'    => $map_coords,
			'map_href'      => $map_href,
			'widget_image'  => $widget_image,
			'path'          => $path 
		));
		
		$this->context->smarty->assign ( $this->tpl_form_vars );
		
		switch (Tools::getValue('widget_code'))
		{
			case "widget_image_slider" :
				$more = $this->module->display ( $this->path, 'views/templates/admin/widget/imageSlider.tpl' );
				break;
			case "widget_category" :
				$more = $this->module->display ( $this->path, 'views/templates/admin/widget/category.tpl' );
				break;
			case "widget_product_slider" :
				$more = $this->module->display ( $this->path, 'views/templates/admin/widget/productSlider.tpl' );
				break;
			case "widget_image" :
				$more = $this->module->display ( $this->path, 'views/templates/admin/widget/image.tpl' );
				break;
		}
		
		echo $more;
	}

	public function ajaxProcesslinkwidget()
	{
		parent::setMedia();
		$cat = Tools::getValue('cat');
		$this->context->smarty->assign ( array (
			'moduledir' => _PS_MODULE_DIR_,
			'bannerid'  => $_GET ['bannerid'],
			'cat'       => $cat 
			));
		
		$more = $this->module->display ($this->path, 'views/templates/admin/widget/deeplink/link.tpl' );
		echo $more;
	}

	public function ajaxProcessgetlinkData()
	{
		$current_object = $this->loadObject ( true );
		
		$this->context->smarty->assign ( array (
			'moduledir' => _PS_MODULE_DIR_,
			'app' => $current_object 
			));
		
		switch (Tools::getValue('link_type'))
		{
			case "product" :
				$pageno = Tools::getValue('pn', 1);
				$pagesize = Tools::getValue('ps', 5);
				$query = Tools::getValue('q', '');
				$default_oderby = "name";
				$default_odertype = "asc";
				
				if (Tools::getValue('cat'))
				{
					$products = $this->find ( $this->current_lang, $query, Tools::getValue('cat'), $pageno, $pagesize, $default_oderby, $default_odertype );
				}
				else
				{
					$products = $this->find ( $this->current_lang, $query, false, $pageno, $pagesize, $default_oderby, $default_odertype );
				}
				
				$tumbPath = "home" . PIC_NAME_SUFFIX;
				$totalRecords = $products ['total'];
				$totalPages = ( int ) ($products ['total'] / $pagesize);
				if ($products ['total'] % $pagesize)
				{
					$totalPages ++;
				}
					
				$this->context->smarty->assign ( array (
					'products'     => $products ['result'],
					'totalPages'   => $totalPages,
					'totalRecords' => $totalRecords,
					"currentPage"  => $pageno,
					"tumbPath"     => $tumbPath,
					"pageSize"     => $pagesize,
					"q"            => $query 
					));
				$more = $this->module->display ( $this->path, 'views/templates/admin/widget/deeplink/product.tpl' );
				break;
			case "category" :
				if (Tools::getValue('cat'))
				{
					$category = Tools::getValue('category', Tools::getValue('cat'));
				}
				else
				{
					$category = Tools::getValue('category', Category::getRootCategory()->id);
				}

				$categories = new HelperTreeCategories ('id_parent');
				$selected = array();
				
				$categories
					->setRootCategory($category)
					->setSelectedCategories($selected)
					->setUseSearch($false)
					->setInputName('id_parent')
					->setUseCheckBox($use_check_box);
					
				if(in_array(_PS_VERSION_, array('1.6.0.6', '1.6.0.8', '1.6.0.9', '1.6.0.11', '1.6.0.14')))
				{
					
				}
				else
				{
					$categories
						->setFullTree(true)
						->setChildrenOnly(true);
				}

				$this->context->smarty->assign ( array (
					'categories' => $categories 
				) );
				$more = $this->module->display ( $this->path, 'views/templates/admin/widget/deeplink/category.tpl' );
				break;
			case "cms" :
				$more = $this->module->display ( $this->path, 'views/templates/admin/widget/deeplink/cms.tpl' );
				break;
			case "phone" :
				$more = $this->module->display ( $this->path, 'views/templates/admin/widget/deeplink/phone.tpl' );
				break;
			case "email" :
				$more = $this->module->display ( $this->path, 'views/templates/admin/widget/deeplink/email.tpl' );
				break;
			case "external" :
				$more = $this->module->display ( $this->path, 'views/templates/admin/widget/deeplink/external.tpl' );
				break;
		}
		
		echo $more;
	}

	protected function getProductImage($name, $ids, $type = null)
	{
		$url = $this->link->getImageLink ( $name, $ids, $type . PIC_NAME_SUFFIX );
		if (strpos ( $url, 'http' ) === false)
		{
			$url = _PS_BASE_URL_ . DIRECTORY_SEPARATOR . $url;
		}
		
		return $url;
	}

	public function ajaxProcessproductgrid()
	{
		$default_oderby = "name";
		$default_odertype = "asc";
		
		$pageno = Tools::getValue('pn', 1);
		$pagesize = Tools::getValue('ps', 10);
		$query = Tools::getValue('q', '');
		
		if (Tools::getValue('cat'))
		{
			$products = $this->find ( $this->current_lang, $query, Tools::getValue('cat'), $pageno, $pagesize, $default_oderby, $default_odertype );
		}
		else
		{
			$products = $this->find ( $this->current_lang, $query, false, $pageno, $pagesize, $default_oderby, $default_odertype );
		}
		
		$tumbPath = "home" . PIC_NAME_SUFFIX;
		$totalRecords = $products ['total'];
		$totalPages = ( int ) ($products ['total'] / $pagesize);
		if ($products ['total'] % $pagesize)
			$totalPages ++;			
		
		$current_object = $this->loadObject ( true );
		$widgetDataArr = $current_object->getWidgetData (Tools::getValue('widget_id'));
		$widgetData = Tools::unSerialize($widgetDataArr ['widget_data']);
		$selectedProductArr = $widgetData ['products'];
		if(!is_array($selectedProductArr))
		{
			$selectedProductArr = Tools::jsonDecode($selectedProductArr, true);
		}

		if(Tools::getValue('checked_products'))
		{
			$checked_products = Tools::unSerialize(Tools::getValue('checked_products'));
			if(!empty($checked_products))
			{
				foreach($checked_products as $_key => $_value)
				{
					$selectedProductArr[$_key] = $_value;
				}
			}
		}

		$this->context->smarty->assign ( array (
			'products'           => $products['result'],
			'totalPages'         => $totalPages,
			'totalRecords'       => $totalRecords,
			"currentPage"        => $pageno,
			"tumbPath"           => $tumbPath,
			"pageSize"           => $pagesize,
			"q"                  => $query,
			'selectedProductArr' => $selectedProductArr 
			));
		
		$more = $this->module->display($this->path, 'views/templates/admin/widget/list/product.tpl');
		echo $more;
	}

	public function ajaxProcesscheckproduct()
	{
		$checked_products = Tools::unSerialize(Tools::getValue('checked_products'));
		if(Tools::getValue('checked') == '1')
		{
			$checked_products[Tools::getValue('productid')] = Tools::getValue('prod_position');
		}
		else if(isset($checked_products[Tools::getValue('productid')]))
		{
			unset($checked_products[Tools::getValue('productid')]);
		}
		echo serialize($checked_products);
	}

	public function ajaxProcesssaveprodposition()
	{
		$productid = Tools::getValue('productid');
		$productpos = Tools::getValue('prod_position');
		$products = Tools::unSerialize(Tools::getValue('checked_products'));
		
		if (array_key_exists ( $productid, $products ))
		{
			unset ( $products [$productid] );
			$products [$productid] = $productpos;
		}
		$response = $products;
		echo serialize ( $response );
	}

	public function ajaxProcesschangeWidgetPosition()
	{
		$current_object = $this->loadObject ( true );
		$flag = $current_object->changePosition ( Tools::getValue('widget_id'), Tools::getValue('position'), Tools::getValue('type'));
		if ($flag)
		{
			echo "1";
		}
		else
		{
			echo "0";
		}
	}

	public static function find($id_lang, $expr, $cat = false, $page_number = 1, $page_size = 1, $order_by = 'position', $order_way = 'desc', $ajax = false, $use_cookie = true, Context $context = null)
	{
		if (! $context)
			$context = Context::getContext ();
		$db = Db::getInstance ( _PS_USE_SQL_SLAVE_ );
		
		// TODO : smart page management
		if ($page_number < 1)
			$page_number = 1;
		if ($page_size < 1)
			$page_size = 1;
		
		if (! Validate::isOrderBy ( $order_by ) || ! Validate::isOrderWay ( $order_way ))
			return false;
		
		$intersect_array = array ();
		$score_array = array ();
		$words = explode ( ' ', Search::sanitize ( $expr, $id_lang, false, $context->language->iso_code ) );
		
		foreach ( $words as $key => $word )
			if (! empty ( $word )) {
				$word = str_replace ( '%', '\\%', $word );
				$word = str_replace ( '_', '\\_', $word );
				$start_search = Configuration::get ( 'PS_SEARCH_START' ) ? '%' : '';
				$end_search = Configuration::get ( 'PS_SEARCH_END' ) ? '' : '%';
				
				$intersect_array [] = 'SELECT si.id_product
					FROM ' . _DB_PREFIX_ . 'search_word sw
					LEFT JOIN ' . _DB_PREFIX_ . 'search_index si ON sw.id_word = si.id_word
					WHERE sw.id_lang = ' . ( int ) $id_lang . '
						AND sw.id_shop = ' . $context->shop->id . '
						AND sw.word LIKE
					' . ($word [0] == '-' ? ' \'' . $start_search . pSQL ( Tools::substr ( $word, 1, PS_SEARCH_MAX_WORD_LENGTH ) ) . $end_search . '\'' : ' \'' . $start_search . pSQL ( Tools::substr ( $word, 0, PS_SEARCH_MAX_WORD_LENGTH ) ) . $end_search . '\'');
				
				if ($word [0] != '-')
					$score_array [] = 'sw.word LIKE \'' . $start_search . pSQL ( Tools::substr ( $word, 0, PS_SEARCH_MAX_WORD_LENGTH ) ) . $end_search . '\'';
			} else
				unset ( $words [$key] );
			
			/*
		 * if (!count($words))
		 * return ($ajax ? array() : array('total' => 0, 'result' => array()));
		 */
		$score = '';
		if (is_array ( $score_array ) && ! empty ( $score_array ))
			$score = ',(
				SELECT SUM(weight)
				FROM ' . _DB_PREFIX_ . 'search_word sw
				LEFT JOIN ' . _DB_PREFIX_ . 'search_index si ON sw.id_word = si.id_word
				WHERE sw.id_lang = ' . ( int ) $id_lang . '
					AND sw.id_shop = ' . $context->shop->id . '
					AND si.id_product = p.id_product
					AND (' . implode ( ' OR ', $score_array ) . ')
			) position';
		
		$sql_groups = '';
		if (Group::isFeatureActive ()) {
			$groups = FrontController::getCurrentCustomerGroups ();
			$sql_groups = 'AND cg.`id_group` ' . (count ( $groups ) ? 'IN (' . implode ( ',', $groups ) . ')' : '= 1');
		}
		
		// Added By Parvez
		$sqlCat = "";
		if ($cat) {
			$sqlCat = " AND c.`id_category`=" . $cat;
		}
		// End
		
		$results = $db->executeS ( '
			SELECT cp.`id_product`
			FROM `' . _DB_PREFIX_ . 'category_product` cp
			' . (Group::isFeatureActive () ? 'INNER JOIN `' . _DB_PREFIX_ . 'category_group` cg ON cp.`id_category` = cg.`id_category`' : '') . '
			INNER JOIN `' . _DB_PREFIX_ . 'category` c ON cp.`id_category` = c.`id_category`
			INNER JOIN `' . _DB_PREFIX_ . 'product` p ON cp.`id_product` = p.`id_product`
			' . Shop::addSqlAssociation ( 'product', 'p', false ) . '
			WHERE c.`active` = 1
			AND product_shop.`active` = 1
			AND product_shop.`visibility` IN ("both", "search")
			AND product_shop.indexed = 1
			' . $sql_groups . $sqlCat, true, false );
		
		$eligible_products = array ();
		foreach ( $results as $row )
			$eligible_products [] = $row ['id_product'];
		foreach ( $intersect_array as $query ) {
			$eligible_products2 = array ();
			foreach ( $db->executeS ( $query, true, false ) as $row )
				$eligible_products2 [] = $row ['id_product'];
			
			$eligible_products = array_intersect ( $eligible_products, $eligible_products2 );
			if (! count ( $eligible_products ))
				return ($ajax ? array () : array (
					'total' => 0,
					'result' => array () 
					));
		}
		
		$eligible_products = array_unique ( $eligible_products );
		
		$product_pool = '';
		foreach ( $eligible_products as $id_product )
			if ($id_product)
				$product_pool .= ( int ) $id_product . ',';
		if (empty ( $product_pool ))
			return ($ajax ? array () : array (
					'total' => 0,
					'result' => array () 
			));
		$product_pool = ((strpos ( $product_pool, ',' ) === false) ? (' = ' . ( int ) $product_pool . ' ') : (' IN (' . rtrim ( $product_pool, ',' ) . ') '));
		
		if ($ajax) {
			$sql = 'SELECT DISTINCT p.id_product, pl.name pname, cl.name cname,
						cl.link_rewrite crewrite, pl.link_rewrite prewrite ' . $score . '
					FROM ' . _DB_PREFIX_ . 'product p
					INNER JOIN `' . _DB_PREFIX_ . 'product_lang` pl ON (
						p.`id_product` = pl.`id_product`
						AND pl.`id_lang` = ' . ( int ) $id_lang . Shop::addSqlRestrictionOnLang ( 'pl' ) . '
					)
					' . Shop::addSqlAssociation ( 'product', 'p' ) . '
					INNER JOIN `' . _DB_PREFIX_ . 'category_lang` cl ON (
						product_shop.`id_category_default` = cl.`id_category`
						AND cl.`id_lang` = ' . ( int ) $id_lang . Shop::addSqlRestrictionOnLang ( 'cl' ) . '
					)
					WHERE p.`id_product` ' . $product_pool . '
					ORDER BY position DESC LIMIT 10';
			return $db->executeS ( $sql, true, false );
		}
		
		if (strpos ( $order_by, '.' ) > 0) {
			$order_by = explode ( '.', $order_by );
			$order_by = pSQL ( $order_by [0] ) . '.`' . pSQL ( $order_by [1] ) . '`';
		}
		$alias = '';
		if ($order_by == 'price')
			$alias = 'product_shop.';
		elseif (in_array ( $order_by, array (
			'date_upd',
			'date_add' 
			)))
		$alias = 'p.';
		
		$join_two_table = Combination::isFeatureActive ();
		$join_two_table = false;

		$sql = 'SELECT p.*, product_shop.*, stock.out_of_stock, IFNULL(stock.quantity, 0) as quantity,
				pl.`description_short`, pl.`available_now`, pl.`available_later`, pl.`link_rewrite`, pl.`name`
			 '.($join_two_table ? ',image_shop.`id_image` id_image, il.`legend`':'').', m.`name` manufacturer_name ' . $score . ',
				DATEDIFF(
					p.`date_add`,
					DATE_SUB(
						"' . date ( 'Y-m-d' ) . ' 00:00:00",
						INTERVAL ' . (Validate::isUnsignedInt ( Configuration::get ( 'PS_NB_DAYS_NEW_PRODUCT' ) ) ? Configuration::get ( 'PS_NB_DAYS_NEW_PRODUCT' ) : 20) . ' DAY
					)
				) > 0 new' . ($join_two_table ? ', product_attribute_shop.minimal_quantity AS product_attribute_minimal_quantity, IFNULL(product_attribute_shop.`id_product_attribute`,0) id_product_attribute' : '') . '
				FROM ' . _DB_PREFIX_ . 'product p
				' . Shop::addSqlAssociation ( 'product', 'p' ) . '
				INNER JOIN `' . _DB_PREFIX_ . 'product_lang` pl ON (
					p.`id_product` = pl.`id_product`
					AND pl.`id_lang` = ' . ( int ) $id_lang . Shop::addSqlRestrictionOnLang ( 'pl' ) . '
				)
				' . ($join_two_table ? 'LEFT JOIN `' . _DB_PREFIX_ . 'product_attribute_shop` product_attribute_shop
				ON (p.`id_product` = product_attribute_shop.`id_product` AND product_attribute_shop.`default_on` = 1 AND product_attribute_shop.id_shop=' . ( int ) $context->shop->id . ')' : '') . '
				' . Product::sqlStock ( 'p', 0 ) . '
				LEFT JOIN `' . _DB_PREFIX_ . 'manufacturer` m ON m.`id_manufacturer` = p.`id_manufacturer`'.
				($join_two_table ? '
				LEFT JOIN `' . _DB_PREFIX_ . 'image_shop` image_shop
					ON (image_shop.`id_product` = p.`id_product` AND image_shop.cover=1 AND image_shop.id_shop=' . ( int ) $context->shop->id . ')
				LEFT JOIN `' . _DB_PREFIX_ . 'image_lang` il ON (image_shop.`id_image` = il.`id_image` AND il.`id_lang` = ' . ( int ) $id_lang . ')
				':'').'
				WHERE p.`id_product` ' . $product_pool . '
				GROUP BY product_shop.id_product
				' . ($order_by ? 'ORDER BY  ' . $alias . $order_by : '') . ($order_way ? ' ' . $order_way : '') . '
				LIMIT ' . ( int ) (($page_number - 1) * $page_size) . ',' . ( int ) $page_size;
		$result = $db->executeS ( $sql, true, false );
		//echo $sql;exit;
		$sql = 'SELECT COUNT(*)
				FROM ' . _DB_PREFIX_ . 'product p
				' . Shop::addSqlAssociation ( 'product', 'p' ) . '
				INNER JOIN `' . _DB_PREFIX_ . 'product_lang` pl ON (
					p.`id_product` = pl.`id_product`
					AND pl.`id_lang` = ' . ( int ) $id_lang . Shop::addSqlRestrictionOnLang ( 'pl' ) . '
				)
				LEFT JOIN `' . _DB_PREFIX_ . 'manufacturer` m ON m.`id_manufacturer` = p.`id_manufacturer`
				WHERE p.`id_product` ' . $product_pool;
		
		$total = $db->getValue ($sql, false);

		if (! $result)
			$result_properties = false;
		else
			$result_properties = Product::getProductsProperties ( ( int ) $id_lang, $result );
		
		return array (
			'total'  => $total,
			'result' => $result_properties 
			);
	}

	public function ajaxProcessgetCustomerGroup()
	{
		$filter_id = Tools::getValue('filter_id');
		$filter_name = Tools::getValue('filter_name');
		$ids_customer_group = Tools::getValue('ids_customer_group');
		$p = Tools::getValue('p', 1);
		$l = Tools::getValue('l', 10);

		$p = $p - 1;

		$lang_id = Tools::getValue('lang_id');
		//$groups = Group::getGroups($lang_id);

		$where = array();
		if($filter_id)
		{
			$where[] = 'g.id_group = "'.$filter_id.'"';
		}
		if($filter_name)
		{
			$where[] = 'gl.name LIKE "%'.$filter_name.'%"';	
		}

		if($where)
		{
			$where = 'WHERE '.implode(' AND ', $where);
		}
		else
		{
			$where = '';
		}

		$sql = '
		SELECT DISTINCT g.`id_group`, g.`reduction`, g.`price_display_method`, gl.`name`
		FROM `'._DB_PREFIX_.'group` g
		LEFT JOIN `'._DB_PREFIX_.'group_lang` AS gl ON (g.`id_group` = gl.`id_group` AND gl.`id_lang` = '.(int)$lang_id.')
		'.$where.'
		ORDER BY g.`id_group` ASC';
		
		$total = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
		$total = count($total);

		$sql .= '
			LIMIT '.$p.', '.$l;

		$groups = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);

		$this->context->smarty->assign ( array (
			'filter_id'          => $filter_id,
			'filter_name'        => $filter_name,
			'ids_customer_group' => explode(',', $ids_customer_group),
			'groups'             => $groups,
			'total'				 => $total,
			'totalPages'		 => (int) ($total / $l)
			));

		$html = $this->module->display($this->path, 'views/templates/admin/widget/customergroup.tpl');
		echo $html;
	}

	public function ajaxProcessgetCustomer()
	{
		$filter_id = Tools::getValue('filter_id');
		$filter_firstname = Tools::getValue('filter_firstname');
		$filter_lastname = Tools::getValue('filter_lastname');
		$filter_email = Tools::getValue('filter_email');
		$ids_customer = Tools::getValue('ids_customer');
		$p = Tools::getValue('p', 1);
		$l = Tools::getValue('l', 10);

		$p = $p - 1;

		$lang_id = Tools::getValue('lang_id');

		$where = array();
		if($filter_id)
		{
			$where[] = 'id_customer = "'.$filter_id.'"';
		}
		if($filter_firstname)
		{
			$where[] = 'firstname LIKE "%'.$filter_firstname.'%"';
		}
		if($filter_lastname)
		{
			$where[] = 'lastname LIKE "%'.$filter_lastname.'%"';
		}
		if($filter_email)
		{
			$where[] = 'email LIKE "%'.$filter_email.'%"';
		}

		if($where)
		{
			$where = 'WHERE '.implode(' AND ', $where);
		}
		else
		{
			$where = '';
		}

		$sql = 'SELECT `id_customer`, `email`, `firstname`, `lastname`
				FROM `'._DB_PREFIX_.'customer`
				'.$where.'
				ORDER BY `id_customer` ASC';
		
		$total = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
		$total = count($total);

		$sql .= '
			LIMIT '.$p.', '.$l;

		$customers = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);

		$this->context->smarty->assign ( array (
			'filter_id'        => $filter_id,
			'filter_firstname' => $filter_firstname,
			'filter_lastname'  => $filter_lastname,
			'filter_email'     => $filter_email,
			'ids_customer'     => explode(',', $ids_customer),
			'customers'        => $customers,
			'total'            => $total,
			'totalPages'       => (int) ($total / $l)
			));

		$html = $this->module->display($this->path, 'views/templates/admin/widget/customer.tpl');
		echo $html;
	}

	/**
	 * addded by yash
	 * added on 2017-12-18
	 */
	public function addNewAddedTabs()
	{
		$parentTabId = Tab::getIdFromClassName('AdminMobicommerce3');
		$tabsToInstall = array(
			0 => array(
				'class_name' => 'MCPushHistory',
				'label' => 'Push Notifications History',
				),
			1 => array(
				'class_name' => 'MCDeviceTokens',
				'label' => 'Device Tokens',
				),
			2 => array(
				'class_name' => 'MCConfiguration',
				'label' => 'Configuration',
				),
			);

		$module = Module::getInstanceByName('mobicommerce3');
		foreach($tabsToInstall as $_tab) {
			if(!Tab::getIdFromClassName($_tab['class_name'])) {
				$module->installModuleTab($_tab['class_name'], $_tab['label'], $parentTabId);
			}
		}
	}
}
