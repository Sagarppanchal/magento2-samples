<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

include_once(dirname(__FILE__).'/../../classes/MCSocialLogin.php');
include_once (dirname ( __FILE__ ) . '/MCAbstract.php');
class MCSocialLoginController extends MCAbstract {
    
    public $bootstrap = true;
    public $module;
    public $position;

    protected $tab_display;
    protected $tab_display_module;
    protected $current_lang;


    protected $available_tabs = array();
    protected $default_tab = 'Facebook';
    protected $available_tabs_lang = array();

	public function __construct()
    {
        $this->lang = (!isset($this->context->cookie) || !is_object($this->context->cookie)) ? (int)(Configuration::get('PS_LANG_DEFAULT')) : (int)($this->context->cookie->id_lang);

        parent::__construct();

        $this->available_tabs_lang = array(
            'Facebook' => $this->l('Facebook'),
            'Google' => $this->l('Google'),
            );

        $this->available_tabs = array(
            'Facebook' => 0,
            'Google'   => 1,
          );
    }

    public function initProcess()
    {
        if (!isset($_GET['action']))
        {
            parent::initProcess();
        }
        else
        {
            $this->id_object = (int)Tools::getValue($this->identifier);
        }

        if (isset($this->available_tabs[Tools::getValue('key_tab')]))
        {
            $this->tab_display = Tools::getValue('key_tab');
        }
        
        if (!$this->tab_display && Tools::getValue('action'))
        {
            if (in_array(Tools::getValue('action'), array_keys($this->available_tabs)))
            {
                $this->tab_display = Tools::getValue('action');
            }
        }
        if (!$this->tab_display)
        {
            if (in_array($this->default_tab, $this->available_tabs))
            {
                $this->tab_display = $this->default_tab;
            }
            else
            {
                $this->tab_display = key($this->available_tabs);
            }
        }
    }

    public function setMedia()
    {
        parent::setMedia();
            $this->addjQueryPlugin(array(
                'validate',
            ));
         $this->addCSS(_PS_MODULE_DIR_.$this->module->name.'/views/css/admin/main.css');
    }

    public function initContent($token = null)
    {
        $this->fields_form = array();   
        if ($this->ajax)
        {
            if(Tools::getValue('ajax') == 1)
            {
                $this->content_only = true;
                $this->{'ajaxProcess'.Tools::getValue('action')}();
            }
            
            $this->content_only = true;
        }
        else
        {
            $product_tabs = array();
            foreach ($this->available_tabs as $product_tab => $value)
            {
                $product_tabs[$product_tab] = array(
                    'id'       => $product_tab,
                    'selected' => (Tools::strtolower($product_tab) == Tools::strtolower($this->tab_display) || (isset($this->tab_display_module) && 'module'.$this->tab_display_module == Tools::strtolower($product_tab))),
                    'name'     => $this->available_tabs_lang[$product_tab],
                    //'href'     => self::$currentIndex.'&id='.(int)Tools::getValue('id').'&updatemobicommerce_applications&token='.$this->token,
                    );
            }
            
            $this->tpl_form_vars['product_tabs'] = $product_tabs;
            parent::initContent();
        }
    }

    public function display()
    {
        parent::display();
    }

    public function postProcess()
    {
        if (Tools::isSubmit('submitSocialLogins'))
        {
            $sociallogin_is_active = $_POST['sociallogin']['isactive'];
            
            $mobi_fb_active = $_POST['sociallogin']['facebook']['isactive'];
            $mobi_fb_title = $_POST['sociallogin']['facebook']['title'];
            $mobi_fb_appid = $_POST['sociallogin']['facebook']['appid'];
            $mobi_fb_appname = $_POST['sociallogin']['facebook']['appname'];
            $mobi_fb_sortorder = $_POST['sociallogin']['facebook']['sortorder'];
            Configuration::updateValue('mobi3_fb_active', $mobi_fb_active);
            Configuration::updateValue('mobi3_fb_title', $mobi_fb_title);
            Configuration::updateValue('mobi3_fb_appid', $mobi_fb_appid);
            Configuration::updateValue('mobi3_fb_appname', $mobi_fb_appname);
            Configuration::updateValue('mobi3_fb_sortorder', $mobi_fb_sortorder);

            $mobi_go_active = $_POST['sociallogin']['google']['isactive'];
            $mobi_go_clientid = $_POST['sociallogin']['google']['clientid'];
            $mobi_go_title = $_POST['sociallogin']['google']['title'];
            $mobi_go_sha1key = $_POST['sociallogin']['google']['sha1key'];
            $mobi_go_sortorder = $_POST['sociallogin']['google']['sortorder'];
            Configuration::updateValue('mobi3_go_active', $mobi_go_active);
            Configuration::updateValue('mobi3_go_title', $mobi_go_title);
            Configuration::updateValue('mobi3_go_clientid', $mobi_go_clientid);
            Configuration::updateValue('mobi3_go_sha1key', $mobi_go_sha1key);
            Configuration::updateValue('mobi3_go_sortorder', $mobi_go_sortorder);
        } 
    }

    public function renderList()
    {
        $this->tpl_form_vars['tabs_preloaded'] = $this->available_tabs;
        
        $this->tpl_form_vars['mobi_fb_active'] = Configuration::get('mobi3_fb_active');
        $this->tpl_form_vars['mobi_fb_title'] = Configuration::get('mobi3_fb_title');
        $this->tpl_form_vars['mobi_fb_appid'] = Configuration::get('mobi3_fb_appid');
        $this->tpl_form_vars['mobi_fb_appname'] = Configuration::get('mobi3_fb_appname');
        $this->tpl_form_vars['mobi_fb_sortorder'] = Configuration::get('mobi3_fb_sortorder');
        
        $this->tpl_form_vars['mobi_go_active'] = Configuration::get('mobi3_go_active');
        $this->tpl_form_vars['mobi_go_title'] = Configuration::get('mobi3_go_title');
        $this->tpl_form_vars['mobi_go_clientid'] = Configuration::get('mobi3_go_clientid');
        $this->tpl_form_vars['mobi_go_sha1key'] = Configuration::get('mobi3_go_sha1key');
        $this->tpl_form_vars['mobi_go_sortorder'] = Configuration::get('mobi3_go_sortorder');

        $this->context->smarty->assign($this->tpl_form_vars);
        return $this->context->smarty->fetch(_PS_MODULE_DIR_.$this->module->name.'/views/templates/admin/sociallogin.tpl');
    }    
}
