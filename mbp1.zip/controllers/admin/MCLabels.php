<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

include_once (dirname ( __FILE__ ) . '/MCAbstract.php');
class MCLabelsController extends MCAbstract
{    
    public $bootstrap = true;
    public $module;
    
    /**
	 * @var string name of the tab to display
	 */
	protected $tab_display;
	protected $tab_display_module;
    protected $current_lang;
    /**
	 * The order in the array decides the order in the list of tab. If an element's value is a number, it will be preloaded.
	 * The tabs are preloaded from the smallest to the highest number.
	 * @var array Product tabs.
	 */
	protected $available_tabs = array();
	protected $default_tab = 'Labels';
	protected $available_tabs_lang = array();
    
	public function __construct()
	{
        $this->explicitSelect = true;
        $this->context = Context::getContext();
        $this->path = _MODULE_DIR_.$this->module->name;
        
        $this->bootstrap = true;
        $this->lang = false;
        $this->default_form_language = $this->context->language->id;
        
        $this->identifier = "id"; 
        $this->tpl_folder = 'labelsandmessages'; 
      
        parent::__construct();
        
        $this->available_tabs_lang = array(
            'Labels'   => $this->l('Labels'),
            'Messages' => $this->l('Messages'),
    		);

		$this->available_tabs = array();
		$this->available_tabs = array_merge($this->available_tabs, array(
            'Labels'   => 0,
            'Messages' => 1,
		  ));
	}
    
    public function setMedia()
    {
        parent::setMedia();
            $this->addjQueryPlugin(array(
				'validate',
			));
         $this->addCSS(_PS_MODULE_DIR_.$this->module->name.'/views/css/admin/main.css');
    }
    
    public function initProcess()
    {
        if (!isset($_GET['action']))
			parent::initProcess();
		else
			$this->id_object = (int)Tools::getValue($this->identifier);

		if (isset($this->available_tabs[Tools::getValue('key_tab')]))
			$this->tab_display = Tools::getValue('key_tab');
        
		if (!$this->tab_display && isset($_GET['action']))
            if (in_array(Tools::getValue('action'), array_keys($this->available_tabs)))
			{
                $this->tab_display = Tools::getValue('action');
            }

		if (!$this->tab_display)
		{
			if (in_array($this->default_tab, $this->available_tabs))
				$this->tab_display = $this->default_tab;
			else
				$this->tab_display = key($this->available_tabs);
		}
    }
    
    public function initContent($token = null)
    {
        $this->fields_form = array();	
		if ($this->ajax)
        {
            if(Tools::getValue('ajax') == 1)
            {
                $this->content_only = true;
                $this->{'ajaxProcess'.Tools::getValue('action')}();
            }
            
            $this->content_only = true;
        }
		else
		{
			$product_tabs = array();
			foreach ($this->available_tabs as $product_tab => $value)
			{
                $product_tabs[$product_tab] = array(
                    'id'       => $product_tab,
                    'selected' => (Tools::strtolower($product_tab) == Tools::strtolower($this->tab_display) || (isset($this->tab_display_module) && 'module'.$this->tab_display_module == Tools::strtolower($product_tab))),
                    'name'     => $this->available_tabs_lang[$product_tab],
                    'href'     => self::$currentIndex.'&id='.(int)Tools::getValue('id').'&updatemobicommerce_applications&token='.$this->token,
					);
			}
			$this->tpl_form_vars['product_tabs'] = $product_tabs;
            parent::initContent();
		}
    }  
    
    public function renderList()
    {
        $languages = Language::getLanguages();
        $this->current_lang = $languages[0]['id_lang'];
        $this->tpl_form_vars['tabs_preloaded'] = $this->available_tabs;
        
        if(Tools::getValue('lang')){
            $this->current_lang = Tools::getValue('lang');
        }

        $langDetails = Language::getLanguage($this->current_lang);
        $locale = $langDetails['iso_code'];

        $this->setLanguageCodeData($locale);
        $labels = $this->getLanguageData($locale);
        
        $sel_tab = 'labels';
        if(Tools::getValue('sel_tab'))
            $sel_tab = Tools::getValue('sel_tab'); 
        elseif(Tools::getValue('sel_lab_tab'))  
            $sel_tab = Tools::getValue('sel_lab_tab'); 
        elseif(Tools::getValue('sel_mes_tab'))  
            $sel_tab = Tools::getValue('sel_mes_tab');                                


        $_vars = array(
            'modulename' => $this->module->name,
            'moduledir'  => _PS_MODULE_DIR_,
            'modulepath' => _PS_MODULE_DIR_.'/'.$this->module->name,
            'labels'     => $labels,
            'locale'     => $locale,
            'languages'  => $languages,
            "lang"       => $this->current_lang,
            "sel_tab"    => $sel_tab,
            );
        $_vars = array_merge($_vars, $this->tpl_form_vars);
        $this->context->smarty->assign($_vars);

        return $this->module->display(_PS_MODULE_DIR_.$this->module->name.DIRECTORY_SEPARATOR.$this->module->name.'.php', 'views/templates/admin/labelsandmessages.tpl');
    }
      
    public function postProcess()
    {
        if (Tools::isSubmit('updateLabels'))
        {
            $this->{'postProcessLabels'}();
        }
    }
    
    public function postProcessLabels()
    {
        $languageData = Tools::getValue('language_data');
        $locale = Tools::getValue('locale');
        $xml =_PS_MODULE_DIR_.$this->module->name.'/views/img/mobi_assets/multilanguage/'.$locale.'.xml';
        $xmldata = simplexml_load_file($xml);

        $childxml = _PS_MODULE_DIR_.$this->module->name.'/media/mobi_commerce/multilanguage/'.$locale.'.xml';
        $doc = new DOMDocument('1.0');
        $doc->formatOutput = true;
        $root = $doc->createElement('mobicommerce_multilanguage');
        $root = $doc->appendChild($root);
        
        foreach($xmldata as $_key => $_data){
        	$optioncodenode = $doc->createElement($_key);
            $newdoc = $root->appendChild($optioncodenode);
        
            $em = $doc->createElement('mm_text');
            $text = $doc->createTextNode(isset($languageData[$_key]) ? $languageData[$_key] : $_data->mm_text);
            $em->appendChild($text);
            $newdoc->appendChild($em);
        }
        $doc->save($childxml);
        $this->current_lang = $_POST['lang_selectd'];
    }
    
    public function setLanguageCodeData($locale)
	{
		if($locale != 'en' && !file_exists(_PS_MODULE_DIR_.$this->module->name.'/views/img/mobi_assets/multilanguage/'.$locale.'.xml'))
			@copy(_PS_MODULE_DIR_.$this->module->name.'/views/img/mobi_assets/multilanguage/en.xml', _PS_MODULE_DIR_.$this->module->name.'/views/img/mobi_assets/multilanguage/'.$locale.'.xml');

		$xml = _PS_MODULE_DIR_.$this->module->name.'/media/mobi_commerce/multilanguage/'.$locale.'.xml';
		if(!file_exists($xml)){
			if(!file_exists(_PS_MODULE_DIR_.$this->module->name.'/media/mobi_commerce/multilanguage/'))
				mkdir(_PS_MODULE_DIR_.$this->module->name.'/media/mobi_commerce/multilanguage/', 0755);

			if(file_exists(_PS_MODULE_DIR_.$this->module->name.'/views/img/mobi_assets/multilanguage/'.$locale.'.xml')){
				@copy(_PS_MODULE_DIR_.$this->module->name.'/views/img/mobi_assets/multilanguage/'.$locale.'.xml', _PS_MODULE_DIR_.$this->module->name.'/media/mobi_commerce/multilanguage/'.$locale.'.xml');
			}
			else
				@copy(PS_MODULE_DIR_.$this->module->name.'/views/img/mobi_assets/multilanguage/'.$locale.'.xml', PS_MODULE_DIR_.$this->module->name.'/media/mobi_commerce/multilanguage/'.$locale.'.xml');
		}
	}

	public function getLanguageData($locale)
	{
        if($locale != 'en' && !file_exists(_PS_MODULE_DIR_.$this->module->name.'/views/img/mobi_assets/multilanguage/'.$locale.'.xml'))
			@copy(_PS_MODULE_DIR_.$this->module->name.'/views/img/mobi_assets/multilanguage/en.xml', _PS_MODULE_DIR_.$this->module->name.'/views/img/mobi_assets/multilanguage/'.$locale.'.xml');
        
        $this->setLanguageCodeData($locale);
		$labels = array();

		$xml = _PS_MODULE_DIR_.$this->module->name.'/views/img/mobi_assets/multilanguage/'.$locale.'.xml';
        $xmldata = simplexml_load_file($xml);
        foreach($xmldata as $_key => $_data){
        	$labels[$_key] = (array)$_data;
        }

        $childxml = _PS_MODULE_DIR_.$this->module->name.'/media/mobi_commerce/multilanguage/'.$locale.'.xml';
        $childxmldata = simplexml_load_file($childxml);
        foreach($childxmldata as $_key => $_data){
        	if(array_key_exists($_key, $labels)){
        		$labels[$_key]['mm_text'] = (string)$_data->mm_text;
        	}
        }

		return $labels;
	}
}
