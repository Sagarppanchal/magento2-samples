<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

include_once (dirname ( __FILE__ ) . '/../../classes/MCPushHistory.php');

class MCPushHistoryController extends ModuleAdminController
{
	protected $position_identifier = 'id';
	protected $identifier = 'id';

	public function __construct()
    {
        $this->bootstrap = true;
        $this->table = 'mobicommerce_pushhistory';
        $this->identifier = 'id';
        $this->className = 'MCPushHistory';
        $this->lang = false;
        $this->explicitSelect = false;
        $this->bulk_actions = array(
            'delete' => array(
                'text' => $this->l('Delete selected'),
                'icon' => 'icon-trash',
                'confirm' => $this->l('Delete selected items?')
            )
        );

        parent::__construct();

        //$this->imageType = 'jpg';
        $this->_defaultOrderBy = 'id';
        $this->_defaultOrderWay = 'DESC';
        $this->allow_export = false;

        // @since 1.5 : translations for tabs
        $this->available_tabs_lang = array(
            'Informations' => $this->l('Information'),
        );
        
        $this->_use_found_rows = false;
        $this->_group = '';

        $this->fields_list = array();
        $this->fields_list['id'] = array(
            'title' => $this->l('ID'),
            'align' => 'center',
            'class' => 'fixed-width-xs',
            'type' => 'int'
        );
        $this->fields_list['image'] = array(
            'title' => $this->l('Image'),
            'align' => 'center',
            'callback' => 'getPushImageGrid',
            'orderby' => false,
            'filter' => false,
            'search' => false
        );
        $this->fields_list['device_type'] = array(
            'title' => $this->l('Device Type'),
            'filter_key' => 'device_type',
            'type' => 'select',
            'callback' => 'getDeviceTypeOutput',
            'list' => $this->getDeviceType(),
        );
        $this->fields_list['heading'] = array(
            'title' => $this->l('Heading'),
            'align' => 'left',
            'orderby' => false,
        );

        $this->fields_list['send_to_type'] = array(
            'title' => $this->l('Send To'),
            'filter_key' => 'send_to_type',
            'type' => 'select',
            'callback' => 'getSentToTypeOutput',
            'list' => $this->getSentToType(),
        );

        $this->fields_list['date_submitted'] = array(
            'title' => $this->l('Sent On'),
            'align' => 'left',
            'type' => 'date',
            'filter_key' => 'date_submitted',
            'orderby' => true,
            'filter' => false,
            'search' => true
        );
        parent::__construct();
    }

    public function initPageHeaderToolbar()
    {
        parent::initPageHeaderToolbar();
        unset($this->toolbar_btn['new']);
    }

    public function renderView()
    {
        $object = $this->loadObject(true);
        $details = Db::getInstance()->executeS('
            SELECT * FROM '._DB_PREFIX_.$this->table.' WHERE '.$this->identifier.' = "'.$object->id.'"
            ');
        $details = $details[0];
        //d($details);
        //$deviceType = $this->getDeviceTypeOutput($details['device_type'], $details);
        $_sent_to = $details['send_to'];
        $_sent_to = implode(',', array_filter(explode(',', $_sent_to)));
        $sent_to_result = array();
        if(!empty($_sent_to)) {
            switch ($details['send_to_type']) {
                case 'customer_group':
                    $sent_to_result = Db::getInstance()->executeS('SELECT id_group AS id, name FROM '._DB_PREFIX_.'group_lang WHERE id_group IN ('.$_sent_to.') GROUP BY id_group');
                    break;

                case 'specific_customer':
                    $sent_to_result = Db::getInstance()->executeS('SELECT id_customer AS id, CONCAT(firstname, " ", lastname, " (", email, ")") AS name FROM '._DB_PREFIX_.'customer WHERE id_customer IN ('.$_sent_to.')');
                    # code...
                    break;
                
                default:
                    # code...
                    break;
            }
        }
        
        
        $this->context->smarty->assign(array(
            'details' => $details,
            'deviceType' => $this->getDeviceTypeOutput($details['device_type'], $details),
            'sentTo' => $this->getSentToTypeOutput($details['send_to_type'], $details),
            'sent_to_result' => $sent_to_result
            ));
        
        $tpl = $this->createTemplate('pushview.tpl');
        return $tpl->fetch();
    }

    public function renderList()
    {
        $this->addRowAction('view');
        $this->addRowAction('delete');
        return parent::renderList();
    }

    protected function getDeviceType()
    {
        return array(
            'both' => 'Both',
            'android' => 'Android',
            'ios' => 'iOS'
            );
    }

    protected function getSentToType()
    {
        return array(
            'all' => 'All',
            'customer_group' => 'Customer Group',
            'specific_customer' => 'Specific Customer'
            );
    }

    public function getDeviceTypeOutput($value, $object)
    {
        $array = $this->getDeviceType();
        return $array[$value];
    }

    public function getSentToTypeOutput($value, $object)
    {
        $array = $this->getSentToType();
        return $array[$value];
    }

    /**
     * comment this function if you need filter title in listing page
     */
    public function initToolbarTitle()
    {
        parent::initToolbarTitle();
        $bread_extended = $this->breadcrumbs;

        switch ($this->display) {
            case 'view':
                $bread_extended[] = $this->l('Push History ID: '.Tools::getValue('id'));
        }

        if (count($bread_extended) > 0) {
            $this->addMetaTitle($bread_extended[count($bread_extended) - 1]);
        }

        $this->toolbar_title = $bread_extended;
    }

    public function getPushImageGrid($value)
    {
        return '<img src="'.$value.'" alt="NA" height="25" />';
    }
}
