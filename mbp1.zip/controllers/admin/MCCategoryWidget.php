<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

include_once(dirname(__FILE__).'/../../classes/MCCategoryWidget.php');
//include_once(dirname(__FILE__).'/MCHomeWidget.php');

include_once (dirname ( __FILE__ ) . '/MCAbstract.php');
class MCCategoryWidgetController extends MCAbstract {

    public $bootstrap = true;
    public $module;
    protected $available_tabs_lang = array();

    public function __construct()
    {
        $this->addRowAction('edit'); //add an edit button
        $this->addRowAction('delete'); //add a delete button
        //$this->bulk_actions = array('delete' => array('text' => $this->l('Delete selected'), 'confirm' => $this->l('Delete selected items?')));
        $this->explicitSelect = true;
        $this->context = Context::getContext();
        $this->id_lang = $this->context->language->id;
        $this->path = _MODULE_DIR_.$this->module->name;
        
        $this->bootstrap = true;
        $this->lang = false;
        $this->default_form_language = $this->context->language->id;
        $this->table = 'mobicommerce_category_widget3'; //define the main table
        $this->className = 'MCCategoryWidgetObject'; //define the module entity
        $this->identifier = "widget_id"; //the primary key
        $this->list_id = 'mccategorywidget';
        $this->tpl_folder = 'mccategorywidget';
        parent::__construct();
    }
    
    public function setMedia()
    {
        parent::setMedia();
        $this->addjQueryPlugin(array(
                'validate'
            ));
        
        $this->addJS(array(
            _PS_JS_DIR_.'tiny_mce/tiny_mce.js',
            _PS_JS_DIR_.'admin/tinymce.inc.js',
            ));
        $this->addCSS(_PS_MODULE_DIR_.$this->module->name.'/views/css/admin/main.css');
    }
    
    public function initProcess()
    {
        if (!isset($_REQUEST['action']))
            parent::initProcess();
        else
            $this->id_object = (int)Tools::getValue($this->identifier);
    }
    
    public function initContent($token = null)
    {
        if ($this->display == 'edit' || $this->display == 'add')
        {
            $this->fields_form = array();
            if ($this->ajax || Tools::getValue('ajax') == 1)
                $this->content_only = true;
        }
        
        parent::initContent();
    }   
    
    public function postProcess()
    {
        /**
         * update widget position
         */
        if(isset($_POST['widget_position_list']) && !empty($_POST['widget_position_list'])){
            $current_object = $this->loadObject ( true );
            $current_object->updateWidgetPosition($_POST['widget_position_list'], 'category');
        }

        if (Tools::isSubmit('submitAddCategoryImage'))
        {
            $thumbnail_image = '';
            $banner_image = '';

            if(isset($_FILES['categoryImage']['name']) && !empty($_FILES['categoryImage']['name']))
            {
                $allowed_files_arr = array('jpg','jpeg','gif','png');
                $media_path = _PS_MODULE_DIR_.$this->module->name.'/media/mobi_commerce/category/';

                if(!file_exists(_PS_MODULE_DIR_.$this->module->name.'/media/mobi_commerce'))
                    @mkdir(_PS_MODULE_DIR_.$this->module->name.'/media/mobi_commerce', 0755);

                if(!file_exists(_PS_MODULE_DIR_.$this->module->name.'/media/mobi_commerce/category'))
                    @mkdir(_PS_MODULE_DIR_.$this->module->name.'/media/mobi_commerce/category', 0755);                

                $shareImagename = uniqid().'.'.PATHINFO($_FILES['categoryImage']['name'], PATHINFO_EXTENSION);
                $file_ext = PATHINFO($_FILES['categoryImage']['name'], PATHINFO_EXTENSION);

                if(!empty($_FILES['categoryImage']['tmp_name']) && in_array($file_ext,$allowed_files_arr))
                {
                    $tmp_name = $_FILES["categoryImage"]["tmp_name"];
                    if(!move_uploaded_file($tmp_name, $media_path.$shareImagename))
                    {
                        $this->errors[] = "Error in uploading";
                        //die($media_path.$shareImagename);
                    }
                    else
                    {
                        $current_object = $this->loadObject(true);
                        $thumbnail_image = $shareImagename;
                    }
                }
            }

            if(isset($_FILES['categoryBannerImage']['name']) && !empty($_FILES['categoryBannerImage']['name']))
            {
                $allowed_files_arr = array('jpg','jpeg','gif','png');
                $media_path = _PS_MODULE_DIR_.$this->module->name.'/media/mobi_commerce/category/';

                if(!file_exists(_PS_MODULE_DIR_.$this->module->name.'/media/mobi_commerce'))
                    @mkdir(_PS_MODULE_DIR_.$this->module->name.'/media/mobi_commerce', 0755);

                if(!file_exists(_PS_MODULE_DIR_.$this->module->name.'/media/mobi_commerce/category'))
                    @mkdir(_PS_MODULE_DIR_.$this->module->name.'/media/mobi_commerce/category', 0755);                

                $shareImagename = uniqid().'.'.PATHINFO($_FILES['categoryBannerImage']['name'], PATHINFO_EXTENSION);
                $file_ext = PATHINFO($_FILES['categoryBannerImage']['name'], PATHINFO_EXTENSION);

                if(!empty($_FILES['categoryBannerImage']['tmp_name']) && in_array($file_ext,$allowed_files_arr))
                {
                    $tmp_name = $_FILES["categoryBannerImage"]["tmp_name"];
                    if(!move_uploaded_file($tmp_name, $media_path.$shareImagename))
                    {
                        $this->errors[] = "Error in uploading";
                        //die($media_path.$shareImagename);
                    }
                    else
                    {
                        $current_object = $this->loadObject(true);
                        $banner_image = $shareImagename;
                    }
                }
            }

            if($current_object->saveImage($_POST, $thumbnail_image, $banner_image))
            {
                $this->confirmations[] = "Category Image Uploaded";
            }
            else
            {
                $this->errors[] = "Error in save image";
            }

            $this->redirect_after = $this->context->link->getAdminLink('MCCategoryWidget')."&lang=".Tools::getValue('languageSelected')."&id_category=".Tools::getValue('categoryBox');
        }
    }
    
    public function renderList()
    {
        $current_object = $this->loadObject(true);
        $languages = Language::getLanguages();
            $this->context->smarty->assign(array(
                'moduledir' => _PS_MODULE_DIR_,
                'app'       => $current_object,
                'languages' => $languages,
        ));

        if(Tools::getValue('lang'))
        {
            $lang = Tools::getValue('lang');
        }
        else
        {
            $lang = $languages[0]['id_lang'];
        }
       
        $this->fields_list = array(
            'widget_id'       => array('title' => $this->l('ID'), 'align' => 'center', 'class' => 'fixed-width-xs'),
            'widget_label'    => array('title' => $this->l('Lable'), 'width' => 'auto'),
            'widget_code'     => array('title' => $this->l('Widget Code'), 'maxlength' => 90, 'orderby' => false),
            'widget_position' => array('title' => $this->l('Position'), 'align' => 'center', 'class' => 'fixed-width-sm'),
            'widget_status' => array(
                'title' => $this->l('Displayed'), 'class' => 'fixed-width-sm', 'active' => 'widget_status',
                'align' => 'center','type' => 'bool', 'orderby' => false
              ));
        
        if(Tools::getValue('id_category'))
        {
            $cat = Tools::getValue('id_category');
            $selected = Tools::getValue('selected', array($cat));
            $widgetList = $current_object->getListCatWidget($cat);
            $widgetImage = $current_object->getCatWidgetImage($cat);
        }
        else
        {
            $cat = Category::getRootCategory()->id;
            $selected = Tools::getValue('selected', array($cat));
            $widgetList = $current_object->getListCatWidget($cat);
            $widgetImage = $current_object->getCatWidgetImage($cat);
        }

        $category = Tools::getValue('category', Category::getRootCategory()->id);
        $current_object = $this->loadObject(true);
        //$categories = new HelperTreeCategories('subtree_associated_categories');
        $categories = new HelperTreeCategories('subtree_associated_categories', null, (int)$category, null, false);
        $categories
            ->setUseCheckBox(false)
            ->setUseSearch(false)
            ->setSelectedCategories($selected)
            ->setRootCategory($category)
            ->setLang($lang);
        if(in_array(_PS_VERSION_, array('1.6.0.6', '1.6.0.8', '1.6.0.9', '1.6.0.11', '1.6.0.14')))
        {
            
        }
        else
        {
            $categories
                ->setFullTree(true)
                ->setChildrenOnly(true)
                ->setNoJS(false);
        }
        
        $path = '../modules/'.$this->module->name.'/media/mobi_commerce/category/';      
        $this->context->smarty->assign(array(
            'categories'  => $categories,
            "cat"         => $cat,
            "lang"        => $lang,
            "widgetList"  => $widgetList,
            "widgetImage" => $widgetImage,
            "path"        => $path
            ));
        
        $this->context->smarty->assign($this->tpl_form_vars);
        return $this->module->display(_PS_MODULE_DIR_.$this->module->name.DIRECTORY_SEPARATOR.$this->module->name.'.php',  'views/templates/admin/categorywidget/list.tpl');
    }
  
    public function ajaxProcessfetchCategories()
    {
        $selected = Tools::getValue('selected', array(5));
        $category = Tools::getValue('category', Category::getRootCategory()->id);
        $current_object = $this->loadObject(true);
        //$categories = new HelperTreeCategories('subtree_associated_categories');
        $categories = new HelperTreeCategories('subtree_associated_categories', null, (int)$category, null, false);
        $categories
            ->setUseCheckBox(false)
            ->setUseSearch(false)
            ->setSelectedCategories($selected)
            ->setRootCategory($category)
            ->setLang(Tools::getValue('lang_id'));
        if(in_array(_PS_VERSION_, array('1.6.0.6', '1.6.0.8', '1.6.0.9', '1.6.0.11', '1.6.0.14')))
        {
            
        }
        else
        {
            $categories
                ->setFullTree(true)
                ->setChildrenOnly(true)
                ->setNoJS(false);
        }
                
        $this->context->smarty->assign(array(
            'moduledir'  => _PS_MODULE_DIR_,
            'app'        => $current_object,
            'categories' => $categories,
            ));

        $more = $this->module->display(_PS_MODULE_DIR_.$this->module->name.DIRECTORY_SEPARATOR.$this->module->name.'.php', 'views/templates/admin/categorywidget/ajaxCatList.tpl');
        echo $more;
    }
}
