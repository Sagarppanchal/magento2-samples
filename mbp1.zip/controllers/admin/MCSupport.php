<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

include_once (dirname ( __FILE__ ) . '/MCAbstract.php');
class MCSupportController extends MCAbstract {
	
	public function __construct()
	{
		parent::__construct();
		header('Location: http://www.mobicommerce.net/support/');
	}
}
