<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

include_once (dirname ( __FILE__ ) . '/../../classes/MCDeviceTokens.php');

class MCDeviceTokensController extends ModuleAdminController
{
	protected $position_identifier = 'md_id';
	protected $identifier = 'md_id';

	public function __construct()
    {
        $this->bootstrap = true;
        $this->table = 'mobicommerce_devicetokens';
        $this->identifier = 'md_id';
        $this->className = 'MCDeviceTokens';
        $this->lang = false;
        $this->explicitSelect = false;
        $this->bulk_actions = array(
            'delete' => array(
                'text' => $this->l('Delete selected'),
                'icon' => 'icon-trash',
                'confirm' => $this->l('Delete selected items?')
            )
        );
        $this->list_no_link = true;

        parent::__construct();

        $this->_defaultOrderBy = 'md_id';
        $this->_defaultOrderWay = 'DESC';
        $this->allow_export = false;

        // @since 1.5 : translations for tabs
        $this->available_tabs_lang = array(
            'Informations' => $this->l('Information'),
        );
        
        $this->_use_found_rows = false;
        $this->_group = '';

        $this->_select .= 'cus.`email` AS `customer_email`, ';
        $this->_join .= '
        LEFT JOIN `'._DB_PREFIX_.'customer` cus ON (cus.`id_customer` = a.`md_userid`)';


        $this->_select .= 'lang.`name` AS `lang_name`, ';
        $this->_join .= '
        LEFT JOIN `'._DB_PREFIX_.'lang` lang ON (lang.`id_lang` = a.`md_store_id`)';

        $this->fields_list = array();
        $this->fields_list['md_id'] = array(
            'title' => $this->l('ID'),
            'align' => 'center',
            'class' => 'fixed-width-xs',
            'type' => 'int'
        );
        $this->fields_list['md_devicetype'] = array(
            'title' => $this->l('Device Type'),
            'filter_key' => 'md_devicetype',
            'type' => 'select',
            'callback' => 'getDeviceTypeOutput',
            'list' => $this->getDeviceType(),
        );
        $this->fields_list['md_devicetoken'] = array(
            'title' => $this->l('Token'),
            'align' => 'left',
            'orderby' => false,
        );

        $this->fields_list['customer_email'] = array(
            'title' => $this->l('User'),
            'filter_key' => 'cus!email',
            'align' => 'left',
            'orderby' => false,
        );

        $this->fields_list['lang_name'] = array(
            'title' => $this->l('Store'),
            'filter_key' => 'lang!name',
            'align' => 'left',
            'orderby' => false,
        );

        $this->fields_list['md_created_date'] = array(
            'title' => $this->l('Created On'),
            'align' => 'left',
            'type' => 'date',
            'orderby' => true,
            'filter' => false,
            'search' => true
        );

        $this->fields_list['md_enable_push'] = array(
            'title' => $this->l('Enabled ?'),
            'type' => 'bool',
            'active' => 'md_enable_push',
            'align' => 'center',
            'orderby' => false,
        );
        parent::__construct();
    }

    public function initPageHeaderToolbar()
    {
        parent::initPageHeaderToolbar();
        unset($this->toolbar_btn['new']);
    }

    public function renderList()
    {
        $this->addRowAction('delete');
        return parent::renderList();
    }

    protected function getDeviceType()
    {
        return array(
            'android' => 'Android',
            'ios' => 'iOS'
            );
    }

    public function getDeviceTypeOutput($value, $object)
    {
        $array = $this->getDeviceType();
        return $array[$value];
    }

    /**
     * comment this function if you need filter title in listing page
     */
    public function initToolbarTitle()
    {
        parent::initToolbarTitle();
        $bread_extended = $this->breadcrumbs;
        if (count($bread_extended) > 0) {
            $this->addMetaTitle($bread_extended[count($bread_extended) - 1]);
        }

        $this->toolbar_title = $bread_extended;
    }
}
