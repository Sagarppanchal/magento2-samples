<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

include_once(dirname(__FILE__).'/../../classes/MCNewApp.php');
include_once (dirname ( __FILE__ ) . '/MCAbstract.php');
class MCNewAppController extends MCAbstract {
	
	public function __construct()
	{
		$this->explicitSelect = true;
		$this->context = Context::getContext();
		$this->id_lang = $this->context->language->id;
		$this->bootstrap = true;
		$this->lang = false;
		$this->default_form_language = $this->context->language->id;
		$this->table = 'mobicommerce_applications3';
		
		$this->className = 'MCNewAppObject';
		$this->identifier = "id";

		parent::__construct();
	}

	public function setMedia()
	{
		parent::setMedia();
		$this->addjQueryPlugin(array(
			'validate'
			));

		$this->addCSS(_PS_MODULE_DIR_.$this->module->name.'/views/css/admin/main.css');
	}

	public function initContent()
	{
		$this->display = 'add';
		return parent::initContent();
	}

    public function renderForm()
	{
		$this->fields_form = array(
			'legend' => array(
				'title' => $this->l('Create App')
				),
			'input' => array(
				array('type' => 'hidden', 'name' => 'apptheme'),
				array('type' => 'hidden', 'name' => 'theme_android'),
				array('type' => 'hidden', 'name' => 'theme_ios'),

				array(
					'type'    => 'select',
					'label'   => $this->l("MobiCommerce Version")." :",
					'name'    => 'version_type',
					'options' => array(
					'query'   => array(
						array(
							'id_option' => '001',
							'name'      => 'Professional'
							),
						array(
							'id_option' => '002',
							'name'      => 'Enterprise'
							),
						),
						'id'   => 'id_option',
						'name' => 'name'
						),
					'required' => true,
					'hint'     => $this->l('Select MobiCommerce version which you want to use for your app.')
					),
				array(
					'type'     => 'text',
					'label'    => $this->l("App Name")." :",
					'name'     => 'appname',
					'size'     => 40,
					'required' => true,
					'col'      => 4,
					),
				array(
					'type'     => 'file',
					'label'    => $this->l('Splash Screen'),
					'name'     => 'appsplash',
					'hint'     => $this->l('(Height:2048, Width: 1536).'),
					'required' => false,
					'thumb'    => _MODULE_DIR_.$this->module->name."/views/img/mobi_assets/v/3/defaults/splash.png"
					),
				array(
					'type'     => 'file',
					'label'    => $this->l('Icon'),
					'name'     => 'appicon',
					'hint'     => $this->l('(Height:1024, Width: 1024).'),
					'required' => false,
					'thumb'    => _MODULE_DIR_.$this->module->name."/views/img/mobi_assets/v/3/defaults/icon.png"
					),
				array(
					'type'     => 'text',
					'label'    => $this->l('Email Address'),
					'name'     => 'email',
					'hint'     => $this->l('Don`t worry we do not spam or publish your email address, it will be solely used to create your MobiCommerce support account.'),
					'required' => true,
					'col'      => 4,
					),
				array(
					'type'     => 'text',
					'label'    => $this->l('Phone Country Code'),
					'name'     => 'phone_country_code',
					'hint'     => $this->l('Don`t worry we do not share your contact number with any third party, it will be solely used to create your MobiCommerce support account.'),
					'required' => true,
					'col'      => 4,
					),
				array(
					'type'     => 'text',
					'label'    => $this->l('Phone Number'),
					'name'     => 'phone',
					'hint'     => $this->l('Don`t worry we do not share your contact number with any third party, it will be solely used to create your MobiCommerce support account.'),
					'required' => true,
					'col'      => 4,
					),
				),
			);
        
		$this->fields_value['version_type']  = '002';
		$this->fields_value['appname']       = Configuration::get('PS_SHOP_NAME');
		$this->fields_value['email']         = $this->context->cookie->email;
		$this->fields_value['apptheme']      = 'shopper';
		$this->fields_value['theme_android'] = 'shopper';
		$this->fields_value['theme_ios']     = 'shopper';
            
		if (Shop::isFeatureActive()) {
			$this->fields_form['input'][] = array(
				'type'   => 'shop',
				'label'  => $this->l('Shop association:'),
				'name'   => 'app_storeid',
				'values' => Shop::getTree(),
				);
		}
		
		$this->fields_form['submit'] = array(
			'title' => $this->l('Create App'),
			);

		return parent::renderForm();
	}

	public function postProcess()
	{
		if (Tools::isSubmit('submitAdd'.$this->table))
		{
			$base_url = $this->getBaseUrl();
			$this->checkAddApplication();

			if (!empty($this->errors))
			{
				$this->display = '';
				return false;
			}

			$max_execution_time = ini_get('max_execution_time');
			if($max_execution_time != -1 && $max_execution_time < 300){
				ini_set('max_execution_time', 300);
			}
			$max_input_time = ini_get('max_input_time');
			if($max_input_time != -1 && $max_input_time < 300){
				ini_set('max_input_time', 300);
			}

			Context::getContext()->shop = Shop::initialize();

			$configurations = array(
				'connectorVersionCode'   => '90c4203d29f077997e7c4e11ce402a93d604dab6',
				'max_execution_time'     => ini_get('max_execution_time'),
				'max_input_time'         => ini_get('max_input_time'),
				'ipaddress'              => isset($_SERVER['REMOTE_ADDR'])?$_SERVER['REMOTE_ADDR']:'',
				'add_store_code_to_urls' => '0',
				'default_store_code'     => '',
				'mobicommerce_version'   => '3',
				);

			if(!count($this->errors))
			{
				$curlData          = $_POST;

				$media_path        = _PS_MODULE_DIR_. $this->module->name.'/media/mobi_commerce/';
				$mediaUrl          = $base_url.'modules/'.$this->module->name.'/media/mobi_commerce/';
				$mediaMobiAssetUrl = $base_url.'modules/'.$this->module->name.'/views/img/mobi_assets/v/3/defaults/';

				$images = array(
					"appsplash" => array(
						"w" => 1536,
						"h" => 2048
						),
					"appicon" => array(
						"w" => 1024,
						"h" => 1024
						)
					);

				foreach($images as $_image_name => $_image_size)
				{
					if(isset($_FILES[$_image_name]['name']) && !empty($_FILES[$_image_name]['name']))
					{
						try
						{
							$size = getimagesize($_FILES[$_image_name]['tmp_name']);
							if($size[0] != $_image_size['w'] || $size[1] != $_image_size['h'])
							{
								$this->errors[] = Tools::displayError(ucfirst($_image_name).' Icon dimenssion must be '.$_image_size['w'].'X'.$_image_size['h']);
							}

							if (!count($this->errors))
							{ 
								if (!is_dir($media_path))
								{
									mkdir($media_path, 0777, true);
								}

								if (is_dir($media_path) && !is_writable($media_path))
								{
									chmod($media_path, 0777);
								}
								
								$filename = uniqid().'.'.PATHINFO($_FILES[$_image_name]['name'], PATHINFO_EXTENSION);
								$tmpName = $media_path.'/'.$filename;
								if (!move_uploaded_file($_FILES[$_image_name]['tmp_name'], $tmpName))
									$this->errors[] = Tools::displayError('An error occurred during the '.$_image_name.' upload process.');
								else
								{
									$curlData[$_image_name] = $mediaUrl.$filename;    
								}
							}
						}
						catch(Exception $e){
							$this->errors[] = Tools::displayError($e->getMessage());
						}
					}
				}

				if(!isset($curlData['appsplash'])){
					$curlData['appsplash'] = $mediaMobiAssetUrl.'splash.png'; 
				}
				
				if(!isset($curlData['appicon'])){
					$curlData['appicon'] = $mediaMobiAssetUrl.'icon.png'; 
				}
			}    
			$curlData['primaryemail'] = $curlData['email'];
			$curlData['approoturl']   = $base_url;
			$curlData['media_url']    = $base_url.'modules/'.$this->module->name.'/media/';
			$curlData['applicencekey'] = '';
			$curlData['configurations'] = $configurations;
			$curlData['backend_platform'] = 'prestashop';

			$sql = 'SELECT * FROM '._DB_PREFIX_.'mobicommerce_licence';
			if ($results = Db::getInstance()->ExecuteS($sql)){
				foreach ($results as $row)
					$curlData['applicencekey'] = $row['ml_licence_key'];
			}
			else
				die('No licence key found');

			//echo "<pre>"; print_r($curlData);exit;

			$ch = curl_init();
			$url = 'http://build3.build.mobi-commerce.net/build/add'; 
			curl_setopt($ch, CURLOPT_HEADER, FALSE);
			curl_setopt($ch, CURLOPT_NOBODY, TRUE);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_POST, count($curlData));
			curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($curlData));
			$result = curl_exec($ch);
			curl_close($ch);
			$result = Tools::jsonDecode($result, true);

			if(isset($result['status']))
			{
				if($result['status'] == 'success')
				{
					$appid = null;
					if($result['data']['appcode'])
					{
						$data = array(
							"groupId"               => '1',
							"version_type"          => $curlData['version_type'],
							"app_name"              => $curlData['appname'],
							"app_code"              => $result['data']['appcode'],
							"app_preview_code"      => $result['data']['appkey'],
							"app_logo"              => '',//$curlData['applogo'],
							"app_theme_folder_name" => $curlData['apptheme'],
							"android_status"        => $result['data']['android_status'],
							"android_url"           => $result['data']['android_url'],
							"ios_status"            => $result['data']['ios_status'],
							"ios_url"               => $result['data']['ios_url'],
							"udid"                  => '',//$curlData['udid'],
							"app_license_key"       => $curlData['applicencekey'],
							"theme_android"         => 'shopper',
							"theme_ios"             => 'shopper',
							);

						$current_object = $this->loadObject(true);
						$appid = $current_object->createNewApp($data);
						$this->context->cookie->__set('redirect_errors', Tools::displayError($result['message']));
						Tools::redirectAdmin($this->context->link->getAdminLink('MCManageApp').'&id='.$appid.'&updatemobicommerce_applications3');
					}
					else
					{
						// app code not found from build mobi server
						$this->errors[] = Tools::displayError($result['message']);
						$this->display = '';
						return false;
					}
				//echo $result['message'];exit;
				// redirect to edit app page
				}
				else
				{
					$this->errors[] = Tools::displayError($result['message']);
					$this->display = '';
					return false;
				}
			}
			else
			{
				$this->errors[] = Tools::displayError("Oops, something wrong happned");
				$this->display = '';
				return false;
			}       
		}
	}

	protected function checkAddApplication()
	{
		if(!Tools::getValue('appname'))
		{
			$this->errors[] = sprintf(
				Tools::displayError('The appname field is required')
				);
		}

		if(!empty($_FILES))
		{
			$images = array(
				"appsplash" => "Splash",
				"appicon"   => "Icon",
				);

			foreach($images as $_image_name => $_image_label)
			{
				if($_FILES[$_image_name]['name'] != '' && Tools::strtolower(PATHINFO($_FILES[$_image_name]['name'], PATHINFO_EXTENSION)) != 'png')
				{
					$this->errors[] = sprintf(
						Tools::displayError($_image_label.' must be png')
						);
				}
			}

			$images = array(
				"appsplash" => array(
					"w" => 1536,
					"h" => 2048,
					"r" => null
					),
				"appicon" => array(
					"w" => 1024,
					"h" => 1024,
					"r" => null
					)
				);
			foreach($images as $_image_name => $_image_size)
			{
				if(isset($_FILES[$_image_name]['name']) && !empty($_FILES[$_image_name]['name']))
				{
					try
					{
						$size = getimagesize($_FILES[$_image_name]['tmp_name']);
						if($_image_size['w'] != null && $_image_size['h'] != null && ($size[0] != $_image_size['w'] || $size[1] != $_image_size['h']))
						{
							$this->errors[] = sprintf(
								Tools::displayError(ucfirst($_image_name).' Icon dimension must be '.$_image_size['w'].'X'.$_image_size['h'])
								);
						}

						// ratio for logo should be 1hx8w. Cannot be more then that
						if(!empty($_image_size['r']))
						{
							$r = explode('x',$_image_size['r']);
							$h = (int) $r[0];
							$w = (int) $r[1];
							$ratio = $h / $w;
							$iratio = $size[1] / $size[0];
							if($iratio < $ratio)
							{
								$this->errors[] = sprintf(
									Tools::displayError(ucfirst($_image_name).' Icon dimension must have ratio of '.$h.'X'.$w)
									);
							}
						}
					}
					catch(Exception $e)
					{
						$this->errors[] = sprintf(
							Tools::displayError($e->getMessage())
							);
					}
				}
			}

			if(!Tools::getValue('email'))
			{
				$this->errors[] = sprintf(
					Tools::displayError('This email field is required')
					);
			}
			else if (!filter_var(Tools::getValue('email'), FILTER_VALIDATE_EMAIL))
			{
				$this->errors[] = sprintf(
					Tools::displayError("This ".Tools::getValue('email')." email address is considered invalid.")
					);
			}

			if(!Tools::getValue('phone_country_code'))
			{
				$this->errors[] = sprintf(
					Tools::displayError('This phone country code field is required')
					);
			}

			if(!Tools::getValue('phone'))
			{
				$this->errors[] = sprintf(
					Tools::displayError('This phone field is required')
					);
			}
		}
	}
}
