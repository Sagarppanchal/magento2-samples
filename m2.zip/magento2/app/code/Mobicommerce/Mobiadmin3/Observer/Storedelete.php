<?php
/**
 * @author Mobicommerce Team
 * @copyright Copyright (c) 2018 Mobicommerce (https://www.mobicommerce.com)
 * @package Mobicommerce_Mobiadmin3
 */

namespace Mobicommerce\Mobiadmin3\Observer;

use Magento\Framework\Event\ObserverInterface;

class Storedelete implements ObserverInterface
{
    protected $_storeManager;

    /**
     * @var \Mobicommerce\Mobiadmin3\Model\Resource\Appsetting\CollectionFactory
     */
    protected $_mobiadmin3ResourceAppsettingCollectionFactory;

    /**
     * @var \Mobicommerce\Mobiadmin3\Model\Resource\Widget\CollectionFactory
     */
    protected $_mobiadmin3ResourceWidgetCollectionFactory;

    public function __construct(
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Mobicommerce\Mobiadmin3\Model\AppsettingFactory $mobiadmin3AppsettingFactory,
        \Mobicommerce\Mobiadmin3\Model\Resource\Appsetting\CollectionFactory $mobiadmin3ResourceAppsettingCollectionFactory,
        \Mobicommerce\Mobiadmin3\Model\Resource\Widget\CollectionFactory $mobiadmin3ResourceWidgetCollectionFactory
    ) {
        $this->_storeManager = $storeManager;
        $this->_mobiadmin3AppsettingFactory = $mobiadmin3AppsettingFactory;
        $this->_mobiadmin3ResourceAppsettingCollectionFactory = $mobiadmin3ResourceAppsettingCollectionFactory;
        $this->_mobiadmin3ResourceWidgetCollectionFactory = $mobiadmin3ResourceWidgetCollectionFactory;
    }

    /**
     * When deleting store view, all records for that store view will be deleted from following 2 tables
     * mobicommerce_applications_settings
     * mobi_app_widgets
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $store = $observer->getStore()->getId();
        if(!empty($store)){
            if(!empty($store)){
                /* for cms */
                $settings = ["cms_settings", "homepage_categories"];
                foreach($settings as $_setting){
                    $collection = $this->_mobiadmin3ResourceAppsettingCollectionFactory->create()->addFieldToFilter('setting_code', $_setting)
                        ->addFieldToFilter('storeid', $store);
                    if($collection->getSize()){
                        foreach($collection as $_collection){
                            $_collection->delete();
                        }
                    }
                }
                /* for cms - upto here */

                /* for widgets */
                $collection = $this->_mobiadmin3ResourceWidgetCollectionFactory->create()->addFieldToFilter('widget_store_id', $store);
                    
                if($collection->getSize()){
                    foreach($collection as $_collection){
                        $_collection->delete();
                    }
                }
                /* for widgets - upto here */
            }
        }
    }
}
