<?php
namespace Mobicommerce\Mobiadmin3\Controller\Adminhtml\Widget;

class Linktype extends \Magento\Backend\App\Action {

    /**
     * @var \Magento\Framework\App\Request\Http
     */
    protected $request;
    protected $_resultPageFactory;
    protected $resultJsonFactory;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Request\Http $request,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
    ) {
        $this->_resultPageFactory = $resultPageFactory;
        $this->request = $request;
        $this->resultJsonFactory = $resultJsonFactory;
        parent::__construct($context);
    }
    
	public function execute()
	{
		$isAjax = $this->request->getParam('isAjax');
		$link_type = $this->request->getParam('link_type');

        if($link_type) {
			$layout = $this->_view->loadLayout();
			$block = $this->getLinkTypeBlockByRequest($link_type);
			
			$deeplink_block_content = "";
			
			if((isset($block['class']) && $block['class'] != "") && (isset($block['template']) && $block['template'] != ""))
			{
				$deeplink_block_content = $layout->getLayout()->createBlock($block['class'])->setTemplate($block['template'])->toHtml();
			}
			else if(isset($block['class']) && $block['class'] != "")
			{
				$deeplink_block_content = $layout->getLayout()->createBlock($block['class'])->toHtml();
			}

			$resultPage = $this->_resultPageFactory->create();
			$this->getResponse()->setBody($deeplink_block_content);
			return ;
			/*
			$response['deeplink_block_content'] = $deeplink_block_content;
			$response['status'] = 'success';
			$resultJson = $this->resultJsonFactory->create();
			return $resultJson->setData($response);*/
		}
	}

	public function getLinkTypeBlockByRequest($link_type)
	{
		$block = [];
		switch ($link_type) {
			case 'product':
                $block['class'] = '\Mobicommerce\Mobiadmin3\Block\Adminhtml\Applications\Grid\Widget\Deeplink\Product';
				break;
			case 'category':
				$block['class'] = 'Mobicommerce\Mobiadmin3\Block\Adminhtml\Comman';
				$block['template'] = 'Mobicommerce_Mobiadmin3::mobiadmin3/application/edit/tab/widget/type/deeplink/category.phtml';
				break;
			case 'cms':
				$block['class'] = '\Mobicommerce\Mobiadmin3\Block\Adminhtml\Applications\Grid\Widget\Deeplink\Cms';
				break;
			case 'phone':
				$block['class'] = 'Mobicommerce\Mobiadmin3\Block\Adminhtml\Comman';
				$block['template'] = 'Mobicommerce_Mobiadmin3::mobiadmin3/application/edit/tab/widget/type/deeplink/phone.phtml';
				break;
			case 'email':
				$block['class'] = 'Mobicommerce\Mobiadmin3\Block\Adminhtml\Comman';
				$block['template'] = 'Mobicommerce_Mobiadmin3::mobiadmin3/application/edit/tab/widget/type/deeplink/email.phtml';
				break;
			case 'external':
				$block['class'] = 'Mobicommerce\Mobiadmin3\Block\Adminhtml\Comman';
				$block['template'] = 'Mobicommerce_Mobiadmin3::mobiadmin3/application/edit/tab/widget/type/deeplink/external.phtml';
				break;
			case 'qrscan':
				$block['class'] = 'Mobicommerce\Mobiadmin3\Block\Adminhtml\Comman';
				$block['template'] = 'Mobicommerce_Mobiadmin3::mobiadmin3/application/edit/tab/widget/type/deeplink/qrscan.phtml';
				break;
		}
		return $block;
	}
}