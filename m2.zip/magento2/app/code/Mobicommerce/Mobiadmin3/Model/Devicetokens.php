<?php

namespace Mobicommerce\Mobiadmin3\Model;

class Devicetokens extends \Magento\Framework\Model\AbstractModel
{
	protected function _construct()
	{
		$this->_init('Mobicommerce\Mobiadmin3\Model\ResourceModel\Devicetokens');
	}
}