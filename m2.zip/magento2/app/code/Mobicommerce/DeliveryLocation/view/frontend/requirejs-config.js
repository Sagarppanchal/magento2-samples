var config = {
    config: {
        mixins: {
            'Magento_Checkout/js/view/shipping': {
                'Mobicommerce_DeliveryLocation/js/view/shipping': true
            }
        }
    }

};