<?php
/**
 * @author Mobicommerce Team
 * @copyright Copyright (c) 2018 Mobicommerce (https://www.Mobicommerce.com)
 * @package Mobicommerce_DeliveryLocation
 */

namespace Mobicommerce\DeliveryLocation\Model;


class DeliveryErrorMessage extends \Mobicommerce\Mobiservices3\Model\AbstractModel 
{

}