<?php
/**
 * @package Mobicommerce\GroceryService
 * @author Mobi Commerce <info@mobicommerce.com>
 * @copyright 2017 Mobicommerce Sp. z o.o.
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Mobicommerce_GroceryService',
    __DIR__
);
