<?php
namespace Mobicommerce\Mobiservices3\Helper;

class Customization extends \Magento\Framework\App\Helper\AbstractHelper {

    public function __construct(
        \Magento\Framework\App\Helper\Context $context
    ) {
        parent::__construct($context);
    }
}