<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

init();

/**
 * used to initializing the store
 * @global type $currency
 * @global type $currencies
 */
function init()
{
    $context = context::getContext();

    init_lanaguage();
    init_currency();
    init_promotion();

    if (method_exists('ImageType', 'getFormatedName')) {
        define('PIC_NAME_SUFFIX', ImageType::getFormatedName(''));
    } else {
        define('PIC_NAME_SUFFIX', '');
    }

    if (!defined('_PS_COUNTRY_DEFAULT_'))
        define('_PS_COUNTRY_DEFAULT_', Configuration::get('PS_COUNTRY_DEFAULT'));

    if (!defined('_PS_CURRENCY_DEFAULT_'))
        define('_PS_CURRENCY_DEFAULT_', Configuration::get('_PS_CURRENCY_DEFAULT_'));

    if (_PS_VERSION_ < '1.4') {
        define('ONLY_PRODUCTS', 1);
        define('ONLY_DISCOUNTS', 2);
        define('BOTH', 3);
        define('BOTH_WITHOUT_SHIPPING', 4);
        define('ONLY_SHIPPING', 5);
        define('ONLY_WRAPPING', 6);
        define('ONLY_PRODUCTS_WITHOUT_SHIPPING', 7);
    } else {
        define('ONLY_PRODUCTS', Cart::ONLY_PRODUCTS);
        define('ONLY_DISCOUNTS', Cart::ONLY_DISCOUNTS);
        define('BOTH', Cart::BOTH);
        define('BOTH_WITHOUT_SHIPPING', Cart::BOTH_WITHOUT_SHIPPING);
        define('ONLY_SHIPPING', Cart::ONLY_SHIPPING);
        define('ONLY_WRAPPING', Cart::ONLY_WRAPPING);
        define('ONLY_PRODUCTS_WITHOUT_SHIPPING', Cart::ONLY_PRODUCTS_WITHOUT_SHIPPING);
    }


    /* Cart already exists read cart id from cookie */
    if ((int) $context->cookie->id_cart && $context->cart) {
        if (isset($context->cookie->id_carrier) && $context->cookie->id_carrier) {
            $context->cart->id_carrier = $context->cookie->id_carrier;   //save id_carrier
        }
    }
}

/**
 * Tools::setCurrency()
 * Currency::getCurrent()
 * @global type $currency
 */
function init_currency()
{
    //here we expose the $currency to the globals
    $context = context::getContext();

    if (isset($context->cookie->id_currency)) {
        $id_currency = Tools::getValue('id_currency');
        if (intval($id_currency) && $context->cookie->id_currency != $id_currency) {
            $context->cookie->id_currency = $id_currency;
            _PS_VERSION_ > '1.5' && $context->currency = new Currency($context->cookie->id_currency);
        }
    } else {
        $context->cookie->id_currency = _PS_CURRENCY_DEFAULT_;
    }
    $currency = Currency::getCurrency($context->cookie->id_currency);
    $context->cookie->currency = $currency['iso_code'];
    if(isset($currency['decimals'])) {
        $context->cookie->decimals = $currency['decimals'] * _PS_PRICE_DISPLAY_PRECISION_;
    }

    unset($_POST['SubmitCurrency']);
    unset($_POST['id_currency']);
}

/**
 * set current language
 * @global type $language
 * @global type $languages_id
 * @global type $config
 * @author hujs
 */
function init_lanaguage()
{
    $context = context::getContext();

    if (isset($context->cookie->id_lang)) {
        $id_lang = Tools::getValue('id_lang');
        if (intval($id_lang) && $context->cookie->id_lang != $id_lang) {
            $context->cookie->id_lang = $id_lang;
        }
    } else {
        $context->cookie->id_lang = (int) Configuration::get('PS_LANG_DEFAULT');
    }

    $context->cookie->iso = Language::getIsoById($context->cookie->id_lang);
    unset($_POST['id_lang']);
}

function init_promotion()
{
    $context = context::getContext();
    if (empty($_POST['discount_amount']) && (!isset($_POST['coupon_for_free']) || $_POST['coupon_for_free'] <= 0)) {
        return false;
    } elseif (!is_readable(_PS_CLASS_DIR_ . 'Discount.php')) {
        return false;
    }

    $result = Db::getInstance()->getRow('SELECT `id_discount` FROM `' . _DB_PREFIX_ . 'discount` WHERE `name` = \'MOBICOMMERCE\' ');
    if (!$result) {
        $rows = Db::getInstance()->ExecuteS('DESC  `' . _DB_PREFIX_ . 'discount` ');
        $fields = array();
        foreach ($rows as $row) {
            if ($row['Null'] == 'NO') {
                if (strpos($row['Field'], 'date_') !== false) {
                    $fields[$row['Field']] = date('Y-m-d H:i:s');
                } else {
                    $fields[$row['Field']] = 0;
                }
            }
        }
        $fields['name'] = 'MOBICOMMERCE';
        unset($fields['id_discount']);
        if (Db::getInstance()->AutoExecute(_DB_PREFIX_ . 'discount', $fields, 'INSERT')) {
            $insert_id = Db::getInstance()->Insert_ID();
        } else {
            $insert_id = false;
        }
    } else {
        $insert_id = $result['id_discount'];
    }

    if (!$insert_id) {
        return false;
    }

    defined('MOBICOMMERCE_DISCOUNT_ID', $insert_id);
    if (is_writeable(_PS_DOWNLOAD_DIR_)) {
        $dir = _PS_DOWNLOAD_DIR_;
    } else {
        $file = tempnam('', 'kc');
        $dir = dirname($file) . DIRECTORY_SEPARATOR;
        @unlink($file);
    }

    if (!file_exists($dir . 'Discount.php')) {
        $context = Tools::file_get_contents(_PS_CLASS_DIR_ . 'Discount.php');
        file_put_contents($dir . 'Discount.php', preg_replace('/class\s+Discount\w*/', 'class KDiscount', $context, 1));
    }

    if (!file_exists($dir . 'Discount.php')) {
        return false;
    }

    include_once $dir . 'Discount.php';
    include_once MOBICOMMERCE3_ROOT . '/modules/promotion/Discount.php';

    $cart = $context->cart;
    if ($insert_id && $cart->id) {
        if (!$cart->getDiscountsCustomer($insert_id)) {
            $cart->addDiscount((int) $insert_id);
            $cart->getDiscounts(false, true); //reflash cart discount
        }
    }
}

/**
 * get current currecy price
 * @global type $currency
 * @global type $currencies
 * @param type $price
 * @return type
 * @author hujs
 */
function currency_price_value($price)
{
    $context = context::getContext();
    $price = Tools::convertPrice($price, Currency::getCurrent());
    return Tools::ps_round($price, $context->cookie->decimals);
}

function addImageRatio(&$product)
{
    $urls = array(
        'widget_image',
        'banner_url',
        'full_image_url',
        'image_url',
        'thumbnail_url',
        'product_image',
        'product_small_image_url',
        'product_image_url',
        'product_thumbnail_url'
        );

    foreach($urls as $_url) {
        if(isset($product[$_url])) {
            $product['ratio_'.$_url] = getImageRatio($product[$_url]);
        }
    }

    return $product;
}

function getImageRatio($url)
{
    $width = 1;
    $height = 1;

    if(!empty($url)) {
        $base_url = getBaseUrl();
        $path = str_replace($base_url, _PS_ROOT_DIR_.'/', $url);
        if(file_exists($path)) {
            list($width, $height, $type, $attr) = getimagesize($path);
        }
    }

    $ratio = round($height / $width, 2);
    return "1:$ratio";
}

function getBaseUrl()
{
    $base_url = _PS_BASE_URL_.__PS_BASE_URI__;
    $ssl = Configuration::get('PS_SSL_ENABLED_EVERYWHERE');
    if($ssl)
    {
        $base_url = str_replace('http://', 'https://', $base_url);
    }

    return $base_url;
}