<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('_PS_VERSION_'))
	exit;

class Mobicommerce3 extends Module
{
	/**
	 * Construct Method
	 */
	public function __construct()
	{
		$this->name = 'mobicommerce3';
		$this->displayName = 'MobiCommerce 3.0';
		$this->description = $this->l('Create Mobile Native iOS & Android apps and Mobile website for your magento store. All you can do through Mageto admin.
			Preview and test your mobile apps and mobile website before you buy it.
			Personalize and customize your apps on the fly.
			Send Push notification to all of your mobile user.
			No coding and technical skills required to create and manage your mobile apps.
			    Create Mobile Native iOS & Android apps and Mobile website for your magento store. All you can do through Mageto admin.
			Preview and test your mobile apps and mobile website before you buy it.
			Personalize and customize your apps on the fly.
			Send Push notification to all of your mobile user.
			No coding and technical skills required to create and manage your mobile apps.');
		$this->author = 'MobiCommerce';
		$this->version = '3.0.0';
		$this->module_key = '89a8082a4ebbfb64392bb8fbac2d7197';
		$this->tab = 'mobile';
        $this->ps_versions_compliancy = array('min' => '1.5', 'max' => _PS_VERSION_);
        $this->bootstrap = true;
        
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
		// Parent constructor
		parent::__construct();
   }

	public function install()
	{
		/* added by yash to install licence url */
		$context = context::getContext();
	    $website_url  = $this->getBaseURL();
	    $sales_email  = $context->cookie->email;
	    $country      = '';

	    $curlData = array();
	    $curlData['website_url'] = $website_url;
	    $curlData['sales_email'] = $sales_email;
	    $curlData['admin_email'] = $context->cookie->email;
	    $curlData['country'] = $country;
	    $curlData['platform'] = 'prestashop';
	    $fields_string = http_build_query($curlData);

	    $ch = curl_init();
	    $url = 'http://build3.build.mobi-commerce.net/install';
	    curl_setopt($ch, CURLOPT_HEADER, FALSE);
	    curl_setopt($ch, CURLOPT_NOBODY, TRUE);
	    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	    curl_setopt($ch, CURLOPT_URL, $url);
	    curl_setopt($ch, CURLOPT_POST, count($curlData));
	    curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
	    $result = curl_exec($ch);
	    curl_close($ch);  

	    $result = Tools::jsonDecode($result, true);
	    $licence_key = $result['data']['licence_key'];
	    /* upto here */
	    
		// Install SQL
		include(_PS_MODULE_DIR_.$this->name.'/sql/install.php');
		$sql = getSql($licence_key);
		foreach ($sql as $s) {
			if (!Db::getInstance()->execute($s))
			return false;
		}

		// Install Tab
	  	$tab = new Tab();
		foreach (Language::getLanguages() as $lang) {
			$tab->name[$lang['id_lang']] = $this->l('MobiCommerce 3.0');
		}
	
		$tab->class_name = 'AdminMobicommerce3';
        $tab->id_parent = 0;
		$tab->module = $this->name;
		$tab->add();
        $parentId = $tab->id;
        
        $this->installModuleTab('MCNewApp', "Create New Mobile App", $parentId);
        $this->installModuleTab('MCManageApp', "Manage Mobile Apps", $parentId);
        $this->installModuleTab('MCSocialLogin', "Social Login", $parentId);
        $this->installModuleTab('MCCategoryWidget', "Category Widgets", $parentId);
        $this->installModuleTab('MCLabels', "Lables and Messages", $parentId);
        //$this->installModuleTab('MCPushHistory', "Push Notifications History", $parentId);
        
        Configuration::updateValue('mobi3_fb_active', '1');
        Configuration::updateValue('mobi3_fb_title', 'Login with Facebook');
        Configuration::updateValue('mobi3_fb_appid', '408928736120784');
        Configuration::updateValue('mobi3_fb_appname', 'MobiCommerce Demo');
        Configuration::updateValue('mobi3_fb_sortorder', '1');

        Configuration::updateValue('mobi3_go_active', '1');
        Configuration::updateValue('mobi3_go_title', 'Login with Google');
        Configuration::updateValue('mobi3_go_clientid', '881306584774-gn175pq2op8tgn2fc125s38hho48k26k.apps.googleusercontent.com');
        Configuration::updateValue('mobi3_go_sha1key', '20:55:05:11:D0:3D:B6:1B:FF:79:3D:02:1E:91:7B:1B:66:60:1C:DA');
        Configuration::updateValue('mobi3_go_sortorder', '2');

        return (parent::install() && $this->registerHook('actionAdminControllerSetMedia') && $this->registerHook('actionFrontControllerSetMedia') && $this->registerHook('displayHeader'));
	}

	public function hookActionAdminControllerSetMedia()
	{
		$this->context->controller->addCSS($this->_path.'views/css/admin/mobiadmin.css', 'all');
	}

	public function hookActionFrontControllerSetMedia()
	{
		$this->context->controller->addCSS($this->_path.'views/css/front/style.css', 'all');
	}

	public function hookDisplayHeader($params)
	{
		$_cart_discounts = $this->context->cart->getDiscounts();
		$is_mobi = Tools::getValue('method');
		if($_cart_discounts && !$is_mobi) {
			foreach($_cart_discounts as $_discount) {
				if(isset($_discount['scope']) && $_discount['scope'] == '1') {
					$this->context->cart->deleteDiscount($_discount['id_cart_rule']);
			        unset($this->context->cookie->coupon);
			        unset($this->context->cookie->id_coupon);
				}
			}
		}
	}

    public function installModuleTab($tabClass, $tabName, $idTabParent)
    {
        $tab = new Tab();

        foreach (Language::getLanguages() as $language) {
            $tab->name[$language['id_lang']] = $tabName;
        }

        $tab->class_name = $tabClass;
        $tab->module = $this->name;
        $tab->id_parent = $idTabParent;

        if (!$tab->save()) {
            return false;
        }

        return $tab->id;
    }

	public function uninstall()
	{
		$sql = array();
		include(_PS_MODULE_DIR_.$this->name.'/sql/uninstall.php');
		foreach ($sql as $s) {
			if (!Db::getInstance()->execute($s))
			return false;
		}
           
        $tabsToDelete = array(
        	'AdminMobicommerce3',
        	'MCNewApp',
        	'MCManageApp',
        	'MCSocialLogin',
        	'MCCategoryWidget',
        	'MCLabels',
        	//'MCPushHistory'
        	);

        foreach ($tabsToDelete as $className)
        {
        	$id_tab = (int)Tab::getIdFromClassName($className);
			if ($id_tab)
			{
				$tab = new Tab($id_tab);
				$tab->delete();
			}
        }

		if (!parent::uninstall())
			return false;

		return true;
	}

	public function getBaseUrl()
	{
		$base_url = _PS_BASE_URL_.__PS_BASE_URI__;
		if(Configuration::get('PS_SSL_ENABLED') && Configuration::get('PS_SSL_ENABLED_EVERYWHERE'))
		{
			$base_url = str_replace('http://', 'https://', $base_url);
		}

		return $base_url;
	}
}
