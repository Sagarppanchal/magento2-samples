<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

//ob_start();
error_reporting(0);
ini_set('display_errors', false);
define('IN_MOBICOMMERCE', true);
define('API_VERSION', '1.1');

define('MOBICOMMERCE3_ROOT', dirname(__FILE__));
define('PS_ROOT', dirname(dirname(MOBICOMMERCE3_ROOT)));

require_once MOBICOMMERCE3_ROOT . '/functions.php';
require_once PS_ROOT . '/config/config.inc.php';
require_once PS_ROOT . '/init.php';
require_once MOBICOMMERCE3_ROOT . '/MobicommerceHelper.php';
require_once MOBICOMMERCE3_ROOT . '/GroceryHelper.php';

mc_include_once(MOBICOMMERCE3_ROOT . '/Logger.php');
mc_include_once(MOBICOMMERCE3_ROOT . '/configure.php');
mc_include_once(MOBICOMMERCE3_ROOT . '/Exceptions.php');
mc_include_once(MOBICOMMERCE3_ROOT . '/ActionFactory.php');
mc_include_once(MOBICOMMERCE3_ROOT . '/ServiceFactory.php');
mc_include_once(MOBICOMMERCE3_ROOT . '/services/BaseService.php');
mc_include_once(MOBICOMMERCE3_ROOT . '/actions/BaseAction.php');
mc_include_once(MOBICOMMERCE3_ROOT . '/actions/UserAuthorizedAction.php');
mc_include_once(MOBICOMMERCE3_ROOT . '/util/CryptoUtil.php');
mc_include_once(MOBICOMMERCE3_ROOT . '/MobicommerceResult.php');
mc_include_once(MOBICOMMERCE3_ROOT . '/common-functions.php');

try {
    $actionInstance = ActionFactory::factory(Tools::getValue('method'));
    $actionInstance->init();
    
    if ($actionInstance->validate()){
        $actionInstance->execute();
    }
    $result = $actionInstance->getResult();
    
    // added by yash
    $json_data = Tools::jsonEncode($result->returnResult());
    if(isset($_GET['callback']) && $_GET['callback']!=''){
        //ob_end_clean();
        print $_GET['callback'] ."(".$json_data.")";
    }else{
        //ob_end_clean();
        header('content-type:application/json');
        echo $json_data;
    }
} catch (EmptyMethodException $e) {
    die('MobiCommerce OpenAPI v' . API_VERSION . ' is installed on Prestashop v' . _PS_VERSION_ . '. Prestashop Plugin v' . MOBICOMMERCE_PLUGIN_VERSION);
} catch (Exception $e) {
    die(Tools::jsonEncode(array('result' => MobicommerceResult::STATUS_FAIL, 'code' => MobicommerceResult::ERROR_UNKNOWN_ERROR, 'info' => $e->getMessage() . ',' . $e->getTraceAsString())));
}
