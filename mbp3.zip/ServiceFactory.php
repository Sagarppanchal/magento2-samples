<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

class ServiceFactory
{
    private static $serviceCache = array();

    public static function factory($serviceName, $singleton = true)
    {
        if (empty($serviceName))
        {
            throw new Exception('Service name is required .');
        }
        $serviceClassName = $serviceName . 'Service';
        if (isset(self::$serviceCache[$serviceClassName]))
        {
            if ($singleton)
            {
                return self::$serviceCache[$serviceClassName];
            }
            else
            {
                return new $serviceClassName;
            }
        }
        if (!self::serviceExists($serviceClassName))
        {
            throw new Exception($serviceClassName . ' not exists');
        }
        mc_include_once(MOBICOMMERCE3_ROOT . '/services/' . $serviceClassName . '.php');
        $instance = new $serviceClassName;
        self::$serviceCache[$serviceClassName] = $instance;
        return $instance;
    }

    public static function serviceExists($serviceClassName)
    {
        $serviceFile = $serviceClassName . '.php';
        return mc_file_exists(MOBICOMMERCE3_ROOT . '/services/' . $serviceFile);
    }
}
