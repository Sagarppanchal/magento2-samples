<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

define('MOBICOMMERCE_PLUGIN_VERSION', '3.0.0');
define('MOBICOMMERCE_APP_KEY', 'Y6Z0QIST3');
define('MOBICOMMERCE_APP_SECRET' , '0SC2Y44UMEABJM573WHW061L8SR3LZ9S3');
