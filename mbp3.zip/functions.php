<?php

function pre($params, $exit = 1)
{
	echo "<pre>";
	print_r($params);

	if($exit)
	{
		exit();
	}
}