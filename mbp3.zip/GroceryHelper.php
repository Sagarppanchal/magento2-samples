<?php

function isGroceryEnabled()
{
    //return true;
    return false;
}

function bindProductListingGrocery(&$_product)
{
    if(isGroceryEnabled())
    {
        //echo '<pre>';print_r($_product);exit;
        $_product['grocery_type'] = 'simple';
        $_product['combination_id'] = $_product['product_id'].'_0_1';
        if($_product['combinations'])
        {
            $_product['grocery_type'] = 'simple_with_options';
            $mobi_combination = array();
            foreach($_product['combinations'] as $_combination_key => $_combination)
            {
                $mobi_combination[] = array(
                    'combination_id' => $_product['product_id'].'_'.$_combination_key.'_1',
                    'title'          => implode(', ', $_combination['attributes_values']),
                    'price'          => $_combination['pricing']['our_price'],
                    'qty'            => $_combination['quantity'],
                    'stock_status'   => $_combination['quantity'] ? true : false,
                    );
                /*
                $_product['combinations'][$_combination_key]['title'] = implode(', ', $_combination['attributes_values']);
                $_product['combinations'][$_combination_key]['price'] = $_combination['pricing']['our_price'];
                */

                /*
                foreach($_combination['attributes_values'] as $_attribute_values_key => $_attribute_values)
                {
                    $_product['combinations'][$_combination_key]['combination_id'] = $_product['product_id'].':'.$_attribute_values_key;
                    /*
                    $_product['combinations'][$_combination_key]['mobi_attributes_values'][] = array(
                        'id' => $_attribute_values_key,
                        'group' => $_product['options']['product_super_attributes'][$_attribute_values_key]['name'],
                        'value' => $_attribute_values
                        );
                    *//*
                }
                */
            }
        }
        $_product['options']['product_options'][0] = array(
            'options' => $mobi_combination
            );
        //$this->bindProductPriceIfZero($_product);
        //echo '<pre>';print_r($_product);exit;
    }
    return;
}

function bindProductPriceIfZero(&$_product)
{
    if(isGroceryEnabled())
    {
        // if simple product with custom options are there
        if($_product['grocery_type'] == 'simple_with_options')
        {
            $_base_price = $_product['special_price'];
            if(!$_base_price) {
                $_base_price = $_product['price'];
            }

            $_price_array = array();
            foreach($_product['options']['product_options'] as $options_key => $options)
            {
                foreach($options['options'] as $_option_key => $_option)
                {
                    $_price = 0;
                    $_option_price = 0;
                    if($_option['price_type'] == 'fixed')
                    {
                        $_option_price = $_base_price + $_option['price'];
                    }
                    else if($_option['price_type'] == 'percent')
                    {
                        $_option_price = $_base_price + ($_base_price * $_option['price'] / 100);
                    }

                    $_product['options']['product_options'][$options_key]['options'][$_option_key]['price'] = $_option_price;
                    $_price_array[] = $_option_price;
                }
            }

            $_product['price'] = min($_price_array);
            $_product['special_price'] = $_product['price'];
        }
    }
    return;
}

function bindProductDetailGrocery(&$_product, $product)
{
    if(isGroceryEnabled())
    {
        $this->bindProductPriceIfZero($_product);
    }
    return;
}

function arrangeProductOptions($product, $options)
{
    if(isGroceryEnabled())
    {
        $product_id = $product->getId();
        $type = $product->getTypeId();
        switch ($type) {
            case Mage_Catalog_Model_Product_Type::TYPE_SIMPLE:
                if($options['product_options'])
                {
                    foreach($options['product_options'] as $simple_option_key => $simple_option)
                    {
                        foreach($simple_option['options'] as $option_key => $option)
                        {
                            $options['product_options'][$simple_option_key]['options'][$option_key]['combination_id'] = $product_id.'_'.$option['option_id'].'_'.$option['option_type_id'];
                        }
                    }
                }
                break;
        }
    }
    return $options;
}

function arrangeCartData($cart_array)
{
    if(isGroceryEnabled())
    {
        $grocery_items = array();
        if($cart_array['items'])
        {
            foreach($cart_array['items'] as $_item_key => $_item)
            {
                if(!array_key_exists($_item['product_id'], $grocery_items))
                {
                    $grocery_items[$_item['product_id']] = $_item;
                    $grocery_items[$_item['product_id']]['grocery_options'] = array();
                }

                $_grocery_option = array();
                // simple product with option
                if($_item['options'])
                {
                    $_grocery_option['grocery_type'] = 'simple_with_options';
                    $_grocery_option['option_details']['option_value'] = implode(', ', $_item['options']);
                    $_grocery_option['combination_id'] = str_replace(':', '_', $_item['item_id']);
                }
                // simple product without option
                else
                {
                    $_grocery_option['grocery_type'] = 'simple';
                    $_grocery_option['combination_id'] = $_item['item_id'];
                }
                
                $_grocery_option['item_id']            = $_item['item_id'];
                $_grocery_option['hasError']           = $_item['hasError'];
                $_grocery_option['errorDescription']   = $_item['errorDescription'];
                $_grocery_option['max_qty']            = $_item['max_qty'];
                $_grocery_option['price']              = $_item['price'];
                $_grocery_option['price_incl_tax']     = $_item['price_incl_tax'];
                $_grocery_option['qty']                = $_item['qty'];
                $_grocery_option['qty_increments']     = $_item['qty_increments'];
                $_grocery_option['row_total']          = $_item['row_total'];
                $_grocery_option['row_total_incl_tax'] = $_item['row_total_incl_tax'];

                $grocery_items[$_item['product_id']]['grocery_options'][] = $_grocery_option;
            }
        }

        $cart_array['grocery_items'] = array_values($grocery_items);
    }
    return $cart_array;
}

function arrangeOrderDetailData($order)
{
    if(isGroceryEnabled())
    {
        $grocery_items = array();
        foreach($order['order_items'] as $_item) {
            if(!array_key_exists($_item['product_id'], $grocery_items)) {
                $grocery_items[$_item['product_id']] = $_item;
                $grocery_items[$_item['product_id']]['grocery_options'] = array();
            }

            if($_item['options'])
            {
                $option_value = array();
                foreach($_item['options'] as $_option)
                {
                    $option_value[] = $_option['option_value'];
                }
                $_item['options'][0]['option_value'] = implode(', ', $option_value);   
            }

            $grocery_items[$_item['product_id']]['grocery_options'][] = $_item;
        }

        $grocery_items = array_values($grocery_items);
        $order['grocery_items'] = $grocery_items;
    }
    
    return $order;
}
