<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

class ProductTranslatorService extends BaseService
{
    private $product;
    private $item = array();
    private $isArray = true;
    private $tax;

    public function __construct()
    {
        parent::__construct();
        $this->tax = (!$this->priceDisplay || $this->priceDisplay == 2);
    }

    public function getTranslatedItem()
    {
        return $this->item;
    }

    public function getItemBaseInfo()
    {
        $this->item['product_id'] = (string)$this->id_product;
        $this->item['name'] = $this->isArray ? $this->product['name'] : $this->product->name;
        $this->item['url'] = $this->link->getProductLink($this->id_product);
        $this->item['type'] = 'simple';
        $this->item['type_id'] = 'simple';
        $this->item['attributeSetName'] = NULL;
        $this->item['entity_id'] = $this->id_product;
        $this->item['product_small_image_url'] = $this->getProductImage($this->link_rewrite, $this->id_image, 'home');
        $this->item['product_thumbnail_url'] = $this->getProductImage($this->link_rewrite, $this->id_image, 'home');
        $this->item['product_image_url'] = $this->getProductImage($this->link_rewrite, $this->id_image, 'home');        
        $this->item['stock_status'] = $this->allowAddToCart() ? true : false;
        $this->item['available_for_order'] = $this->product->available_for_order;
        $this->item['review_summary'] = $this->getReviewSummary($this->id_product);
        $this->item['reviews'] = $this->getProductReviews($this->id_product, 1, 3);
        $this->item['ratingOptions'] = $this->getRatingOptions($this->id_product);
        addImageRatio($this->item);
        // for worachat - loyalty
        /*
        include_once(_PS_ROOT_DIR_.'/modules/loyalty/LoyaltyModule.php');
        include_once(_PS_ROOT_DIR_.'/modules/loyalty/LoyaltyStateModule.php');
        $product = new Product((int)$this->id_product);

        $params['cart'] = $this->cart;
        if (Validate::isLoadedObject($params['cart']))
        {
            $pointsBefore = (int)LoyaltyModule::getCartNbPoints($params['cart']);
            $pointsAfter = (int)LoyaltyModule::getCartNbPoints($params['cart'], $product);
            $points = (int)($pointsAfter - $pointsBefore);
        }
        else
        {
            if (!(int)Configuration::get('PS_LOYALTY_NONE_AWARD') && Product::isDiscounted((int)$this->id_product))
            {
                $points = 0;
                $no_pts_discounted = 1;
            }
            else{
                $points = (int)LoyaltyModule::getNbPointsByPrice(
                    $product->getPrice(
                        Product::getTaxCalculationMethod() == PS_TAX_EXC ? false : true,
                        (int)$product->getIdProductAttributeMostExpensive()
                    )
                );
            }
            $pointsAfter = $points;
            $pointsBefore = 0;
            $points_html = '';

            $voucher = LoyaltyModule::getVoucherValue((int)$pointsAfter);
        }

        if($points){
            $points_html .= $this->l("By buying this product you can collect up to", array(
                'mod' => 'loyalty',
                'modtpl' => 'product',
                ));
            $points_html .= " ".$points." ";
            if($points > 1){
                $points_html .= $this->l("loyalty points", array(
                    'mod' => 'loyalty',
                    'modtpl' => 'product',
                    ));
            }
            else{
                $points_html .= $this->l("loyalty point", array(
                    'mod' => 'loyalty',
                    'modtpl' => 'product',
                    ));
            }
            $points_html .= '.';
            $points_html .= ' ';
            
            $points_html .= $this->l("Your cart will total", array(
                'mod' => 'loyalty',
                'modtpl' => 'product',
                ));

            $points_html .= " ".$pointsAfter." ";
            if($pointsAfter > 1){
                $points_html .= $this->l("points", array(
                    'mod' => 'loyalty',
                    'modtpl' => 'product',
                    ));
            }
            else{
                $points_html .= $this->l("point", array(
                    'mod' => 'loyalty',
                    'modtpl' => 'product',
                    ));
            }
            $points_html .= '.';
            
            //$points_html .= ' ';
            //$this->l("that can be converted into a voucher of", array(
            //    'mod' => 'loyalty',
            //    'modtpl' => 'product',
            //    ));
            //$points_html .= " ".$voucher;
            $points_html = '';
        }
        else{
            if(isset($no_pts_discounted) && $no_pts_discounted == 1){
                $points_html = $this->l('No reward points for this product because there\'s already a discount.', array(
                    'mod' => 'loyalty',
                    'modtpl' => 'loyalty',
                    ));
            }
            else{
                $points_html = $this->l('No reward points for this product.', array(
                    'mod' => 'loyalty',
                    'modtpl' => 'loyalty',
                    ));
            }
        }
        if(!empty($points_html)){
            $this->item["loyalty_text"] = $points_html;   
        }
        //$this->item["loyalty_text"] = $points_html;
        */
        // for worachat - loyalty - upto here

        return $this->item;
    }

    /**
    * Added By Dharmendra Jain For Review Functionality
    * 04032016
    **/
    public function getReviewSummary($productId)
    {
        $review_array = array(
            'averageRating' => 0,
            'count' => 0
            );

        if(Module::isInstalled('productcomments'))
        {
            include_once _PS_MODULE_DIR_.'productcomments/ProductComment.php';
            include_once _PS_MODULE_DIR_.'productcomments/ProductCommentCriterion.php';            

            $averages = ProductComment::getRatings((int)$productId);
            $averageTotal = 0;
            if(!empty($averages))
            {
                $averageTotal = $averages['avg'];
            }

            $comments = ProductComment::getByProduct((int)$productId, $p, 5000);

            $review_array['averageRating'] = $averageTotal ? round($averageTotal, 2) : 0;
            $review_array['count'] = count($comments);
        }
        return $review_array;
    }

    public function getProductReviews($productId, $p=1, $n=3)
    {
        $review_array = array();
        if(Module::isInstalled('productcomments'))
        {
            include_once _PS_MODULE_DIR_.'productcomments/ProductComment.php';
            include_once _PS_MODULE_DIR_.'productcomments/ProductCommentCriterion.php';
            
            $comments = ProductComment::getByProduct((int)$productId, $p, $n);
            $_reviews = array();
            foreach ($comments as $key => $comment) {
                $_reviews[] = array(
                    'product_id'    => $productId,
                    'nickname'      => $comment['customer_name'],
                    'averageRating' => $comment['grade'],
                    'title'         => $comment['title'],
                    'detail'        => $comment['content'],
                    'created_at'    => $comment['date_add']
                );
            }
            $review_array = $_reviews;
        }
        return $review_array;
    }

    /**
    * Added By Dharmendra Jain For Review Functionality
    * 04032016
    **/
    public static function getRatingOptions($id_product)
    {
        $ratingData = array();
        if(Module::isInstalled('productcomments'))
        {
            include_once _PS_MODULE_DIR_.'productcomments/ProductComment.php';
            include_once _PS_MODULE_DIR_.'productcomments/ProductCommentCriterion.php';
            
            $id_lang = (int) context::getContext()->cookie->id_lang;            
            $grades = ProductComment::getGradeByProduct((int) $id_product, $id_lang);

            $_grades = array();
            foreach ($grades as $key => $grade) {
                $comment_criterion_id = $grade['id_product_comment_criterion'];
                $_grades[$comment_criterion_id][] = $grade['grade'];
            }        
            $comment_criterions = Db::getInstance()->executeS('SELECT *
            FROM `'._DB_PREFIX_.'product_comment_criterion` pcc
            LEFT JOIN `' . _DB_PREFIX_ . 'product_comment_criterion_lang` pccl ON pccl.`id_product_comment_criterion` = pcc.`id_product_comment_criterion`
            WHERE `id_lang`= ' . $id_lang . ' AND  `active`='.'1'.' ');
            
            foreach ($comment_criterions as $key => $comment_criterion) {
                $comment_criterion_id = $comment_criterion['id_product_comment_criterion'];
                if(!isset($_grades[$comment_criterion_id])){
                    //continue;
                }
                $ratingData[$key]['rating_code'] = $comment_criterion['name'];
                $id_product_comment_criterion = $comment_criterion['id_product_comment_criterion'];
                $options = array(
                    '1' => array('option_id' => 1,'code' => 1,'value' => 1, 'rating_id' => $id_product_comment_criterion,),
                    '2' => array('option_id' => 2,'code' => 2,'value' => 2, 'rating_id' => $id_product_comment_criterion,),
                    '3' => array('option_id' => 3,'code' => 3,'value' => 3, 'rating_id' => $id_product_comment_criterion,),
                    '4' => array('option_id' => 4,'code' => 4,'value' => 4, 'rating_id' => $id_product_comment_criterion,),
                    '5' => array('option_id' => 5,'code' => 5,'value' => 5, 'rating_id' => $id_product_comment_criterion,),
                );
                $ratingData[$key]['options'] = $options;
                $ratingData[$key]['rating_id'] = $id_product_comment_criterion;
                
                if(isset($_grades[$comment_criterion_id])){
                    $count = count($_grades[$comment_criterion_id]);
                    $sum = array_sum($_grades[$comment_criterion_id]);
                    $ratingData[$key]['summary'] = $sum/$count*10;
                }else{
                    $ratingData[$key]['summary'] = '0';
                }
                
            }
        }

        return $ratingData;
    }

    private function allowAddToCart()
    {
        return (!isset($this->available_for_order) || $this->available_for_order) &&
                $this->customizable != 2 &&
                !Configuration::get('PS_CATALOG_MODE') &&
                ($this->allow_oosp || $this->quantity > 0);
    }

    /**
     * Check if product has attributes combinaisons
     *
     * @return integer Attributes combinaisons number
     */
    public function hasAttributes()
    {
        $count = (int) Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
            SELECT COUNT(`id_product_attribute`)
            FROM `' . _DB_PREFIX_ . 'product_attribute`
            WHERE `id_product` = ' . (int) ($this->id_product));

        return $count > 0;
    }

    /**
     * get item prices not include tax
     * @global type $cookie
     * @return type
     * @author hujs
     */
    public function getItemPrices()
    {
        $prices = array();
        $productPriceWithoutRedution = Product::getPriceStatic($this->id_product, $this->tax, null, $this->context->cookie->decimals, NULL, false, false, 1);
        $finalPrice = Product::getPriceStatic($this->id_product, $this->tax, NULL, $this->context->cookie->decimals, NULL, false, true, 1);

        $prices['currency'] = $this->context->cookie->currency;
        $prices['base_price'] = array('price' => $finalPrice); //not include attribute price
        $prices['tier_prices'] = array();    //different qty has diferent price
        $displayPrices = array();
        $displayPrices[] = array(//the final price include attribute price
            'title' => 'Price',
            'price' => Tools::ps_round($finalPrice, $this->context->cookie->decimals),
            'style' => 'normal'
        );

        if ($productPriceWithoutRedution > $finalPrice) {
            $displayPrices[] = array(
                'title' => '',
                'price' => Tools::ps_round($productPriceWithoutRedution, $this->context->cookie->decimals),
                'style' => 'line-through'
            );
            //$this->item['discount'] = round(100 - ($finalPrice * 100) / $productPriceWithoutRedution);
        }

        $prices['display_prices'] = $displayPrices;
        //$this->item['prices'] = $prices;
        
        $price = $finalPrice;
        $this->item['price'] = $productPriceWithoutRedution;
        $this->item['special_price'] = $price;
		if($this->item['price'] != $this->item['special_price']){
			$this->item['discount'] = round(100 - ($finalPrice * 100) / $productPriceWithoutRedution).'%';
            //$this->item['discount'] = $this->cookie->currency.' '.round($productPriceWithoutRedution - $finalPrice);
		}else{
			$this->item['discount'] = 0;
		}
        
        return $price;
    }

    /**
     * Assign template vars related to attribute groups and colors
     */
    protected function assignAttributesGroups()
    {
        $this->context = Context::getContext();
        $colors = array();
        $groups = array();

        // @todo (RM) should only get groups and not all declination ?
        $attributes_groups = $this->product->getAttributesGroups($this->context->language->id);
        //print_r($attributes_groups);exit;
        if (is_array($attributes_groups) && $attributes_groups)
        {

            $combination_images = $this->product->getCombinationImages($this->context->language->id);
            $combination_prices_set = array();
            foreach ($attributes_groups as $k => $row)
            {
                // Color management
                if (isset($row['is_color_group']) && $row['is_color_group'] && (isset($row['attribute_color']) && $row['attribute_color']) || (file_exists(_PS_COL_IMG_DIR_.$row['id_attribute'].'.jpg')))
                {
                    $colors[$row['id_attribute']]['value'] = $row['attribute_color'];
                    $colors[$row['id_attribute']]['name'] = $row['attribute_name'];
                    if (!isset($colors[$row['id_attribute']]['attributes_quantity']))
                        $colors[$row['id_attribute']]['attributes_quantity'] = 0;
                    $colors[$row['id_attribute']]['attributes_quantity'] += (int)$row['quantity'];
                }
                if (!isset($groups[$row['id_attribute_group']]))
                    $groups[$row['id_attribute_group']] = array(
                        'group_name' => $row['group_name'],
                        'name' => $row['public_group_name'],
                        'group_type' => $row['group_type'],
                        'default' => -1,
                    );

                $groups[$row['id_attribute_group']]['attributes'][$row['id_attribute']] = $row['attribute_name'];
                if ($row['default_on'] && $groups[$row['id_attribute_group']]['default'] == -1)
                    $groups[$row['id_attribute_group']]['default'] = (int)$row['id_attribute'];
                if (!isset($groups[$row['id_attribute_group']]['attributes_quantity'][$row['id_attribute']]))
                    $groups[$row['id_attribute_group']]['attributes_quantity'][$row['id_attribute']] = 0;
                $groups[$row['id_attribute_group']]['attributes_quantity'][$row['id_attribute']] += (int)$row['quantity'];

                $combinations[$row['id_product_attribute']]['attributes_values'][$row['id_attribute_group']] = $row['attribute_name'];
                $combinations[$row['id_product_attribute']]['attributes'][] = (int)$row['id_attribute'];
                $combinations[$row['id_product_attribute']]['price'] = (float)$row['price'];

                // Call getPriceStatic in order to set $combination_specific_price
                if (!isset($combination_prices_set[(int)$row['id_product_attribute']]))
                {
                    Product::getPriceStatic((int)$this->product->id, false, $row['id_product_attribute'], 6, null, false, true, 1, false, null, null, null, $combination_specific_price);
                    $combination_prices_set[(int)$row['id_product_attribute']] = true;
                    $combinations[$row['id_product_attribute']]['specific_price'] = $combination_specific_price;
                }
                $combinations[$row['id_product_attribute']]['ecotax'] = (float)$row['ecotax'];
                $combinations[$row['id_product_attribute']]['weight'] = (float)$row['weight'];
                $combinations[$row['id_product_attribute']]['quantity'] = (int)$row['quantity'];
                $combinations[$row['id_product_attribute']]['reference'] = $row['reference'];
                $combinations[$row['id_product_attribute']]['unit_impact'] = $row['unit_price_impact'];
                $combinations[$row['id_product_attribute']]['minimal_quantity'] = $row['minimal_quantity'];
                if ($row['available_date'] != '0000-00-00' && Validate::isDate($row['available_date']))
                {
                    $combinations[$row['id_product_attribute']]['available_date'] = $row['available_date'];
                    $combinations[$row['id_product_attribute']]['date_formatted'] = Tools::displayDate($row['available_date']);
                }
                else
                    $combinations[$row['id_product_attribute']]['available_date'] = $combinations[$row['id_product_attribute']]['date_formatted'] = '';

                if (!isset($combination_images[$row['id_product_attribute']][0]['id_image']))
                    $combinations[$row['id_product_attribute']]['id_image'] = -1;
                else
                {
                    $combinations[$row['id_product_attribute']]['id_image'] = $id_image = (int)$combination_images[$row['id_product_attribute']][0]['id_image'];
                    if ($row['default_on'])
                    {
                        if (isset($this->context->smarty->tpl_vars['cover']->value))
                            $current_cover = $this->context->smarty->tpl_vars['cover']->value;

                        if (is_array($combination_images[$row['id_product_attribute']]))
                        {
                            foreach ($combination_images[$row['id_product_attribute']] as $tmp)
                                if ($tmp['id_image'] == $current_cover['id_image'])
                                {
                                    $combinations[$row['id_product_attribute']]['id_image'] = $id_image = (int)$tmp['id_image'];
                                    break;
                                }
                        }

                        if ($id_image > 0)
                        {
                            if (isset($this->context->smarty->tpl_vars['images']->value))
                                $product_images = $this->context->smarty->tpl_vars['images']->value;
                            if (isset($product_images) && is_array($product_images) && isset($product_images[$id_image]))
                            {
                                $product_images[$id_image]['cover'] = 1;
                                $this->context->smarty->assign('mainImage', $product_images[$id_image]);
                                if (count($product_images))
                                    $this->context->smarty->assign('images', $product_images);
                            }
                            if (isset($this->context->smarty->tpl_vars['cover']->value))
                                $cover = $this->context->smarty->tpl_vars['cover']->value;
                            if (isset($cover) && is_array($cover) && isset($product_images) && is_array($product_images))
                            {
                                $product_images[$cover['id_image']]['cover'] = 0;
                                if (isset($product_images[$id_image]))
                                    $cover = $product_images[$id_image];
                                $cover['id_image'] = (Configuration::get('PS_LEGACY_IMAGES') ? ($this->product->id.'-'.$id_image) : (int)$id_image);
                                $cover['id_image_only'] = (int)$id_image;
                                $this->context->smarty->assign('cover', $cover);
                            }
                        }
                    }
                }
            }

            // wash attributes list (if some attributes are unavailables and if allowed to wash it)
            if (!Product::isAvailableWhenOutOfStock($this->product->out_of_stock) && Configuration::get('PS_DISP_UNAVAILABLE_ATTR') == 0)
            {
                foreach ($groups as &$group)
                    foreach ($group['attributes_quantity'] as $key => &$quantity)
                        if ($quantity <= 0)
                            unset($group['attributes'][$key]);

                foreach ($colors as $key => $color)
                    if ($color['attributes_quantity'] <= 0)
                        unset($colors[$key]);
            }
            foreach ($combinations as $id_product_attribute => $comb)
            {
                $attribute_list = '';
                foreach ($comb['attributes'] as $id_attribute)
                    $attribute_list .= '\''.(int)$id_attribute.'\',';
                $attribute_list = rtrim($attribute_list, ',');
                $combinations[$id_product_attribute]['list'] = $attribute_list;
                $combinations[$id_product_attribute]['pricing'] = $this->assignCombinationPrice($combinations, $id_product_attribute);
            }

            foreach ($groups as $key => $value){
                foreach($value['attributes'] as $_attr_key => $_attr_value){
                    $groups[$key]['attributes'][$_attr_key] = array('value' => $_attr_value);
                    if(isset($colors[$_attr_key]))
                        $groups[$key]['attributes'][$_attr_key]['color_value'] = $colors[$_attr_key]['value'];
                }
                $groups[$key]['group_id'] = $key;
            }
            
            $groups = array_values($groups);
            $this->item['options']['product_super_attributes'] = $groups;
            $this->item['combinations'] = $combinations;
            /*
            $this->context->smarty->assign(array(
                'groups' => $groups,
                'colors' => (count($colors)) ? $colors : false,
                'combinations' => $combinations,
                'combinationImages' => $combination_images
            ));
            */
        }
    }

    public function assignCombinationPrice($combinations, $combID)
    {
        $combination = $combinations[$combID];
 
        $ecotaxTax_rate = (float)Tax::getProductEcotaxRate($this->context->cart->{Configuration::get('PS_TAX_ADDRESS_TYPE')});
        $taxRate = (float)$this->product->getTaxesRate(new Address((int)$this->context->cart->{Configuration::get('PS_TAX_ADDRESS_TYPE')}));
        $currency = Tools::setCurrency($this->context->cookie);
        //$currencyRate = (float)$currency->getConversationRate();
        $currencyRate = (float)$currency->conversation_rate;
         
        $address = new Address($this->context->cart->{Configuration::get('PS_TAX_ADDRESS_TYPE')});
        $no_tax = Tax::excludeTaxeOption() || !$this->product->getTaxesRate($address);
         
        $id_group = (int)Group::getCurrent()->id;
        $group_reduction = GroupReduction::getValueForProduct($this->product->id, $id_group);
        if ($group_reduction === false) {
            $group_reduction = Group::getReduction((int)$this->context->cookie->id_customer) / 100;
        }
         
        $productPriceTaxExcluded = $this->product->getPriceWithoutReduct(true) - $this->product->ecotax;
        $productPriceTaxIncluded = $this->product->getPriceWithoutReduct(false) - $this->product->ecotax * (1 + $ecotaxTax_rate / 100);
         
        $basePriceWithoutTax = +$productPriceTaxExcluded;
        $basePriceWithTax = +$productPriceTaxIncluded;
         
        $priceWithGroupReductionWithoutTax = 0;
        $priceWithGroupReductionWithoutTax = $basePriceWithoutTax * (1 - $groupReduction);
         
        $basePriceWithoutTax = $basePriceWithoutTax + +$combination['price'];
        $basePriceWithTax = $basePriceWithTax + +$combination['price'] * ($taxRate/100 + 1);
         
        if ($combination['specific_price'] && $combination['specific_price']['price'] > 0)
        {
            $basePriceWithoutTax = +$combination['specific_price']['price'];
            $basePriceWithTax = +$combination['specific_price']['price'] * ($taxRate/100 + 1);
        }
         
        $priceWithDiscountsWithoutTax = $basePriceWithoutTax;
        $priceWithDiscountsWithTax = $basePriceWithTax;
         
        $default_eco_tax = $this->product->ecotax;
        if ($default_eco_tax)
        {
            // combination.ecotax doesn't modify the price but only the display
            $priceWithDiscountsWithoutTax = $priceWithDiscountsWithoutTax + $default_eco_tax * (1 + $ecotaxTax_rate / 100);
            $priceWithDiscountsWithTax = $priceWithDiscountsWithTax + $default_eco_tax * (1 + $ecotaxTax_rate / 100);
            $basePriceWithTax = $basePriceWithTax + $default_eco_tax * (1 + $ecotaxTax_rate / 100);
            $basePriceWithoutTax = $basePriceWithoutTax + $default_eco_tax * (1 + $ecotaxTax_rate / 100);
        }
         
        // Apply specific price (discount)
        // We only apply percentage discount and discount amount given before tax
        // Specific price give after tax will be handled after taxes are added
        if ($combination['specific_price'] && $combination['specific_price']['reduction'] > 0)
        {
            if ($combination['specific_price']['reduction_type'] == 'amount')
            {
                if (isset($combination['specific_price']['reduction_tax']) && $combination['specific_price']['reduction_tax'] === "0")
                {
                    $reduction = $combination['specific_price']['reduction'];
                    if ($combination['specific_price']['id_currency'] == 0)
                        $reduction = $reduction * $currencyRate * (1 - $groupReduction);
                    $priceWithDiscountsWithoutTax -= $reduction;
                    $priceWithDiscountsWithTax -= $reduction * ($taxRate/100 + 1);
                }
            }
            else if ($combination['specific_price']['reduction_type'] == 'percentage')
            {
                $priceWithDiscountsWithoutTax = $priceWithDiscountsWithoutTax * (1 - +$combination['specific_price']['reduction']);
                $priceWithDiscountsWithTax = $priceWithDiscountsWithTax * (1 - +$combination['specific_price']['reduction']);
            }
        }
         
        // Apply Tax if necessary
        $noTaxForThisProduct = $no_tax;
        $customerGroupWithoutTax = Group::getPriceDisplayMethod($this->context->customer->id_default_group);
        if ($noTaxForThisProduct || $customerGroupWithoutTax)
        {
            $basePriceDisplay = $basePriceWithoutTax;
            $priceWithDiscountsDisplay = $priceWithDiscountsWithoutTax;
        }
        else
        {
            $basePriceDisplay = $basePriceWithTax;
            $priceWithDiscountsDisplay = $priceWithDiscountsWithTax;
        }
         
        // If the specific price was given after tax, we apply it now
        if ($combination['specific_price'] && $combination['specific_price']['reduction'] > 0)
        {
            if ($combination['specific_price']['reduction_type'] == 'amount')
            {
                if (isset($combination['specific_price']['reduction_tax'])
                    || (isset($combination['specific_price']['reduction_tax']) && $combination['specific_price']['reduction_tax'] === '1'))
                {
                    $reduction = $combination['specific_price']['reduction'];
                    $specific_currency=($this->product->specificPrice && $this->product->specificPrice->id_currency);
                    if (isset($specific_currency) && $specific_currency && (int) $combination['specific_price']['id_currency'] && $combination['specific_price']['id_currency'] != $currency['id'])
                        $reduction = $reduction / $currencyRate;
                    else if(!$specific_currency)
                        $reduction = $reduction * $currencyRate;
         
                    if (isset($groupReduction) && $groupReduction > 0)
                        $reduction *= 1 - (float)$groupReduction;
         
                    $priceWithDiscountsDisplay -= $reduction;
                    // We recalculate the price without tax in order to keep the data consistency
                    $priceWithDiscountsWithoutTax = $priceWithDiscountsDisplay - $reduction * ( 1/(1+$taxRate/100) );
                }
            }
        }
         
        if ($priceWithDiscountsDisplay < 0)
        {
            $priceWithDiscountsDisplay = 0;
        }
         
        // Compute discount value and percentage
        // Done just before display update so we have final prices
        if ($basePriceDisplay != $priceWithDiscountsDisplay)
        {
            $discountValue = $basePriceDisplay - $priceWithDiscountsDisplay;
            $discountPercentage = (1-($priceWithDiscountsDisplay/$basePriceDisplay))*100;
        }
         
        $unit_impact = +$combination['unit_impact'];
        $productUnitPriceRatio = $this->product->unit_price_ratio;
        $productBasePriceTaxExcl = $this->product->getPrice(false, null, 6, null, false, false);
        if ($productUnitPriceRatio > 0 || $unit_impact)
        {
            if ($unit_impact)
            {
                $baseUnitPrice = $productBasePriceTaxExcl / $productUnitPriceRatio;
                $unit_price = $baseUnitPrice + $unit_impact;
         
                if (!$noTaxForThisProduct || !$customerGroupWithoutTax)
                    $unit_price = $unit_price * ($taxRate/100 + 1);
            }
            else
                $unit_price = $priceWithDiscountsDisplay / $productUnitPriceRatio;
        }
         
        $prices['our_price'] = $priceWithDiscountsDisplay;
        if ($priceWithDiscountsDisplay != $basePriceDisplay){
            $prices['base_price'] = $basePriceDisplay;
        }
        return $prices;
    }

    /**
     * only apply for one attribute
     * @global type $cookie
     * @param type $idProductAttribute
     * @return type
     */
    public function getProductAttributePrice($combinations, $default, $id)
    {
        if ($id && $combinations) {
            $defaultList = $combinations[$this->id_product_attribute]['list'];
            $price = $combinations[$this->id_product_attribute]['price'];
            $list = str_replace($default, $id, $defaultList);
            if ($list != $defaultList) {
                foreach ($combinations as $combination) {
                    if ($list == $combination['list']) {
                        $price = ($combination['price'] - $price) * (100 - intval($this->item['discount'])) * 0.01;
                        return currency_price_value($price);
                    }
                }
            }
        }

        return 0;
    }

    /**
     * get customer selected product information
     * @param array $options
     * @return boolean
     * @author hujs
     */
    public function getIdProductAttribut(array $options, $productId)
    {

        if (empty($options)) {
            return 0;
        }

        $whereStr = join(',', $options);
        $id_product_attribute = Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
			SELECT pa.id_product_attribute
            FROM `' . _DB_PREFIX_ . 'product_attribute` pa
	        LEFT JOIN `' . _DB_PREFIX_ . 'product_attribute_combination` pac ON pac.`id_product_attribute` = pa.`id_product_attribute`
			WHERE pa.`id_product`= ' . $productId . ' AND  id_attribute in(' . $whereStr . ')
            GROUP BY id_product_attribute
            HAVING COUNT(*)=' . count($options));

        return $id_product_attribute;
    }

    public function getRecommededItems()
    {
        $this->item['recommended_items'] = array();
    }

    public function getRelatedItems()
    {
        $accessories = $this->product->getAccessories($this->context->language->id);

        $products = array();
        if($accessories){
            foreach($accessories as $cp){
                if($cp['id_product'] == $this->product->id_product)
                    continue;
                
                $_product = array(
                    'product_id'            => $cp['id_product'],
                    'product_thumbnail_url' => $this->getProductImage($this->link_rewrite, $cp['id_image'], 'home'),
                    'name'                  => $cp['name'],
                    'show_price'            => $price_show,
                    'price'                 => $cp['price']
                    );
                $_product['product_small_image_url'] = $_product['product_thumbnail_url'];
                $_product['stock_status'] = $this->allowAddToCartProduct($cp) ? true : false;
                $_product['available_for_order'] = $cp['available_for_order'];
                $_product['review_summary'] = $this->getReviewSummary($cp['id_product']);
                $_product['ratingOptions'] = $this->getRatingOptions($cp['id_product']);
                $products[] = $_product;
            }
        }
        //echo '<pre>';print_r($products);exit;
        $this->item['relatedProducts']['products'] = $products;
    }

    public function allowAddToCartProduct($product)
    {
        return (!isset($product['available_for_order']) || $product['available_for_order']) &&
                $product['customizable'] != 2 &&
                !Configuration::get('PS_CATALOG_MODE') &&
                ($product['allow_oosp'] || $product['quantity'] > 0);
    }

    public function getProductFeature()
    {
        $features = $this->product->getFrontFeatures($this->context->cookie->id_lang);
        foreach ($features as &$feature) {
            $feature['code'] = $feature['id_feature'];
            if(empty($feature['value'])){
                unset($feature['id_feature']);
            }
            else{
                $feature['relateTo'] = "description";
            }
        }

        return $features;
    }

    /**
     * get item images
     * @return int
     * @author hujs
     */
    public function getItemImgs()
    {
        $this->item['short_description'] = $this->description_short;
        $this->item['description'] = preg_replace('/(<img[^<^>]+?src\s*=\s*(\"|\'))([^:^\"^\']+\2)/i', '$1' . _PS_BASE_URL_ . '/$2', $this->description);
        //$this->item['specifications'] = $this->getProductFeature();
        $this->item['customAttributes'] = $this->getProductFeature();

        $imgs = array();
        $images = $this->product->getImages($this->context->cookie->id_lang);

        $pos = 0;
        foreach ($images as $row) {
            $imageId = $this->id_product . '-' . $row['id_image'];
            $imgs[] = array(
                'id' => $row['id_image'],
                'full_image_url' => $this->getProductImage($this->link_rewrite, $imageId, 'large'),
                'position' => $pos++,
                'label' => ""
            );
        }

        if (!$imgs) {
            $imgs[] = array(
                'id' => '1',
                'full_image_url' => $this->getProductImage($this->link_rewrite, $this->id_image, 'large'),
                'position' => $pos,
                'label' => ""
            );
        }
        $this->item['product_images'] = $imgs;
        return $imgs;
    }

    public function clear()
    {
        $this->product = null;
        $this->item = array();
    }

    public function setProduct($product)
    {
        if (is_array($product)) {
            if (!isset($product['id_image'])) { //cid = -1
                $productId = $product['id_product'];
                $imageId = Product::getCover($productId);
                $product['id_image'] = $productId . '-' . $imageId['id_image'];
            }

            empty($product['id_product_attribute']) && $product['id_product_attribute'] = Product::getDefaultAttribute($productId);
            if (!isset($product['quantity']) || empty($product['quantity'])) {
                $product['quantity'] = Product::getQuantity($product['id_product'], $product['id_product_attribute']);
            }
            //$product['product_reviews'] = $this->getProductComments($productId);
            addImageRatio($product);

            $this->product = $product;
            $this->isArray = true;
        }
    }

    public function loadProductById($productId)
    {
        if (is_numeric($productId)) {
            $this->product = new Product($productId, true, $this->context->cookie->id_lang);
            $imageId = Product::getCover($productId);

            $this->isArray = false;
            $this->product->id_image = $productId . '-' . $imageId['id_image'];
            $this->product->id_image = Product::defineProductImage( $imageId, $this->context->cookie->id_lang);
            $this->product->id_product = $productId;
            $this->product->id_product_attribute = Product::getDefaultAttribute($productId);

            if (!$this->product->quantity) {
                $this->product->quantity = Product::getQuantity($productId, $this->product->id_product_attribute);
            }
            $this->item['max_qty'] = $this->product->quantity;
            $this->item['combinations'] = $this->product->getAttributeCombinations($this->context->language->id);
            $this->product->allow_oosp = Product::isAvailableWhenOutOfStock($this->product->out_of_stock);
        }
    }

    public function __get($name)
    {
        if ($this->product) {
            if ($this->isArray) {
                return $this->product[$name];
            } else {
                return $this->product->{$name};
            }
        } else {
            return null;
        }
    }

    public function __isset($name)
    {
        if ($this->product) {
            if ($this->isArray) {
                return isset($this->product[$name]);
            } else {
                return isset($this->product->{$name});
            }
        } else {
            return false;
        }
    }

    public function getListingItemInfo()
    {
        $this->getItemBaseInfo();
        if ($this->isArray) {
            $this->loadProductById($this->id_product);
        }
        $this->getItemPrices();
        $this->assignAttributesGroups();
        $this->getItemImgs();
        $this->getGroceryItems();
        return $this->getTranslatedItem();
    }

    public function getFullItemInfo()
    {
        $this->getItemBaseInfo();
        if ($this->isArray) {
            $this->loadProductById($this->id_product);
        }
        $this->getItemPrices();
        $this->assignAttributesGroups();
        $this->getItemImgs();
        $this->getRelatedItems();
        $this->getGroceryItems();
        return $this->getTranslatedItem();
    }

    public function getGroceryItems()
    {
        bindProductListingGrocery($this->item);
    }
}
