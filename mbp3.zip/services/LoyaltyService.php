<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE')) {
    header('HTTP/1.1 404 Not Found');
    die();
}

/**
 * Checkout utility
 * @package services
 * @author hujs
 */
class LoyaltyService extends BaseService
{
    private $errors = array();
    private $context;

    public function __construct()
    {
        parent::__construct();
        ServiceFactory::factory('Mobicommercehelper')->autoLoginMobileUser();

        $this->context = Context::getContext();

        include_once(_PS_ROOT_DIR_.'/modules/loyalty/LoyaltyModule.php');
        include_once(_PS_ROOT_DIR_.'/modules/loyalty/LoyaltyStateModule.php');
    }

    public function getLoyaltyPoints($p = 0, $n = 0)
    {
        $displayorders = LoyaltyModule::getAllByIdCustomer(
            (int)$this->context->customer->id,
            (int)$this->context->language->id, false, true,
            $n,
            $p
        );

        $count = LoyaltyModule::getAllByIdCustomer(
            (int)$this->context->customer->id,
            (int)$this->context->language->id, false, true,
            5000,
            $p
        );

        $customer_points = (int)LoyaltyModule::getPointsByCustomer((int)$this->context->customer->id);
        $transformation_allowed = $customer_points > 0;
        $transformation_text = "";
        if($transformation_allowed){
            $transformation_text = $this->l("Transform my points into a voucher of", array(
                'mod' => 'loyalty',
                'modtpl' => 'loyalty',
                ));
            $transformation_text .= " ";
            $transformation_text .= LoyaltyModule::getVoucherValue($customer_points, (int)$this->context->currency->id);
        }
        $total_points_text = $this->l("Your total points available to be used:", array(
            'mod' => 'loyalty',
            'modtpl' => 'loyalty',
            ));

        $nb_discounts = 0;
        $discounts = array();
        //if ($ids_discount = LoyaltyModule::getDiscountByIdCustomer((int)$this->context->customer->id))
        if ($ids_discount = $this->getDiscountByIdCustomer((int)$this->context->customer->id))
        {
            $nb_discounts = count($ids_discount);
            foreach ($ids_discount as $key => $discount)
            {
                $discounts[$key] = new CartRule((int)$discount['id_cart_rule'], (int)$this->context->cookie->id_lang);
                $discounts[$key]->orders = LoyaltyModule::getOrdersByIdDiscount((int)$discount['id_cart_rule']);
            }
        }

        if(!empty($discounts)){
            $final = array();
            foreach ($discounts as $key => $value) {
                $value = (array)$value;
                $value['date_add'] = date('Y-m-d', strtotime($value['date_add']));
                $value['date_from'] = date('Y-m-d', strtotime($value['date_from']));
                $value['date_to'] = date('Y-m-d', strtotime($value['date_to']));
                $qty = $value['quantity'];
                //if($qty > 0){
                    $value['status'] = $this->l("Ready to use", array(
                        'mod' => 'loyalty',
                        'modtpl' => 'loyalty',
                        ));
                //}
                //print_r($value);exit;
                $final[] = $value;
            }
            $discounts = $final;
        }

        $title = $this->l("My vouchers from loyalty points", array(
            'mod' => 'loyalty',
            'modtpl' => 'loyalty',
            ));

        $minimum_text = $this->l("The minimum order amount in order to use these vouchers is:", array(
                'mod' => 'loyalty',
                'modtpl' => 'loyalty',
                ));

        $minimalLoyalty = (float)Configuration::get('PS_LOYALTY_MINIMAL');
        $minimum_text = $minimum_text.' '. $minimalLoyalty;
        
        $result = array(
            //'list'                => $displayorders,
            'list'                => $discounts,
            'count'               => $nb_discounts,
            'category_text'       => $this->getCategoryText(),
            'transformation_text' => $transformation_text,
            'total_points'        => $customer_points,
            'total_points_text'   => $total_points_text,
            'title'               => $title,
            'minimum_text'        => $minimum_text
            );
        return $result;
        //echo '<pre>';print_r($displayorders);exit;
    }

    public function getCategoryText()
    {
        $all_categories = Category::getSimpleCategories((int)$this->context->cookie->id_lang);
        $voucher_categories = Configuration::get('PS_LOYALTY_VOUCHER_CATEGORY');
        if ($voucher_categories != '' && $voucher_categories != 0)
            $voucher_categories = explode(',', Configuration::get('PS_LOYALTY_VOUCHER_CATEGORY'));
        else
            die(Tools::displayError());

        if (count($voucher_categories) == count($all_categories))
            $categories_names = null;
        else
        {
            $categories_names = array();
            foreach ($all_categories as $k => $all_category)
                if (in_array($all_category['id_category'], $voucher_categories))
                    $categories_names[$all_category['id_category']] = trim($all_category['name']);
            if (!empty($categories_names)){
                //$categories_names = Tools::truncate(implode(', ', $categories_names), 100).'.';
                $categories_names = implode(', ', $categories_names);
            }
            else
                $categories_names = null;
        }

        $text = $this->l("Vouchers generated here are usable in the following categories : ", array(
            'mod' => 'loyalty',
            'modtpl' => 'loyalty',
            ));
        if($categories_names){
            $text .= $categories_names;
        }
        else{
            $text .= $this->l("All", array(
                'mod' => 'loyalty',
                'modtpl' => 'loyalty',
                ));
        }
        return $text;
    }

    public function getDiscountByIdCustomer($id_customer, $last = false)
    {
        $query = '
        SELECT f.id_cart_rule AS id_cart_rule, f.date_upd AS date_add
        FROM `'._DB_PREFIX_.'loyalty` f
        LEFT JOIN `'._DB_PREFIX_.'orders` o ON (f.`id_order` = o.`id_order`)
        INNER JOIN `'._DB_PREFIX_.'cart_rule` cr ON (cr.`id_cart_rule` = f.`id_cart_rule`)
        WHERE f.`id_customer` = '.(int)($id_customer).'
        AND f.`id_cart_rule` > 0
        AND o.`valid` = 1
        AND quantity > 0
        GROUP BY f.id_cart_rule';
        if ($last)
            $query.= ' ORDER BY f.id_loyalty DESC LIMIT 0,1';

        return Db::getInstance()->executeS($query);
    }
}
