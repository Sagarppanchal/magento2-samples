<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE')) {
    header('HTTP/1.1 404 Not Found');
    die();
}

/**
 * Order Service, Utility
 * @package services 
 */
class OrderService extends BaseService
{
    public function __construct()
    {
        parent::__construct();
        ServiceFactory::factory('Mobicommercehelper')->autoLoginMobileUser();
    }

    /** new
     * get user orders information
     * @param type $userId
     * @return type 
     * @author hujs
     */
    public function getOrderInfos(array $parameter)
    {
        $orderInfos = array();

        $pageNo = $parameter['page_no'];
        $pageSize = $parameter['page_size'];

        $orders = $this->getOrderList($pageNo, $pageSize);
        
        foreach ($orders as $value) {
            $order = new Order($value['id_order']);
            $orderItem = array();

            $this->initOrderDetail($orderItem, $order);
            $orderItem['price_infos'] = $this->getPriceInfos($orderItem, $order);
            $orderItem['order_items'] = $this->getOrderItems($order,$nbTotalProducts);
            $orderItem['total_qty_ordered'] = count($orderItem['order_items']);

            /* added by Yash */
            $orderItem['entity_id'] = $value['id_order'];
            $orderItem['created_at'] = $order->date_add;
            /* added by Yash - upto here */
            $orderItem = arrangeOrderDetailData($orderItem);
            $orderInfos[] = $orderItem;
        }

        return array('ordersCount' => $this->getUserOrderCounts(), 'orders' => $orderInfos);
    }

    public function encrypt_decrypt($action, $string) {
        $output = false;

        $encrypt_method = "AES-256-CBC";
        $secret_key = 'This is my secret key';
        $secret_iv = 'This is my secret iv';

        // hash
        $key = hash('sha256', $secret_key);
        
        // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
        $iv = Tools::substr(hash('sha256', $secret_iv), 0, 16);

        if( $action == 'encrypt' ) {
            $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
            $output = base64_encode($output);
        }
        else if( $action == 'decrypt' ){
            $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
        }

        return $output;
    }

    /**
     * get order detail information
     * @param type $orderId
     * @return type
     * @author hujs
     */
    public function getOneOrderInfoById($orderId, $cartId = 0)
    {
        /* for ktc */
        if(Tools::strlen($orderId) >= 28){
            $Ref = $orderId;
            $Ref = $this->encrypt_decrypt('decrypt',$Ref);
            $cart_id = $Ref;
            $order = New Order();
            $orderId = $order->getOrderByCartId($cart_id);
        }
        /* for ktc upto here */

        /* for sid payment gateway */
        if(!empty($cartId)){
            $orderId = Order::getOrderByCartId((int)($cartId));
        }
        /* for sid payment gateway - upto here */

        $orderItem = array();

        $order = $this->getOneOrder($orderId);
        $this->initOrderDetail($orderItem, $order);
        $orderItem['price_infos']     = $this->getPriceInfos($orderItem, $order);
        $orderItem['order_items']     = $this->getOrderItems($order, $nbTotalProducts);
        $orderItem['shippingAddress'] = $this->getShippingAddress($order);
        $orderItem['billingAddress']  = $this->getBillingAddress($order, $orderItem['shipping_address']);
        $orderItem['allow_reorder'] = true;
        $orderItem['total_qty_ordered'] = $nbTotalProducts;

        /* added by Yash */
        $orderItem['order_id'] = $orderId;
        /* added by Yash - upto here */
        $orderItem = arrangeOrderDetailData($orderItem);
        return $orderItem;
    }

    public function reOrder($id_order)
    {
        $errors = array();
        $oldCart = new Cart(Order::getCartIdStatic($id_order, $this->context->customer->id));
        $duplication = $oldCart->duplicate();
        if (!$duplication || !Validate::isLoadedObject($duplication['cart']))
            $errors[] = Tools::displayError('Sorry. We cannot renew your order.');
        elseif (!$duplication['success'])
            $errors[] = Tools::displayError('Some items are no longer available, and we are unable to renew your order.');
        else
        {
            $this->context->cookie->id_cart = $duplication['cart']->id;
            $context = $this->context;
            $context->cart = $duplication['cart'];
            CartRule::autoAddToCart($context);
            $this->context->cookie->write();
            return array(true, 'success');
        }
        return array(false, implode(', ', $errors));
    }

    public function getPaymentOrderInfo($order, $tx = '')
    {
        $orderItem = array();
        $orderId = false;

        if ($order) {
            $orderItem['display_id'] = $orderId = $order->id;
            $orderItem['shipping_address'] = $this->getShippingAddress($order);
            $orderItem['price_infos'] = $this->getPaymentPriceInfos($order);
            $orderItem['order_items'] = $this->getPaymentOrderItems($order);

            $total = $order->total_paid;
            $currencyDate = Currency::getCurrency($order->id_currency);
            $currency = $currencyDate['iso_code'];
        } else {
            $total = 0;
            $currency = $this->context->cookie->currency;
        }

        return array(
            'transaction_id' => $tx,
            'payment_total'  => $total,
            'currency'       => $currency,
            'order_id'       => $orderId,
            'orders'         => sizeof($orderItem) ? array($orderItem) : false,

            //added by yash
            'invoice_number' => $order->reference,
            'orders' => $this->getOrderInfos(array(
                'page_no'   => '1',
                'page_size' => '30',
                ))
        );
    }

    public function getPaymentPriceInfos($order)
    {
        $info = array();

        $info[] = array(
            'type' => 'total',
            'home_currency_price' => $order->total_paid
        );

        $info[] = array(
            'type' => 'shipping',
            'home_currency_price' => $order->total_shipping
        );

        $tax = $order->getTotalProductsWithTaxes() - $order->getTotalProductsWithoutTaxes();
        $info[] = array(
            'type' => 'tax',
            'home_currency_price' => $tax
        );

        return $info;
    }

    public function getPaymentOrderItems($order)
    {
        $items = array();
        $cart = new Cart($order->id_cart);
        $products = $cart->getProducts();
        foreach ($products as $product) {
            $items[] = array(
                'order_item_key' => $product['id_product'],
                'item_title' => $product['name'],
                'category_name' => '',
                'home_currency_price' => $product['price_wt'],
                'qty' => $product['cart_quantity']
            );
        }

        return $items;
    }

    /**
     * get one order detail information
     * @param type $orderItem
     * @param type $order
     * @author hujs
     */
    public function initOrderDetail(&$orderItem, $order)
    {
        $payMethod = array('pm_id' => '',
            'title' => $order->payment,
            'description' => '');
        //print_r($order);exit;
        $orderState = OrderHistory::getLastOrderState($order->id);
        $Carrier = new Carrier($order->id_carrier);
        $currency = Currency::getCurrency($order->id_currency);
        $orderItem = array(
            'order_id'           => $order->id,
            'increment_id'       => $order->reference,
            'currency'           => $currency['iso_code'],
            'shipping_address'   => array(),
            'billing_address'    => array(),
            'payment_method'     => $payMethod['title'],
            'shipping_method'    => $Carrier->name,
            'shipping_insurance' => 0,
            'coupon'             => '',
            'order_status'       => $orderState,
            'last_status_id'     => $orderState->id,
            'grand_total'        => $order->total_paid,
            'subtotal'           => $order->total_products,
            's_fee'              => $order->total_shipping,
            'tax'                => ($order->total_paid_tax_incl-$order->total_paid_tax_excl),
            'order_tax_rate'     => $order->carrier_tax_rate,
            'discount'           => $order->total_discounts,
            'order_note'         => $order->gift_message,
            'created_at'         => $order->date_add,
            'order_date'         => $order->date_add,
            );

        $status = $this->getOrderHistory($order);
        $orderItem['order_status'] = $status;
        $orderItem['status'] = (isset($status[0]['status_id'])?$status[0]['display_text']:"");
        $orderItem['statusLabel'] = (isset($status[0]['display_text'])?$status[0]['display_text']:"");
    }

    /**
     * get order ship address
     * @param $order
     * @return array
     * @author hujs
     */
    private function getShippingAddress($order)
    {
        $addr = ServiceFactory::factory('User')->getAddress($order->id_address_invoice);
        $country = new Country($addr['country_id']);
        $zone = new Zone($country->id_zone);

        $address = array('address_book_id' => $addr['address_book_id'],
            'address_type' => 'ship',
            'lastname'     => $addr['lastname'],
            'firstname'    => $addr['firstname'],
            'name'         => $addr['firstname'].' '.$addr['lastname'],
            'telephone'    => $addr['telephone'],
            'mobile'       => $addr['mobile'],
            'gender'       => '',
            'zip'          => $addr['postcode'],
            'city'         => $addr['city'],
            'zone_id'      => $zone->id,
            'zone_code'    => $zone->iso_code,
            'zone_name'    => $zone->name,
            'state_name'   => $addr['state'],
            'street'       => array_filter(array($addr['address1'],$addr['address2'])),
            'country_id'   => strval($country->id),
            'country_code' => $country->iso_code,
            'country'      => is_array($country->name) ? $country->name[1] : $country->name,
            'company'      => $addr['company']);

        return $address;
    }

    /**
     * get order bill address
     * @param $order
     * @return array
     * @author hujs
     */
    private function getBillingAddress($order, $shippingAddress = false)
    {
        if ($order->id_address_delivery == $order->id_address_invoice && $shippingAddress) {
            $address = $shippingAddress;
            $address['address_type'] = 'bill';

            return $address;
        }

        $addr = ServiceFactory::factory('User')->getAddress($order->id_address_delivery);
        $country = new Country($addr['country_id']);
        $zone = new Zone($country->id_zone);

        $address = array(
            'address_book_id' => $addr['address_book_id'],
            'address_type'    => 'bill',
            'lastname'        => $addr['lastname'],
            'firstname'       => $addr['firstname'],
            'name'            => $addr['firstname'].' '.$addr['lastname'],
            'telephone'       => $addr['telephone'],
            'mobile'          => $addr['mobile'],
            'gender'          => '',
            'zip'             => $addr['postcode'],
            'city'            => $addr['city'],
            'zone_id'         => $zone->id,
            'zone_code'       => $zone->iso_code,
            'zone_name'       => $zone->name,
            'state_name'      => $addr['state'],
            'street'          => array_filter(array($addr['address1'],$addr['address2'])),
            'country_id'      => strval($country->id),
            'country_code'    => $country->iso_code,
            'country'         => is_array($country->name) ? $country->name[1] : $country->name,
            'company'         => $addr['company']);

        return $address;
    }

    /**
     * get order price information
     * @global type $currencies
     * @param array $order
     * @author hujs
     */
    public function getPriceInfos(&$orderItem, $order)
    {
        $info = array();
        $postion = 0;

        $carrier = new Carrier($order->id_carrier);
        $currency = new Currency($order->id_currency);
        /*
        $orderItem['shipping_method'] = array('pm_id' => '',
            'title' => $carrier->name,
            'description' => '',
            'price' => $order->total_shipping);
            */
        // changed by Yash
        $orderItem['shipping_method'] = $carrier->name;

        if ($this->priceDisplay && $this->withTax) {
            $info[] = array(
                'title' => $this->l('Total products (tax excl.):'),
                'type' => 'tax',
                'price' => $order->getTotalProductsWithoutTaxes(),
                'currency' => $currency->iso_code,
                'position' => $postion++);
        }

        $info[] = array(
            'title'    => $this->l('Total products' . ($this->withTax ? ' (tax incl.):' : ':')),
            'type'     => 'subtotal',
            'price'    => $order->getTotalProductsWithTaxes(),
            'currency' => $currency->iso_code,
            'position' => $postion++
            );

        if ($order->total_discounts > 0) {
            $info[] = array(
                'title'    => $this->l('Total vouchers:'),
                'type'     => 'discount',
                'price'    => $order->total_discounts,
                'currency' => $currency->iso_code,
                'position' => $postion++
                );
        }

        if ($order->total_wrapping > 0) {
            $info[] = array(
                'title'    => $this->l('Total vouchers:'),
                'type'     => 'vouchers',
                'price'    => $order->total_wrapping,
                'currency' => $currency->iso_code,
                'position' => $postion++
                );
        }

        $info[] = array(
            'title'    => $this->l('Total shipping' . ($this->withTax ? ' (tax incl.):' : ':')),
            'type'     => 'shipping',
            'price'    => $order->total_shipping,
            'currency' => $currency->iso_code,
            'position' => $postion++
            );

        $info[] = array(
            'title'    => $this->l('Total:'),
            'type'     => 'total',
            'price'    => $order->total_paid,
            'currency' => $currency->iso_code,
            'position' => $postion++
            );


        return $info;
    }

    /**
     * get order items
     * @param array $order
     * @return array
     * @author hujs
     */
    public function getOrderItems($order,&$nbTotalProducts=0)
    {
        $items = array();
        $cart = new Cart($order->id_cart);
        $products = $cart->getProducts();
        foreach ($products as $row) {
            $productId = $row['id_product'];
            $nbTotalProducts += intval($row['cart_quantity']);

            $options = array();
            $attributes = isset($row['attributes']) ? explode(',',  $row['attributes']) : array();
            if($attributes) {
                foreach ($attributes as $_attribute) {
                    $_attribute = explode(':', $_attribute);
                    $options[] = array(
                        'option_title' => $_attribute[0],
                        'option_value' => $_attribute[1]
                        );
                }
            }
            $_item = array(
                'order_item_id'    => $productId . ':' . $row['product_attribute_id'],
                'product_id'       => $productId,
                'options'          => $options,
                'product_name'     => $row['name'],
                'product_image'    => $this->getProductImage($row['link_rewrite'], $row['id_image'], 'home'),
                'product_qty'      => $row['cart_quantity'],
                'product_price'    => $row['price_wt'],
                'product_subtotal' => $row['total_wt'],
                'discount'         => $row['reduction_applies'],
                's_fee'            => $row['additional_shipping_cost'],
                'order_total'      => $row['total_wt'],
                );
            addImageRatio($_item);

            $items[] = $_item;
        }

        return $items;
    }

    /**
     * get order history information by id
     * @param type $orderId
     * @return type
     * @author hujs
     */
    public function getOrderHistory($order)
    {
        $info = array();
        $postion = 0;

        $rows = $order->getHistory($this->context->cookie->id_lang);
        foreach ($rows as $row) {
            $info[] = array(
                'status_id'    => $row['id_order_state'],
                'status_name'  => $row['ostate_name'],
                'display_text' => $row['ostate_name'],
                'language_id'  => $this->context->cookie->id_lang,
                'date_added'   => $row['date_add'],
                'comments'     => '',
                'position'     => $postion++
                );
        }

        return $info;
    }

    /**
     * get orders information
     * @param type $userId
     * @return array
     * @author hujs
     */
    public function getOrderList($pageNo, $pageSize)
    {
        $start = ($pageNo - 1) * $pageSize;
        $userId = $this->context->cookie->id_customer;
        
        $orders = Db::getInstance(_PS_USE_SQL_SLAVE_)->ExecuteS("
			SELECT id_order
			FROM `" . _DB_PREFIX_ . "orders`
            WHERE id_customer =  $userId
			ORDER BY `date_add` DESC
			LIMIT $start, $pageSize");
        return $orders;
    }

    /**
     * get one order information by order id 
     * @param type $orderId
     * @return type
     */
    public function getOneOrder($orderId)
    {
        return new Order($orderId);
    }

    /**
     * get user order count
     * @param type $userId
     * @return int
     * @author hujs
     */
    public function getUserOrderCounts()
    {
        return (isset($this->context->cookie->id_customer)) ? Order::getCustomerNbOrders($this->context->cookie->id_customer) : 0;
    }
}
