<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

/**
 * ShoppingCart Service,Utility
 * @package services 
 * @author hujs
 */
class ShoppingCartService extends BaseService
{
    public $mod = 'blockcart';
    protected $onepagecheckoutps = false;

    public function __construct()
    {
        parent::__construct();
        ServiceFactory::factory('Mobicommercehelper')->autoLoginMobileUser();
    }

    /**
     * Get Cart detailed information
     * @author hujs
     */
    public function get()
    {
        $result = array();

        $result['cart_id'] = $this->context->cart->id;
        $result['items'] = $this->getProducts($nbTotalProducts);
        $result['is_virtual'] = $this->context->cart->isVirtualCart();
        $this->initShoppingCartGetReslut($result);
        $result['shipping_address'] = ServiceFactory::factory('Checkout')->getShippingAddress();
        $result['billing_address'] = ServiceFactory::factory('Checkout')->getBillingAddress();                
        $result['price_infos'] = $this->getPriceInfo();
        $result['cart_qty'] = $nbTotalProducts;

        /*
        $this->context->cookie->coupon && $result['couponcode'] = $this->context->cookie->coupon;
        */
        $discounts = $this->context->cart->getCartRules();
        if($discounts){
            foreach($discounts as $_discount){
                $result['couponcode'] = $_discount['code'];
            }
        }
        
        if($this->context->cookie->id_customer) {
            $result['is_session'] = '1';
        }

        $total = $this->context->cart->getOrderTotal(true,BOTH,null,$this->context->cookie->id_carrier);
        $discount = $this->context->cart->getOrderTotal(true, ONLY_DISCOUNTS);
        $totalWithoutTax = $this->context->cart->getOrderTotal(false,BOTH,null,$this->context->cookie->id_carrier);
        $result['subtotal'] = $this->context->cart->getOrderTotal(false, Cart::ONLY_PRODUCTS);
        $result['shipping_description'] = "";

        $base_total_tax_inc = $this->context->cart->getOrderTotal(true);
        $base_total_tax_exc = $this->context->cart->getOrderTotal(false);

        $total_tax = $base_total_tax_inc - $base_total_tax_exc;
        $result['tax_amount'] = $total_tax;

        $result['discount_amount'] = $discount;
        $result['grand_total'] = $this->context->cart->getOrderTotal(true);
        //added by yash
        if(isset($result['price_infos']['shipping']))
        {
            $result['shipping_address']['shipping_method'] = $result['price_infos']['shipping']['title'];
            $result['shipping_address']['shipping_description'] = $result['price_infos']['shipping']['title'];
            $result['shipping_address']['shipping_amount'] = $this->context->cart->getTotalShippingCost(null, false);
        }
        
        if(isset($_REQUEST['payment']['method']) && $_REQUEST['payment']['method'] == 'cashondeliveryplus')
        {
            $dobirecne = ServiceFactory::factory('MobicommercePayment')->getDobirecne();
            if($dobirecne > 0)
            {
                $result['paymentinfo']['fee'] = $dobirecne;
                $result['paymentinfo']['title'] = 'Cuota adicional por forma de pago';
            }
        }

        $shipping_method = (int) $this->context->cart->id_carrier;
        if($shipping_method)
        {
            $carriers = Carrier::getCarriers($this->context->cookie->id_lang);
            foreach($carriers as $_carrier)
            {
                if($_carrier['id_carrier'] == $shipping_method)
                {
                    $result['shipping_address']['shipping_description'] = $_carrier['name'];
                }
            }
        }

        $result['minimum_order_amount'] = array(
            'active'      => '0',
            'amount'      => '0',
            'description' => '',
            );
        /* for totallydresseted */
        //$result['pay_with_amazon_button'] = $this->hookDisplayShoppingCart();
        /* for totallydresseted - upto here */
        $result = arrangeCartData($result);
        return $result;
    }

    public function _getCartLoyaltyPointText()
    {
        include_once(_PS_ROOT_DIR_.'/modules/loyalty/LoyaltyModule.php');
        $context = Context::getContext();
        $params['cart'] = $context->cart;
        if (Validate::isLoadedObject($params['cart']))
        {
            $points = (int)LoyaltyModule::getCartNbPoints($params['cart']);
            $voucher = LoyaltyModule::getVoucherValue((int)$points);
        }
        else
            $points = 0;

        $message = array();
        if($points > 0){
            $message[] = $this->l("By checking out this shopping cart you can collect up to", array(
                'mod' => 'loyalty',
                'modtpl' => 'shopping-cart',
                ));

            if($points > 1){
                 $message[] = $this->l("$points loyalty points", array(
                    'mod' => 'loyalty',
                    'modtpl' => 'shopping-cart',
                    ));
            }
            else{
                $_message = $this->l("%d loyalty points", array(
                    'mod' => 'loyalty',
                    'modtpl' => 'shopping-cart',
                    ));

                 $_message = str_replace("%d", $points);
                 $message[] = $_message;
            }
            $message[] = $this->l("that can be converted into a voucher of", array(
                'mod' => 'loyalty',
                'modtpl' => 'shopping-cart',
                ));
            $message[] = Tools::displayPrice($voucher, Context::getContext()->currency);
        }
        else{
            $message[] = $this->l("Add some products to your shopping cart to collect some loyalty points.", array(
                'mod' => 'loyalty',
                'modtpl' => 'shopping-cart',
                ));
        }
        return implode(' ', $message);
    }

    public function hookDisplayShoppingCart()
    {
        $str = '';
        $_dir = _PS_ROOT_DIR_.'/modules/pwapresta';
        //echo $_dir;exit;
        $context = Context::getContext();
        //check PWA is enable if yes then show Pay With Amazon button on cart page
        if ( Configuration::get('PWAPRESTA_PWAPRESTA_ENABLE') )
        { 
            if( Configuration::get('PWAPRESTA_PWAPRESTA_SHOW_CART_BUTTON') )            
            {
                if( Configuration::get('PWAPRESTA_PWAPRESTA_BTN_SHOW') == 'loggeed' && $context->customer->isLogged())
                {
                    if ( ! defined( 'PWA_MODULE_DIR' ) ) {
                        define( 'PWA_MODULE_DIR' , dirname($_dir.'/pwapresta.php'));
                    }
                    include_once( $_dir.'/'.'includes/class-pwapresta.php' );
                    $cba = new PWA_Cba();   
                    $str = $cba->pay_with_amazon_button('cart');
                }
        
                if( Configuration::get('PWAPRESTA_PWAPRESTA_BTN_SHOW') == 'notlogged')
                {
                    if ( ! defined( 'PWA_MODULE_DIR' ) ) {
                        define( 'PWA_MODULE_DIR' , dirname($_dir.'/pwapresta.php'));
                    }
                    include_once( $_dir.'/'.'includes/class-pwapresta.php' );
                    $cba = new PWA_Cba();   
                    $str = $cba->pay_with_amazon_button('cart');
                }
            }
        }
        $str = explode('function callme()', $str);
        $str = explode('function call_again()', $str[1]);
        $str = $str[0];
        $str = str_replace(
            array("\r\n", "\n"),
            array(" ", " "),
            $str
            );
        $str = "app.f.callmeamazon = function()".$str;
        return $str;
    }
        
    public function getPaymentMethods()
    {
        $base_url = $this->getBaseUrl();
        
        $methods = array();
        $paymentMethods = PaymentModule::getPaymentModules();

        //Customization for jenil parmar ayurvedamart
        //$paymentdata = Tools::unSerialize(Configuration::get('VELOCITY_SUPERCHECKOUT_DATA'));
        //Customization for jenil parmar ayurvedamart end
        $restrictedPaymentGateways = $this->_getRestrictedPaymentGateways();
        $context = Context::getContext();

        if($this->onepagecheckoutps){
            $onepagecheckoutpsPaymentsArray = array();
            require_once _PS_MODULE_DIR_.'/onepagecheckoutps/onepagecheckoutps.php';
            $onepagecheckoutpsPaymentObj = new OnePageCheckoutPS();
            $onepagecheckoutpsPayments = $onepagecheckoutpsPaymentObj->loadPayment('mobicommerce');
            foreach ($onepagecheckoutpsPayments as $row) {
                $onepagecheckoutpsPaymentsArray[$row['name']] = $row;
            }
            //echo '<pre>';print_r($onepagecheckoutpsPaymentsArray);exit;
        }

        $external_payments = ServiceFactory::factory('MobicommercePayment')->getExternalPaymentMethods();
        $type18_payments = ServiceFactory::factory('MobicommercePayment')->getType18PaymentMethods();

        foreach ($paymentMethods as $key => $module) {
            $module_obj = Module::getInstanceById($module['id_module']);
            if(in_array($module_obj->name, $restrictedPaymentGateways))
                continue;

            // validation done by yash
            // dated 31-08-2016. for hook
            $validate = true;
            try{
                if(method_exists($module_obj, 'hookPayment')) {
                    if(!$module_obj->hookPayment((array)$context))
                        $validate = false;
                }
            }
            catch(Exception $e){
                
            }
            
            /**
             * added by Yash on 2017-05-31
             * for hadi checkout.bh, he has reported issue that he has disabled some payment gateways for some products, which was not working
             * code is still commented as its not further tested.
             */
            /*
            if(!Hook::exec('displayPayment', array(), (int)$module['id_module']))
                $validate = false;
            */

            if(!$validate){
                continue;
            }

            $_method = array(
                '_code'     => $module_obj->name,
                'code'      => strtoupper($module_obj->name),
                'title'     => $module_obj->displayName,
                'show_type' => 0
                );
            if($module_obj->description){
                $_method['title'] .= " ". $module_obj->description;
            }

            if(in_array($_method['_code'], array('bankwire'))){
                $_method['title'] = $this->l('Pay by bank wire', array(
                    'mod'    => 'bankwire',
                    'modtpl' => 'payment',
                    ));
                $_method['instructions'] = $this->l('(order processing will be longer)', array(
                    'mod'    => 'bankwire',
                    'modtpl' => 'payment',
                    ));
            }
            else if(in_array($_method['_code'], array('codfee'))){
                $_method['title'] = $this->l('Cash on delivery:', array(
                    'mod'    => 'codfee',
                    'modtpl' => 'payment',
                    ));

                $order_total = $this->context->cart->getOrderTotal(true, 3);
                $currency = new Currency((int)$this->context->cart->id_currency);

                $cashOnDelivery = new CodFee();
                $codfeeconf = new CodfeeConfiguration(1);
                //$codfeeconf = false;
                $fee = (float)Tools::ps_round((float)$cashOnDelivery->getFeeCost($this->context->cart, (array)$codfeeconf), 2);

                $total = $fee + $order_total;
                $fee = number_format((float)$fee, 2, '.', '');

                $instructions = Product::convertPriceWithCurrency(array('price' => $order_total, 'currency' => $currency)) .' + '. Product::convertPriceWithCurrency(array('price' => $fee, 'currency' => $currency)).' '.$this->l('(COD fee)', array(
                    'mod'    => 'codfee',
                    'modtpl' => 'payment',
                    )).' = '.Product::convertPriceWithCurrency(array('price' => $total, 'currency' => $currency));
                $_method['instructions'] = $instructions;
            }

            if(in_array($_method['_code'], $type18_payments))
            {
                $_method['show_type'] = 18;
                $_method['urls'] = array(
                    'condition' => 'LIKE',
                    'redirect_url' => '',
                    'success_url'  => 'id_order=',
                    'cancel_url'   => 'cancelled'
                    );

                if(in_array($_method['_code'], array('bankwire')))
                {
                    $_method['urls']['redirect_url'] = $base_url.'module/bankwire/payment';
                    //$_method['urls']['redirect_url'] = $base_url.'index.php?fc=module&module=bankwire&controller=payment';
                }
                else if(in_array($_method['_code'], array('cheque')))
                {
                    $_method['urls']['redirect_url'] = $base_url.'module/cheque/payment';
                    //$_method['urls']['redirect_url'] = $base_url.'index.php?fc=module&module=cheque&controller=payment';
                }
                else if(in_array($_method['_code'], array('cashondelivery')))
                {
                    $_method['urls']['redirect_url'] = $base_url.'module/cashondelivery/validation';
                    //$_method['urls']['redirect_url'] = $base_url.'index.php?fc=module&module=cashondelivery&controller=validation';
                }
                else if(in_array($_method['_code'], array('codfee')))
                {
                    $_method['urls']['redirect_url'] = $base_url.'module/codfee/payment?c=1';
                }
                else if(in_array($_method['_code'], array('satispay')))
                {
                    $_method['title'] = $this->l('Satispay', array(
                        'mod'    => 'satispay',
                        'modtpl' => 'payment',
                        )).' - Paga dal tuo cellulare';
                    $_method['urls']['redirect_url'] = $base_url.'module/satispay/payment';
                    $_method['urls']['success_url'] = 'order_id=';
                    $_method['urls']['cancel_url'] = 'step=3';
                }
                else if(in_array($_method['_code'], array('payu')))
                {
                    $_method['urls']['redirect_url'] = $base_url.'modules/payu/payment.php?mobileapp=true';
                    $_method['urls']['success_url'] = 'controller=order-detail';
                    $_method['urls']['cancel_url'] = 'cancelled=1';
                    $_method['urls']['condition'] = 'LIKE';
                }
                else if(in_array($_method['_code'], array('paytm')))
                {
                    $_method['urls']['redirect_url'] = $base_url.'index.php?fc=module&module=paytm&controller=payment';
                    $_method['urls']['success_url'] = '/status/Ok'; //or id_cart=
                    $_method['urls']['cancel_url'] = '/status/Failed';
                    $_method['urls']['condition'] = 'LIKE';
                }
            }

            if(in_array($_method['_code'], $external_payments))
            {
                $_method['show_type'] = 9;
                $_method['urls'] = array(
                    'condition' => 'LIKE',
                    'redirect_url' => '',
                    'success_url'  => 'id_order=',
                    'cancel_url'   => 'cancelled'
                    );

                if(in_array($_method['_code'], array('bankmellat')))
                {
                    $_method['urls']['redirect_url'] = $base_url.'module/bankmellat/payment';
                }
                else if(in_array($_method['_code'], array('dmtbanks')))
                {
                    $_method['urls']['redirect_url'] = $base_url.'module/dmtbanks/payment?bank=';
                }
                else if(in_array($_method['_code'], array('parsianpayment')))
                {
                    $_method['urls']['redirect_url'] = $base_url.'modules/parsianpayment/payment.php';
                }
                else if(in_array($_method['_code'], array('ebs')))
                {
                    $_method['title'] = $this->l('Pay by Debit, Credit Card or Netbanking', array('mod' => 'ebs', 'modtpl' => 'payment'));
                    $_method['urls']['redirect_url'] = $base_url.'module/ebs/payment?mobileapp=true';
                }
                else if(in_array($_method['_code'], array('paypalwithfee')))
                {
                    $_method['urls']['redirect_url'] = $base_url.'modules/'.$this->module->name.'/index.php?method=mobicommerce3.payments.paypalwithfee.redirect&appcode='.Tools::getValue('appcode').'&app_key='.Tools::getValue('app_key');
                    $_method['urls']['success_url'] = 'controller=order-detail';
                    $_method['urls']['cancel_url'] = 'order-opc.php';
                    $_method['urls']['condition'] = 'LIKE';
                }
                else if(in_array($_method['_code'], array('redsys')))
                {
                    $_method['urls']['redirect_url'] = $base_url.'modules/'.$this->module->name.'/index.php?method=mobicommerce3.payments.redsys.redirect&appcode='.Tools::getValue('appcode').'&app_key='.Tools::getValue('app_key');
                    $_method['urls']['success_url'] = 'controller=order-detail';
                    $_method['urls']['cancel_url'] = 'quick-order';
                    $_method['urls']['condition'] = 'LIKE';
                }
                else if(in_array($_method['_code'], array('paypalusa')))
                {
                    $_method['logo'] = 'https://www.paypalobjects.com/en_US/i/bnr/horizontal_solution_PPeCheck.gif';
                    $_method['urls']['redirect_url'] = $base_url.'modules/'.$this->module->name.'/index.php?method=mobicommerce3.payments.paypalusa.redirect&appcode='.Tools::getValue('appcode').'&app_key='.Tools::getValue('app_key');
                    $_method['urls']['cancel_url'] = $base_url.$this->context->cookie->iso.'/order';
                }
                else if(in_array($_method['_code'], array('paypal')))
                {
                    $_method['title'] = $this->l('Pay with your card or your PayPal account', array(
                        'mod'    => 'paypal',
                        'modtpl' => 'integral_evolution_payment',
                        ));
                    $_method['urls']['condition'] = 'LIKE';
                    //$_method['title'] = $this->l('Pay with PayPal', array('mod' => 'paypal', 'modtpl' => 'payment'));
                    $_method['logo'] = 'https://www.paypalobjects.com/en_US/i/bnr/horizontal_solution_PPeCheck.gif';
                    $_method['urls']['redirect_url'] = $base_url.'modules/'.$this->module->name.'/index.php?method=mobicommerce3.payments.paypal.redirect&appcode='.Tools::getValue('appcode').'&app_key='.Tools::getValue('app_key');
                    $_method['urls']['cancel_url'] = $base_url.$this->context->cookie->iso.'/order';
                    $_method['urls']['success_url'] = 'order_id=';
                }
                else if(in_array($_method['_code'], array('ccavenue')))
                {
                    $_method['urls']['condition'] = 'LIKE';
                    //$_method['urls']['redirect_url'] = $base_url.'modules/'.$this->module->name.'/index.php?method=mobicommerce3.payments.ccavenue.redirect&appcode='.Tools::getValue('appcode').'&app_key='.Tools::getValue('app_key');
                    $_method['urls']['redirect_url'] = $base_url.'index.php?fc=module&module=ccavenue&controller=validation';
                    $_method['urls']['success_url'] = 'id_order='; //or id_cart=
                    $_method['urls']['cancel_url'] = $base_url;
                }
                else if(in_array($_method['_code'], array('mymodpayment')))
                {
                    $_method['title'] = "Pay with MPU Payment";
                    $_method['logo'] = $base_url.'modules/mymodpayment/views/img/mymodpayment.png';
                    $_method['urls']['condition'] = 'LIKE';
                    $_method['urls']['redirect_url'] = $base_url.'module/mymodpayment/payment';
                    $_method['urls']['success_url'] = 'order_id=';
                    $_method['urls']['cancel_url'] = 'mymodpayment/validation?status=PR';
                }
                else if(in_array($_method['_code'], array('pwapresta')))
                {
                    $_method['urls']['redirect_url'] = $base_url.'modules/pwapresta/pwapresta.php';
                }
                else if(in_array($_method['_code'], array('ktc')))
                {
                    $_method['urls']['condition'] = 'LIKE';
                    $_method['urls']['redirect_url'] = $base_url.'module/ktc/payment';
                    $_method['urls']['success_url'] = 'module/ktc/paymentSuccess';
                    $_method['urls']['cancel_url'] = 'module/ktc/paymentCancel';
                    $_method['urls']['fail_url'] = 'module/ktc/paymentFail';
                }
                else if(in_array($_method['_code'], array('sid')))
                {
                    $_method['urls']['condition'] = 'LIKE';
                    $_method['urls']['redirect_url'] = $base_url.'modules/sid/redirect.php';
                    $_method['urls']['success_url'] = 'id_cart=';
                    $_method['urls']['cancel_url'] = 'order.php?step=3';
                }
                else if(in_array($_method['_code'], array('setcomhf')))
                {
                    $_method['urls']['condition'] = 'LIKE';
                    $_method['urls']['redirect_url'] = $base_url.'modules/'.$this->module->name.'/index.php?method=mobicommerce3.payments.setcomhf.redirect&appcode='.Tools::getValue('appcode').'&app_key='.Tools::getValue('app_key');
                    $_method['urls']['success_url'] = 'id_order=';
                    $_method['urls']['cancel_url'] = 'Outcome=Error';
                }
                else if(in_array($_method['_code'], array('bankwirethai')))
                {
                    $bank_options = array();
                    include_once _PS_MODULE_DIR_.'bankwirethai/bankwirethai.php';
                    $banks = new BankWireThai();
                    $banks = $banks->banks->getAllBank(true);
                    //echo '<pre>';print_r($banks);exit;
                    foreach($banks as $_bank){
                        //$_bank = (array)$_bank;
                        $_method = array(
                            '_code'     => $module_obj->name,
                            'code'      => strtoupper($module_obj->name),
                            'title'     => $module_obj->displayName,
                            'show_type' => 9
                            );
                        /*
                        $_method['params']['bankwirethai'] = '1';
                        $_method['params']['account_name'] = $_bank->owner[1];
                        $_method['params']['account_number'] = $_bank->account_number[1];
                        $_method['params']['branch'] = $_bank->branch[1];
                        */
                        //echo '<pre>';print_r($_method);exit;
                        //$methods[] = $_method;

                        $_bank_option = array(
                            'bank_code' => $_bank->bank_swift_code,
                            //'image' => '',
                            'bank_name' => $_bank->bank_name[1],
                            'account_name' => $_bank->owner[1],
                            'account_number' => $_bank->account_number[1],
                            'branch' => $_bank->branch[1]
                            );
                        $bank_options[] = $_bank_option;
                    }
                    //continue;
                    $_method['bank_options'] = $bank_options;
                    $_method['urls']['condition'] = 'LIKE';
                    $_method['urls']['redirect_url'] = $base_url.'module/bankwirethai/payment?swift=';
                    $_method['urls']['success_url'] = 'id_order=';
                }
                else if(in_array($_method['_code'], array('payfast')))
                {
                    $_method['urls']['condition'] = 'LIKE';
                    $_method['urls']['redirect_url'] = $base_url.'modules/'.$this->module->name.'/index.php?method=mobicommerce3.payments.payfast.redirect&appcode='.Tools::getValue('appcode').'&app_key='.Tools::getValue('app_key');
                    $_method['urls']['success_url'] = 'order_id=';
                    $_method['urls']['cancel_url'] = 'nothing';
                }
                else if(in_array($_method['_code'], array('multisafepayconnect')))
                {
                    $_method['title'] = 'Paga con la tua carta di credito';
                    $_method['instructions'] = 'su server sicuro MultiSafepay';
                    $_method['urls']['condition'] = 'LIKE';
                    $_method['urls']['redirect_url'] = $base_url.'modules/'.$this->module->name.'/index.php?method=mobicommerce3.payments.common.redirect&appcode='.Tools::getValue('appcode').'&app_key='.Tools::getValue('app_key').'&payment_method=multisafepayconnect';
                    $_method['urls']['success_url'] = 'order_id=';
                    $_method['urls']['cancel_url'] = 'step=3';
                }
            }

            if(in_array($_method['_code'], array('cashondeliveryplus')))
            {
                $dobirecne = ServiceFactory::factory('MobicommercePayment')->getDobirecne();

                $_method['title'] = $this->l('Pay with cash on delivery (COD)', array(
                'mod'    => 'cashondelivery',
                'modtpl' => 'payment',
                ));
                if($dobirecne > 0){
                    $_method['fees'] = Tools::convertPrice($dobirecne);
                    $_method['fees_html'] = $this->l('The COD fee is', array(
                        'mod'    => 'cashondelivery',
                        'modtpl' => 'payment',
                        ));
                    $_method['fees_html'] .= ' '. $dobirecne;
                }
            }

            switch ($_method['_code']) {
                case 'payfortfort':
                    $_method['show_type'] = 1;
                    $_method['title'] = $this->l('Pay With Debit / Cradit Card', array('mod' => 'payfortfort', 'modtpl' => 'payfortfort'));
                    $_method['urls']['condition'] = 'LIKE';
                    $_method['urls']['redirect_url'] = $base_url.'modules/'.$this->module->name.'/index.php?method=mobicommerce3.payments.payfortfort.redirect&appcode='.Tools::getValue('appcode').'&app_key='.Tools::getValue('app_key');
                    $_method['urls']['payfortfort_data_url'] = $base_url.'index.php?fc=module&module=payfortfort&controller=payment&action=getMerchantPageData';
                    //$_method['urls']['success_url'] = 'id_order=';
                    $_method['urls']['success_url'] = 'action=responseOnline';
                    $_method['urls']['cancel_url'] = 'id_cart=';
                    break;
                
                case 'paypalusa':
                    $_method['title'] = $this->l('Pay with PayPal', array('mod' => 'paypalusa', 'modtpl' => 'standard'));

                default:
                    # code...
                    break;
            }

            if($this->onepagecheckoutps)
            {
                $_method['logo'] = $base_url.$onepagecheckoutpsPaymentsArray[$module_obj->name]['url_image'];
            }

            // for AynaraSecret
            if($this->onepagecheckoutps)
            {
                switch ($_method['_code'])
                {
                    case 'redsys':  $_method['title'] = 'Tarjeta de Credito o Debito';
                        break;
                    case 'paypal':  $_method['title'] = 'Pago con Paypal';
                        break;
                    case 'bankwire':  $_method['title'] = 'Transferencia';
                        break;
                    case 'cashondeliveryplus': $_method['title'] = 'Contra Reembolso';
                        break;
                    default:
                        break;
                }
            }
            // for AynaraSecret - upto here

            // for omyanmar
            /*
            if(in_array($_method['_code'], array('cashondelivery'))){
                $_method['logo'] = $base_url.'themes/warehouse/img/cash.png';
            }
            */
            /*
            if(isset($module_obj->link) && !empty($module_obj->link)){
                $_method['show_type'] = 9;
                $_method['urls'] = array(
                    'redirect_url' => $module_obj->link
                    );
            }
            */

            //Customization for jenil paramr ayurvedamart
            /*$module_id = $module_obj->id;
            $id_lang = (int) $this->context->cookie->id_lang;
            if(isset($paymentdata['payment_method'][$module_id]['title'])){
                $payment_title = $paymentdata['payment_method'][$module_id]['title'][$id_lang];
                $_method['title'] = $payment_title;
            }*/
            //Customization for jenil paramr ayurvedamart end
            
            $methods[] = $_method;
        }

        //Added for Customization of Dandal Ir
        $all_methods = array();
        foreach ($methods as $key => $value)
        {
            if(in_array($value['_code'], array('dmtbanks')))
            {
                $_method = $value;

                $_method['urls']['redirect_url'] = $value['urls']['redirect_url'].'parsian';
                $_method['title'] = "Payment with parsian bank";
                $_method['code'] = "DMTBANKS_parsian";
                $all_methods[] = $_method;
                
                $_method['urls']['redirect_url'] = $value['urls']['redirect_url'].'mellat';
                $_method['title'] = "Payment with mellat bank";
                $_method['code'] = "DMTBANKS_mellat";
                $all_methods[] = $_method;
            }
            else
            {
                $all_methods[] = $value;
            }
        }
        $methods = $all_methods;
        
        return $methods;
       
        if (file_exists(_MODULE_DIR_ . '/paypalapi'))
        {
            if (Module::isInstalled('paypalapi'))
            {
                return array('paypalec');
            }
        }
        elseif (Module::isInstalled('paypal'))
        {
            if (Configuration::get('PAYPAL_API_USER') && Configuration::get('PAYPAL_API_PASSWORD') && Configuration::get('PAYPAL_API_SIGNATURE')) {
                return array('paypalec');
            }
        }
        return array();
    }

    private function _getRestrictedPaymentGateways()
    {
        return array("amzpayments");
    }

    /**
     * get products information
     * @param type $this->cart
     * @return array
     * @author hujs
     */
    public function getProducts(&$nbTotalProducts = 0)
    {
        $items = array();
        $products = $this->context->cart->getProducts(true);
        //pre($this->context->cart);
        //pre($products);exit;
        foreach ($products as $product)
        {
            $item = array(
                'unique_id'             => $product['unique_id'],
                'item_id'               => $product['id_product'] . ':' . $product['id_product_attribute'] . ':' . $product['minimal_quantity'],
                'product_id'            => $product['id_product'],
                'name'                  => $product['name'],
                'product_thumbnail_url' => $this->getProductImage($product['link_rewrite'], $product['id_image'], 'home'),
                'currency'              => $this->context->cookie->currency,
                'price'                 => $product['price'],
                'price_incl_tax'        => $product['price_wt'],
                'row_total'             => $product['total'],
                'row_total_incl_tax'    => $product['total_wt'],
                'qty'                   => $product['cart_quantity'],
                'max_qty'               => $product['stock_quantity'],
                'qty_increments'        => '0',
                'options'               => explode(',', $product['attributes']),
                'display_attributes'    => empty($product['attributes']) ? '' : str_replace(',', '<br/> -', ' - ' . $product['attributes']),
                'item_url'              => $this->link->getProductLink($product['id_product']),
                'short_description'     => $product['description_short'],
                'hasError'              => false,
                'errorDescription'      => false,
            );
            $nbTotalProducts += intval($product['cart_quantity']);
            $items[] = $item;
        }
        $items = $this->sortCartProductsByUniqueId($items);
        return $items;
    }

    protected function sortCartProductsByUniqueId($items)
    {
        // if you do not want sorting comment below line.
        //return $items;
        if($items)
        {
            $unique_id = array();
            $item_id = array();

            foreach ($items as $key => $row)
            {
                $unique_id[$key] = $row['unique_id'];
                $item_id[$key] = $row['item_id'];
            }

            array_multisort($unique_id, SORT_ASC, $item_id, SORT_ASC, $items);
        }

        return $items;
    }

    /**
     * initialization of cart information
     * @param type $result
     * @author hujs
     */
    public function initShoppingCartGetReslut(&$result)
    {
        $result['cart_items_count']  = 0;
        $result['cart_items']        = array();
        $result['messages']          = array();
        $result['price_infos']       = array();
        $result['valid_to_checkout'] = true;
        $result['is_virtual']        = false;
    }

    /**
     * get price information
     * @return int
     * @author hujs
     */
    public function getPriceInfo()
    {
        $postion = 0;
        $total = $this->context->cart->getOrderTotal(true,BOTH,null,$this->context->cookie->id_carrier);
        $discount = $this->context->cart->getOrderTotal(true, ONLY_DISCOUNTS);
        $totalWithoutTax = $this->context->cart->getOrderTotal(false,BOTH,null,$this->context->cookie->id_carrier);
        $shipping = $this->context->cart->getOrderTotal(true, ONLY_SHIPPING,null,$this->context->cookie->id_carrier);
        $priceInfo = array();
        $priceInfo['shipping'] = array(
            'title'    => $this->l('Shipping'),
            'type'     => 'shipping',
            'price'    => $shipping,
            'currency' => $this->context->cookie->currency,
            'position' => $postion++,
        );

        if ($this->withTax && $total > $totalWithoutTax) {
            $priceInfo['tax'] = array(
                'title' => $this->l('Tax'),
                'type' => 'tax',
                'price' => $total - $totalWithoutTax,
                'currency' => $this->context->cookie->currency,
                'position' => $postion++,
            );
        }

        if ($discount) {
            $priceInfo['discount'] = array(
                'title' => $this->l('Discount'),
                'type' => 'discount',
                'price' => $discount,
                'currency' => $this->context->cookie->currency,
                'position' => $postion++,
            );
        }

        if ($this->context->cart->gift) {
            $wrapping_fees = (float) (Configuration::get('PS_GIFT_WRAPPING_PRICE'));
            if ($this->withTax) {
                $wrapping_fees_tax = new Tax((int) (Configuration::get('PS_GIFT_WRAPPING_TAX')));
                $wrapping_fees *= 1 + (((float) ($wrapping_fees_tax->rate) / 100));
            }
            $wrapping_fees = Tools::convertPrice(Tools::ps_round($wrapping_fees, 2), Currency::getCurrencyInstance((int) ($this->context->cookie->id_currency)));
            $priceInfo['wrapping'] = array(
                'title'    => $this->l('Wrapping'),
                'type'     => 'wrapping',
                'price'    => $wrapping_fees,
                'currency' => $this->context->cookie->currency,
                'position' => $postion++,
            );
        }
        $priceInfo['total'] = array(
            'title'    => $this->l('Total'),
            'type'     => 'total',
            'price'    => $total,
            'currency' => $this->context->cookie->currency,
            'position' => $postion++,
        );
        return $priceInfo;
    }

    /**
     * add goods into cart
     * @param type $goods
     * @return type 
     * @author hujs
     */
    public function add($productId, $idProductAttribute, $quantity = 1)
    {
        /* Product addition to the cart */
        if (!isset($this->context->cart->id) OR !$this->context->cart->id) {
            CartRule::autoRemoveFromCart($this->context);
            $this->context->cart->add();
            CartRule::autoAddToCart($this->context);
            if ($this->context->cart->id)
                $this->context->cookie->id_cart = (int) ($this->context->cart->id);
        }
        return $this->context->cart->updateQty($quantity, $productId, $idProductAttribute);
    }

    /**
     * update product's quantity and attributes
     * in cart by product id
     * @param type $arr
     * @return type 
     * @author hujs
     */
    public function update($cartItemId, $quantity)
    {
        $newCartItemId = explode(":", $cartItemId);
        $itemId = $newCartItemId[0];
        $itemAttr = empty($newCartItemId[1]) ? NULL : $newCartItemId[1];
        $this->cartItemNb = $this->context->cart->containsProduct($itemId, $itemAttr, FALSE);
        /* Product addition to the cart */
        if (!isset($this->context->cart->id) OR !$this->context->cart->id)
        {
            CartRule::autoRemoveFromCart($this->context);
            $this->context->cart->add(true);
            CartRule::autoAddToCart($this->context);

            if ($this->context->cart->id)
            {
                $this->context->cookie->id_cart = (int) ($this->context->cart->id);
            }
        }
        
        if ($quantity < $this->cartItemNb['quantity'])
        {
            $operator = 'down';
            $qty = $this->cartItemNb['quantity'] - $quantity;
        }
        else if ($quantity == $this->cartItemNb['quantity'])
        {
            return true;
        }
        else
        {
            $operator = 'up';
            $qty = $quantity - $this->cartItemNb['quantity'];
            //$qty = $quantity;
        }

        if (_PS_VERSION_ < '1.5') {
            return $this->context->cart->updateQty($qty, $itemId, $itemAttr, false, $operator);
        } else {
            return $this->context->cart->updateQty($qty, $itemId, $itemAttr, false, $operator,$this->context->cookie->id_address_delivery);
        }
    }

    /**
     * remove goods from cart by product key
     * @access  public
     * @param   integer $id
     * @return  void
     * @author hujs
     */
    public function remove($cartItemId) {
        $item = explode(":", $cartItemId);
        $id_product = $item[0];
        $id_product_attribute = $item[1];
        
        foreach ($this->context->cart->getProducts() as $key => $product) {
            if($id_product == $product['id_product']){
                $this->context->cart->deleteProduct($id_product, $id_product_attribute);
            }   
        }

        CartRule::autoRemoveFromCart($this->context);
        CartRule::autoAddToCart($this->context);
    }
}
