<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

class MobicommercehelperService extends BaseService
{
    protected $key = "d0a7e7997b6d5fcd55f4b5c32611b87cd923e88837b63bf2941ef819dc8ca282";

    public function encrypt($string)
    {
        $key = _COOKIE_KEY_;
        $result = '';
        for($i=0, $k= strlen($string); $i<$k; $i++) {
            $char = substr($string, $i, 1);
            $keychar = substr($key, ($i % strlen($key))-1, 1);
            $char = chr(ord($char)+ord($keychar));
            $result .= $char;
        }
        return base64_encode($result);
        //return base64_encode($strgin);
        /*
        $iv = mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_CBC), MCRYPT_DEV_URANDOM);
        $key = $this->key;
        $key = pack('H*', $key);
        $mac = hash_hmac('sha256', $string, Tools::substr(bin2hex($key), -32));
        $passcrypt = mcrypt_encrypt(MCRYPT_RIJNDAEL_256, $key, $string.$mac, MCRYPT_MODE_CBC, $iv);
        $encoded = base64_encode($passcrypt).'|'.base64_encode($iv);
        return $encoded;
        */
    }

    public function decrypt($string)
    {
        $key = _COOKIE_KEY_;
        $result = '';
        $string = base64_decode($string);
        for($i=0,$k=strlen($string); $i< $k ; $i++) {
            $char = substr($string, $i, 1);
            $keychar = substr($key, ($i % strlen($key))-1, 1);
            $char = chr(ord($char)-ord($keychar));
            $result.=$char;
        }
        return $result;
        //return base64_decode($string);
        /*
        $decrypt = explode('|', $string.'|');
        $decoded = base64_decode($decrypt[0]);
        $iv = base64_decode($decrypt[1]);
        if(Tools::strlen($iv)!==mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_CBC)){ return false; }
        $key = $this->key;
        $key = pack('H*', $key);
        $decrypted = trim(mcrypt_decrypt(MCRYPT_RIJNDAEL_256, $key, $decoded, MCRYPT_MODE_CBC, $iv));
        $mac = Tools::substr($decrypted, -64);
        $decrypted = Tools::substr($decrypted, 0, -64);
        $calcmac = hash_hmac('sha256', $decrypted, Tools::substr(bin2hex($key), -32));
        if($calcmac!==$mac){ return false; }
        return $decrypted;
        */
    }

    /**
     * Created by: Yash Shah
     * Date: 27-07-2015
     * For mobile app, if session expires then also keep user login by mobile session customer id
     */
    public function autoLoginMobileUser()
    {
        if(isset($_REQUEST['autologinid']) && !empty($_REQUEST['autologinid'])){
            $autologinid = $this->decrypt($_REQUEST['autologinid']);
            $customer = $this->context->cookie->id_customer;
            if(!empty($autologinid) && empty($this->context->cookie->id_customer)){
                ServiceFactory::factory('User')->login(null, $autologinid);
            }
            $_REQUEST['autologinid'] = false;
        }
    }
}
