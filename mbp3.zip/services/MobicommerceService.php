<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class MobicommerceService extends BaseService
{
    public function __construct()
    {
        parent::__construct();
        ServiceFactory::factory('Mobicommercehelper')->autoLoginMobileUser();
    }

    public function getCustomCheckoutFields()
    {
        // for co-opclick worachat
        $customFields = array(
            "register" => array(
                array(
                    "code"              => "newsletter",
                    "type"              => "checkbox",
                    "name"              => "Sign up for our newsletter!",
                    "required"          => false,
                    "validation"        => "",
                    "error_message"     => "",
                    "registerDependent" => false
                    ),
                array(
                    "code"              => "optin",
                    "type"              => "checkbox",
                    "name"              => "Receive special offers from our partners!",
                    "required"          => false,
                    "validation"        => "",
                    "error_message"     => "",
                    "registerDependent" => false
                    )
                ),
            "order_review" => array(
                array(
                    "code"              => "message",
                    "type"              => "textarea",
                    "name"              => "Leave a message",
                    "required"          => false,
                    "validation"        => "",
                    "error_message"     => "",
                    "registerDependent" => false,
                    "params" => array(
                        "default_value" => "",
                        "description"   => "",
                        "format"        => ""
                        )
                    )
                ),
            "shipping_method" => array(
                array(
                    "code"              => "cgv",
                    "type"              => "checkbox",
                    "name"              => "I agree to the terms of service and will adhere to them unconditionally.",
                    "required"          => true,
                    "validation"        => "",
                    "error_message"     => "Please agreee to terms and conditions",
                    "params" => array(
                        "default_value" => "1",
                        "url"           => "https://www.co-opclick.com/en/content/3-terms-and-conditions-of-use?content_only=1",
                        "text" => "Read The Terms of Service"
                        )
                    )
                ),
            );
        $customFields = array();
        $customFields = array();
        return $customFields;
    }


    public function getHomeData($app_key)
    {
        $app_code = $this->getAppCode($app_key);
        $result['advance_settings'] = $this->getAppInfo($app_code, "advance_settings");
        $result['homepage_categories'] = $this->getAppInfo($app_code, "homepage_categories");
        $result['widgets'] = $this->getHomePageWidgets($app_code, $this->context->cookie->id_lang);
        $result['customCheckoutFields'] = $this->getCustomCheckoutFields();
        $result['version_support'] = true;
        return $result;
    }

    public function _getSocialLogin()
    {
        $social_login = array(
            0 => array(
                'code'       => 'facebook',
                'title'      => Configuration::get('mobi3_fb_title'),
                'is_active'  => Configuration::get('mobi3_fb_active'),
                'sort_order' => (int) Configuration::get('mobi3_fb_sortorder'),
                ),
            1 => array(
                'code'       => 'google',
                'title'      => Configuration::get('mobi3_go_title'),
                'is_active'  => Configuration::get('mobi3_go_active'),
                'sort_order' => (int) Configuration::get('mobi3_go_sortorder'),
                ),
            );
        
        foreach ($social_login as $key => $row){
            $sort_order[$key] = $row['sort_order'];
            $is_active[$key]  = $row['is_active'];
        }
        array_multisort($sort_order, SORT_ASC, $is_active, SORT_ASC, $social_login);

        $social = array();
        foreach($social_login as $_sociallogin)
        {
            if($_sociallogin['is_active'])
            {
                $social[] = array(
                    'code' => $_sociallogin['code'],
                    'title' => $_sociallogin['title']
                    );
            }
        }
        return $social;
    }

    public function getCMSDetail($id)
    {
        $cmsDetail = $this->getCms($id);
        if(is_array($cmsDetail)){
            $info = array();
            $info['detail'] = $cmsDetail;
            $info['version_support']=true;
            return $info;
        }
        else{
            return false;
        }
    }
    
    public function getCatlogData($app_key, $cid)
    {
        $info = array();
        $info['widgets'] = $this->getCategoryWidgets($cid, $this->context->cookie->id_lang);
        $info['version_support']=true;
        return $info;
    }
    
    public function getConfig($app_key)
    {
		$app_code = $this->getAppCode($app_key);
        $current_lang = $this->context->cookie->id_lang;

        if(Tools::getValue('store')){
            $current_lang = Tools::getValue('store');
            $this->context->cookie->id_lang = $current_lang;
        }
        /* change language - upto here */

        /* change currrency */        
        if(Tools::getValue('currency')){
            $currency = $this->getCurrencyByCode(Tools::getValue('currency'));
            if(!empty($currency)){
                $this->context->cookie->id_currency = (int) $currency['id_currency'];
            }
        }
        /* change currrency - upto here */
        
        $langDetails = Language::getLanguage($current_lang);
        $locale = $langDetails['iso_code'];
        $storeService = ServiceFactory::factory('Store');

        ServiceFactory::factory('Pushnotification')->updatePreference();

        $info = array();
        $info['store_code']   = $langDetails['iso_code'];
        $info['stores']       = $storeService->getLanguages();
        $info['appinfo']      = $this->getAppInfo($app_code,"appinfo");
        $info['homedata']     = $this->getHomeData($app_key);
        $info['CMS']          = $this->getAppInfo($app_code, "cms_settings", $current_lang);
        $info['language']     = $this->getLanguage($locale);
        $info['push']         = $this->getAppInfo($app_code,"push_notification");
        $info['cart_details'] = ServiceFactory::factory('ShoppingCart')->get();
        $info['userdata'] = ServiceFactory::factory('User')->getUserInfo($this->context->cookie->email);

        /*
        $info['data']['wishlist'] = array();
        if(Module::isInstalled('blockwishlist'))
        {
            $wishlists = Wishlist::getByIdCustomer($this->context->customer->id);
            if (empty($this->context->cookie->id_wishlist) === true ||
                WishList::exists($this->context->cookie->id_wishlist, $this->context->customer->id) === false)
            {
                if (!count($wishlists))
                    $id_wishlist = false;
                else
                {
                    $id_wishlist = (int)$wishlists[0]['id_wishlist'];
                    $this->context->cookie->id_wishlist = (int)$id_wishlist;
                }
            }
            else
                $id_wishlist = $this->context->cookie->id_wishlist;

            $wishlist_products = ($id_wishlist == false ? false : WishList::getProductByIdCustomer($id_wishlist, $this->context->customer->id, $this->context->language->id, null, true));

            $proudctTranslator = ServiceFactory::factory('ProductTranslator');
            if($wishlist_products) {
                foreach ($wishlist_products as $row) {
                    $proudctTranslator->clear();
                    $proudctTranslator->setProduct($row);
                    $info['wishlist'][] = $proudctTranslator->getListingItemInfo();
                }
            }
        }
        */

        $info['countries'] = $storeService->getCountries();
        $info['googleanalytics'] = $this->getAppInfo($app_code, "googleanalytics");
        $info['social_login'] = $this->_getSocialLogin();
        $info['version_support'] = true;

        $_categories = ServiceFactory::factory('Category')->getAllCategories();
        $_category_keys = array();
        $_category_values = array();
        if($_categories) {
            foreach ($_categories as $_category) {
                $_category_keys = array_keys($_category);
                $_category_values[] = array_values($_category);
            }
        }
        $info['category_keys'] = $_category_keys;
        $info['category_values'] = $_category_values;
        
        $info = $this->getPersonalizer($info);
        return $info;
    }

    private function getPersonalizer($info)
    {
        $appcode = Tools::getValue('appcode');
        $theme_name = 'shopper';
        $collection = $this->getAppInfo($appcode, "theme_folder_name");
        
        if($collection){
            $theme_name = $collection[0]['value'];
        }

        $file_personalizer_parent = _PS_ROOT_DIR_.'/modules/mobicommerce3/views/css/mobi_assets/v/3/theme_files/'.$theme_name.'/personalizer/personalizer.css';
        $file_personalizer_child = _PS_ROOT_DIR_.'/modules/mobicommerce3/media/mobi_commerce/'.$appcode.'/personalizer/personalizer.xml';
        //echo $file_personalizer_parent;exit;
        if(file_exists($file_personalizer_parent) && file_exists($file_personalizer_child)) {
            $code_personalizer_parent = simplexml_load_file($file_personalizer_parent);
            $code_personalizer_child = simplexml_load_file($file_personalizer_child);

            $android_statusbar_color = '';
            foreach ($code_personalizer_parent->android_primary_theme->options->option as $option) {
                if($option->value == (string)$code_personalizer_child->android_primary_theme->current_value) {
                    $android_statusbar_color = (string) $option->statusbar;
                }
            }
            
            $info['personalizer'] = array(
                'android_primary_theme' => (string)$code_personalizer_child->android_primary_theme->current_value,
                'android_statusbar_color' => $android_statusbar_color,
                'android_secondary_theme' => (string)$code_personalizer_child->android_secondary_theme->current_value,
                'ios_primary_theme' => (string)$code_personalizer_child->ios_primary_theme->current_value,
                'ios_secondary_theme' => (string)$code_personalizer_child->ios_secondary_theme->current_value,
                );
        }
        return $info;
    }
    
    public function getHome($app_key)
    {
        $app_code = $this->getAppCode($app_key);
        $storeService = ServiceFactory::factory('Store');        
        $result['advance_settings'] = $this->getAppInfo($app_code, "advance_settings");
        $result['widgets'] = $this->getHomePageWidgets($app_code, $this->context->cookie->id_lang);
        return $result;
    }
    
    public function setLanguageCodeData($locale)
	{
		if($locale != 'en_US' && !file_exists(_PS_MODULE_DIR_.$this->module->name.'/views/img/mobi_assets/multilanguage/'.$locale.'.xml'))
			@copy(_PS_MODULE_DIR_.$this->module->name.'/views/img/mobi_assets/multilanguage/en_US.xml', _PS_MODULE_DIR_.$this->module->name.'/views/img/mobi_assets/multilanguage/'.$locale.'.xml');

		$xml = _PS_MODULE_DIR_.$this->module->name.'/media/mobi_commerce/multilanguage/'.$locale.'.xml';
		if(!file_exists($xml)){
			if(!file_exists(_PS_MODULE_DIR_.$this->module->name.'/media/mobi_commerce/multilanguage/'))
				mkdir(_PS_MODULE_DIR_.$this->module->name.'/media/mobi_commerce/multilanguage/', 0755);

			if(file_exists(_PS_MODULE_DIR_.$this->module->name.'/views/img/mobi_assets/multilanguage/'.$locale.'.xml')){
				@copy(_PS_MODULE_DIR_.$this->module->name.'/views/img/mobi_assets/multilanguage/'.$locale.'.xml', _PS_MODULE_DIR_.$this->module->name.'/media/mobi_commerce/multilanguage/'.$locale.'.xml');
			}
			else
				@copy(PS_MODULE_DIR_.$this->module->name.'/views/img/mobi_assets/multilanguage/'.$locale.'.xml', PS_MODULE_DIR_.$this->module->name.'/media/mobi_commerce/multilanguage/'.$locale.'.xml');
		}
	}
    
    public function getLanguage($locale)
    {
        if($locale != 'en' && !file_exists(_PS_MODULE_DIR_.$this->module->name.'/views/img/mobi_assets/multilanguage/'.$locale.'.xml'))
			@copy(_PS_MODULE_DIR_.$this->module->name.'/views/img/mobi_assets/multilanguage/en.xml', _PS_MODULE_DIR_.$this->module->name.'/views/img/mobi_assets/multilanguage/'.$locale.'.xml');

		$labels = array();

		$xml = _PS_MODULE_DIR_.$this->module->name.'/views/img/mobi_assets/multilanguage/'.$locale.'.xml';
        $xmldata = simplexml_load_file($xml);
        foreach($xmldata as $_key => $_data){
        	$labels[$_key] = (array)$_data;
        }

        $childxml = _PS_MODULE_DIR_.$this->module->name.'/media/mobi_commerce/multilanguage/'.$locale.'.xml';
        $childxmldata = simplexml_load_file($childxml);
        if($childxmldata) {
            foreach($childxmldata as $_key => $_data){
                if(array_key_exists($_key, $labels)){
                    $labels[$_key]['mm_text'] = (string)$_data->mm_text;
                }
            }
        }
        $finalLables = array();
        foreach($labels as $_key => $label){
            $finalLables[] = array('code' => $_key, 'text' => $label['mm_text']);
        }
        
		return $finalLables;
    }
    
    public function getAppCode($app_key)
    {
        $_table = 'mobicommerce_applications3';
        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('
		SELECT c.*
		FROM `'._DB_PREFIX_.$_table.'` c
		WHERE c.`app_key` = "'.$app_key.'"');
        return $result['0']['app_code'];
    }
    
    public function getAppInfo($app_code, $setting_code, $lang_code=false)
    {
        $base_url = $this->getBaseUrl();
        $_table = 'mobicommerce_applications_settings3';
        $sql = '
        SELECT c.*
        FROM `'._DB_PREFIX_.$_table.'` c
        WHERE c.`app_code` = "'.$app_code.'" and c.`setting_code` = "'.$setting_code.'" 
        ';
        
        if(!empty($lang_code)){
            $sql .= ' AND c.`storeid` = "'.$lang_code.'"';
        }
        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
        $value = Tools::unSerialize($result[0]['value']);

        if($setting_code == 'appinfo'){
            $value['app_share_image'] = $base_url.'modules/'.$this->module->name.'/media/mobi_commerce/'.$app_code.'/appinfo/'.$value['app_share_image'];
        }
        else if($setting_code == 'advance_settings') {
            if(isset($value['categories']) && !empty($value['categories'])){
                $value['categories'] = array();
                foreach($value['categories'] as $_category){
                    $value['categories'][$_category] = 'on';
                }
            }
            //print_r($value['categories']);exit;
        }
        else if($setting_code == 'cms_settings'){
            
            // menu Icon
            $value['contact_information']['menu_icon'] = $base_url.'modules/'.$this->module->name.'/'.$value['contact_information']['menu_icon'];
            
            $cms_pages = array();
            if(!empty($value['cms_pages']['status'])){
                $allcms = $this->getCms();
                foreach($value['cms_pages']['status'] as $_key => $_value){
                    $_cmspage['page_id'] = $allcms[$_key]['page_id'];
                    $_cmspage['title'] = $allcms[$_key]['title'];
                    //$_cmspage['content'] = $allcms[$_key]['content'];
                    //$_cmspage['content'] = str_replace('src="/img', 'src="'.$base_url.'img', $_cmspage['content']);
                    $_cmspage['index'] = (int)$value['cms_pages']['index'][$_key];
                    $cms_pages[] = $_cmspage;
                }

                // sorting based on index
                foreach ($cms_pages as $key => $row) {
                    $index[$key]  = $row['index'];
                    $page_id[$key] = $row['page_id'];
                }
                array_multisort($index, SORT_ASC, $page_id, SORT_ASC, $cms_pages);
            }
            $value['cms_pages'] = $cms_pages;
        }
		return  $value;
    }
    
    public function getCms($id=0)
    {
        $base_url = $this->getBaseUrl();
        $current_lang = $this->context->cookie->id_lang;
        $cmsPages = CMS::getCMSPages($current_lang);
        $cmsPagesIdBased = array();
        foreach($cmsPages as $cms)
        {
            $_cms = array();
            $_cms['page_id'] = $cms['id_cms'];
            $_cms['title'] = $cms['meta_title'];
            $_cms['content'] = str_replace('src="/img', 'src="'.$base_url.'img', $cms['content']);
            
            $cmsPagesIdBased[$cms['id_cms']] = $_cms;
        }

        if($id)
        {
            if(isset($cmsPagesIdBased[$id]))
                return $cmsPagesIdBased[$id];
            else
                return false;     
        }
        else
        {
            return $cmsPagesIdBased;    
        }
    }
    
    public function getHomePageWidgets($appcode, $lang_id)
    {
        $_table = 'mobicommerce_widget3';
        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('SELECT c.*
        FROM `'._DB_PREFIX_.$_table.'` c     
        WHERE c.widget_status ="1" and c.`widget_app_code` = "'.$appcode.'" and widget_store_id='.$lang_id.' ORDER BY widget_position ASC');
        
        $resultWidget = array();
        foreach($result as $k=>$r)
        {
            $result[$k]['widget_data'] = Tools::unSerialize($r['widget_data']);
            $widgetFunction = $r['widget_code'];
            $widget = $this->{$widgetFunction}($result[$k]);
            if(!empty($widget)){
                $widget['widget_data']['widget_id'] = $widget['widget_id'];
                $resultWidget[] = $widget;
            }
        }
        $result = array_values($resultWidget);
        return $result;
    }

    public function getCategoryWidgets($cid,$lang_id)
    {
        $_table = 'mobicommerce_category_widget3';
        /*
        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('SELECT c.*
		FROM `'._DB_PREFIX_.$_table.'` c		
		WHERE c.widget_status ="1" and c.`widget_category_id` = "'.$cid.'" and widget_store_id='.$lang_id." ORDER BY widget_position ASC");
        */
        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('SELECT c.*
        FROM `'._DB_PREFIX_.$_table.'` c        
        WHERE c.widget_status ="1" and c.`widget_category_id` = "'.$cid.'" ORDER BY widget_position ASC');
        
        foreach($result as $k => $r)
        {
            $result[$k]['widget_data'] = Tools::unSerialize($r['widget_data']);
            $widgetFunction = $r['widget_code'];
            $widget = $this->{$widgetFunction}($result[$k]);
            if($widget)
                $result[$k] = $widget;
        }
        $result = array_values($result);
		return $result;
    }

    public function widget_image_slider($widget)
    {
        $base_url = $this->getBaseUrl();
        $banners = $widget['widget_data']['banners'];
        $widget['widget_data']['banners'] = array();
        $banners = array_values($banners);
        foreach($banners as $_key => $_banner){
            $filename = $_banner['banner_url'];
            $filename = str_replace($base_url, _PS_ROOT_DIR_.'/', $filename);
            if($_banner['banner_status'] == '1' && file_exists($filename)) {
                addImageRatio($_banner);
                $widget['widget_data']['banners'][] = $_banner;
            }
        }
        return $widget;
    }

    public function widget_product_slider($widget)
    {
        if(in_array($widget['widget_data']['productslider_type'], array('newarrivals', 'bestseller', 'productviewed'))){
            switch ($widget['widget_data']['productslider_type']) {
                case 'newarrivals':
                    $params['sort_by'] = "date_add";
                    $params['sort_order'] = 'desc';
                    $params['widget_type'] = 'newarrivals';
                    $params['page_size'] = $widget['widget_data']['limit'];
                    $params['page_no'] = '1';

                    $productService = ServiceFactory::factory('Product');
                    $collection = $productService->getProducts($params);
                    break;
                case 'bestseller':
                    $params['sort_order'] = 'DESC';
                    $params['widget_type'] = 'bestseller';
                    $params['page_size'] = $widget['widget_data']['limit'];
                    $params['page_no'] = '1';
                    $productService = ServiceFactory::factory('Product');
                    $collection = $productService->getProducts($params);
                    break;
                case 'productviewed':
                    $params['widget_type'] = 'productviewed';
                    $params['page_size'] = $widget['widget_data']['limit'];
                    $params['page_no'] = '1';
                    $productService = ServiceFactory::factory('Product');
                    $collection = $productService->getProducts($params);
                    break;
                default:
                    break;
            }
            $finalProductArray = array();
            if(!empty($collection['products'])){
                foreach($collection['products'] as $_collection){
                    $productTranslator = ServiceFactory::factory('ProductTranslator');
                    $productTranslator->loadProductById($_collection['product_id']);
                    
                    $_product = $productTranslator->getListingItemInfo();
                    if(!empty($_product['name']))
                    {
                        $finalProductArray[$_collection['product_id']] = $_product;

                        unset($finalProductArray[$_collection['product_id']]['combinations']);
                        //unset($finalProductArray[$_collection['product_id']]['options']);
                        unset($finalProductArray[$_collection['product_id']]['short_description']);
                        unset($finalProductArray[$_collection['product_id']]['description']);
                        unset($finalProductArray[$_collection['product_id']]['customAttributes']);
                        unset($finalProductArray[$_collection['product_id']]['product_images']);
                        unset($finalProductArray[$_collection['product_id']]['related_items']);
                        unset($finalProductArray[$_collection['product_id']]['attributeSetName']);
                    }
                }
            }
            if(empty($finalProductArray))
                return false;

            $widget['widget_data']['products'] = array_values($finalProductArray);
        }
        else{
            $products = $widget['widget_data']['products'];
            $finalProductArray = array();

            if($products && is_array($products)) {
                foreach($products as $productId=>$value)
                {
                    if (is_numeric($productId) && !empty($productId)) {
                        $productTranslator = ServiceFactory::factory('ProductTranslator');
                        $productTranslator->loadProductById($productId);
                        
                        $_product = $productTranslator->getListingItemInfo();
                        if(!empty($_product['name']))
                        {
                            $finalProductArray[$productId] = $_product;

                            unset($finalProductArray[$productId]['combinations']);
                            //unset($finalProductArray[$productId]['options']);
                            unset($finalProductArray[$productId]['short_description']);
                            unset($finalProductArray[$productId]['description']);
                            unset($finalProductArray[$productId]['customAttributes']);
                            unset($finalProductArray[$productId]['product_images']);
                            unset($finalProductArray[$productId]['related_items']);
                            unset($finalProductArray[$productId]['attributeSetName']);
                        }
                    }
                }
            }

            if(empty($finalProductArray))
                return false;

            $widget['widget_data']['products'] = array_values($finalProductArray);
        }
        
        return $widget;
    }
    
    public function widget_image($widget)
    {
        $base_url = $this->getBaseUrl();
        //global $smarty;
        $mapcode = $widget['widget_data']['mapcode'];
        $mapcode = htmlspecialchars_decode($mapcode);
        $mapcode = $this->_getImagemapContent($mapcode, false);
        if(empty($mapcode)){
            $mapcode = '<img src="'.$widget['widget_data']['widget_image'].'" alt="">';
        }
        //$mapcode = str_replace('../modules', $smarty->tpl_vars['base_dir']->value.'modules', $mapcode);
        $mapcode = str_replace('../modules',  _PS_ROOT_DIR_.'/modules', $mapcode);

        $widget['widget_data']['mapcode'] = $mapcode;

        //$filename = str_replace('../modules', $smarty->tpl_vars['base_dir']->value.'modules', $widget['widget_data']['widget_image']);
        $filename = str_replace('../modules', _PS_ROOT_DIR_.'/modules', $widget['widget_data']['widget_image']);

        $widget['widget_data']['widget_image'] = $filename;
        $filename = str_replace($base_url, _PS_ROOT_DIR_.'/', $filename);
        if(file_exists($filename)) {
            addImageRatio($widget['widget_data']);
        }
        
        return $widget;
    }

    protected function _getImagemapContent($map, $decodeLink = true)
    {
        $map = htmlspecialchars_decode($map);
        $doc = new DOMDocument();
        $doc->loadHtml($map);
        $areas = $doc->getElementsByTagName('area');
        foreach($areas as $_area){
            $href = $_area->getAttribute("href");
            if($decodeLink){
                $link = $this->_decodeDeeplink($href);
                $map = str_replace('href="'.$href.'"', 'href="'.$link.'"', $map);
            }
            else{
                $map = str_replace('href="'.$href.'"', 'onclick ="app.f.imagemap(\''.$href.'\');"', $map);
            }
        }
        return $map;
    }

    protected function _decodeDeeplink($link = null)
    {
        if(!empty($link)){
            $explode = explode("||", $link);
            if(count($explode) == 2){
                $urltype = $explode['0'];
                $urltval = $explode['1'];
                if($urltype == 'product'){
                    /*
                    $product = Mage::getModel('catalog/product')->load($urltval);
                    $link = $product->getProductUrl();
                    */
                }elseif($urltype == 'category'){
                    /*
                    $link = Mage::getModel("catalog/category")->load($urltval)->getUrl();
                    */
                }elseif($urltype == 'cms'){
                    /*
                    $link = Mage::getBaseUrl().$urltval.'.html';
                    */
                }elseif($urltype == 'phone'){
                    $link = "tel:'.$urltval.'";
                }elseif($urltype == 'email'){
                    $link = "mailto:'.$urltval.'";
                }elseif($urltype == 'external'){
                    $link = $urltval;
                }
            }
        }
        return $link;
    }
    
    public function widget_category($widget)
    {
        $allcategories = Tools::jsonDecode($widget['widget_data']['categories'], true);
        $categories = array();
        foreach($allcategories as $_category_id => $_on)
        {
            $categories[] = $_category_id;
        }
      
        $finalCategoryArray = array();
        $categoryService = ServiceFactory::factory('Category');
        $finalCategoryArray = $categoryService->getCategory($categories); 
       
        foreach($finalCategoryArray as $key => &$category)
        {
            $finalCategoryArray[$key]['category_id'] = $category['category_id'];
        }

        foreach($finalCategoryArray as $key => $value){
            $finalCategoryArray[$key]['position'] = $allcategories[$value['category_id']];
        }

        foreach ($finalCategoryArray as $key => $value) {
            $position[$key]  = $value['position'];
            $category_id[$key] = $value['category_id'];
        }
        array_multisort($position, SORT_ASC, $category_id, SORT_DESC, $finalCategoryArray);
       
        $widget['widget_data']['categories'] = $finalCategoryArray;
        return $widget;   
    }

    public function getCurrencyByCode($code)
    {
        $row = Db::getInstance(_PS_USE_SQL_SLAVE_)->getRow('
            SELECT *
            FROM `'._DB_PREFIX_.'currency`
            WHERE `deleted` = 0
            AND `active` = 1
            AND `iso_code` = "'.$code.'"');
        if($row){
            $currency = new Currency($row['id_currency']);
            if (Validate::isLoadedObject($currency) && !$currency->deleted)
            {
                return $row;
            }
        }

        return null;
    }
    
    public function validUrl($string) {
        $query = "http";
        return (substr($string, 0, strlen($query)) === $query) ? true : false;
    }
}
