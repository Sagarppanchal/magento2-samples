<?php

/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class UrlscanService extends BaseService {

    public function __construct() {
        parent::__construct();
        ServiceFactory::factory('Mobicommercehelper')->autoLoginMobileUser();
    }

    public function getScanInfo() {
        $url = trim(Tools::getValue('scan_value'));
        $found = false;
        if (empty($url)) {
            return false;
        }
        $info = array();
        $products = Product::getProducts($this->context->language->id, 1, 5000, 'name', 'ASC');
        foreach ($products as $_product) {
            $link = new Link();
            if ($url == $link->getProductLink($_product)) {
                $info = array(
                    'type' => 'product',
                    'id' => $_product['id_product'],
                    'product_details' => ServiceFactory::factory('Product')->getProduct($_product['id_product'])
                );
                
                $this->_setProductInCookie($_product['id_product']);
                $found = true;
                break;
            }
        }

        if (!$found) {
            $categories = Category::getCategories((int) ($this->context->cookie->id_lang), true, false);
            foreach ($categories as $_category) {
                $link = new Link();
                if ($url == $link->getCategoryLink($_category['id_category'])) {
                    $info = array(
                        'type' => 'category',
                        'id' => $_category['id_category'],
                        'categories' => ServiceFactory::factory('Category')->getCategory($_product['id_category'])
                    );
                    
                    $found = true;
                    break;
                }
            }
        }

        if (!$found) {
            $cms = CMS::getCMSPages((int) ($this->context->cookie->id_lang), true, false);

            foreach ($cms as $_cms) {
                $link = new Link();
                
                if ($url == $link->getCMSLink($_cms['id_cms'])) {
                    $info = array(
                        'type' => 'cms',
                        'id' => $_cms['id_cms'],
                        'detail' => ServiceFactory::factory('Mobicommerce')->getCMS($_cms['id_cms'])
                    );
                    
                    $found = true;
                    break;
                }
            }
        }
        
        if (!$found) {
            $isValid = ServiceFactory::factory('Mobicommerce')->validUrl($url);
            if ($isValid) {
                $info = array(
                    'type' => 'external_url',
                    'id' => $url
                );
            }
        }

        return $info;
    }

    /**
     * to set recently viewed products in cookie
     */
    protected function _setProductInCookie($id_product)
    {
        $productsViewed = (isset($this->context->cookie->viewed) && !empty($this->context->cookie->viewed)) ? array_slice(array_reverse(explode(',', $this->context->cookie->viewed)), 0, Configuration::get('PRODUCTS_VIEWED_NBR')) : array();

        if ($id_product && !in_array($id_product, $productsViewed))
        {
            $product = new Product((int)$id_product);
            if ($product->checkAccess((int)$this->context->customer->id))
            {
                if (isset($this->context->cookie->viewed) && !empty($this->context->cookie->viewed))
                    $this->context->cookie->viewed .= ','.(int)$id_product;
                else
                    $this->context->cookie->viewed = (int)$id_product;
            }
        }
    }
}
