<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

/**
 * @author hujs
 */
class CategoryService extends BaseService
{
    public function __construct()
    {
        parent::__construct();
        ServiceFactory::factory('Mobicommercehelper')->autoLoginMobileUser();
    }

    /*
    * Added By Dharmen Jain
    * Fix Category is filter by customer group
    ***/
    public static function getCategories($id_lang = false, $active = true, $order = true, $sql_filter = '', $sql_sort = '', $sql_limit = '')
    {
        $sql_groups_where = '';
        $sql_groups_join = '';
        if (Group::isFeatureActive())
        {
            //echo "string"; exit;
            $sql_groups_join = 'LEFT JOIN `'._DB_PREFIX_.'category_group` cg ON (cg.`id_category` = c.`id_category`)';
            $groups = FrontController::getCurrentCustomerGroups();
            $sql_groups_where = 'AND cg.`id_group` '.(count($groups) ? 'IN ('.implode(',', $groups).')' : '='.(int)Group::getCurrent()->id);
        }

        if (!Validate::isBool($active))
            die(Tools::displayError());
        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('
            SELECT *
            FROM `'._DB_PREFIX_.'category` c
            '.Shop::addSqlAssociation('category', 'c').'
            LEFT JOIN `'._DB_PREFIX_.'category_lang` cl ON c.`id_category` = cl.`id_category`'.Shop::addSqlRestrictionOnLang('cl').'
            '.$sql_groups_join.'
            WHERE 1 '.$sql_filter.' '.($id_lang ? 'AND `id_lang` = '.(int)$id_lang : '').'
            '.($active ? 'AND `active` = 1' : '').'
            '.$sql_groups_where.'
            '.(!$id_lang ? 'GROUP BY c.id_category' : '').'
            '.($sql_sort != '' ? $sql_sort : 'ORDER BY c.`level_depth` ASC, category_shop.`position` ASC').'
            '.($sql_limit != '' ? $sql_limit : '')
        );

        if (!$order)
            return $result;

        $categories = array();
        foreach ($result as $row)
            $categories[$row['id_parent']][$row['id_category']]['infos'] = $row;

        return $categories;
    }

    /**
     * get sub categories of home
     * @return type
     * @author hujs
     */
    public function getAllCategories()
    {
        $root = Category::getRootCategory();
        $rows = $this->getCategories($this->context->cookie->id_lang);
        $categories = array();
        $parent = array();
        $postion = 0;
        $current_lang = (int) Configuration::get('PS_LANG_DEFAULT');
        $langDetails =  Language::getLanguage($current_lang);
        $lang_code = $langDetails['language_code'];
       
        foreach ($rows as $pid => $row)
        {
            foreach ($row as $cid => $item)
            {
                if ($item['infos']['level_depth'] > $root->level_depth)
                {
                    $pid == $root->id || $parent[$pid] = true;                    
                    $child = Category::getChildren($cid, $current_lang);
                    //$widgetCount = ServiceFactory::factory('Mobicommerce')->getCategoryWidgets($cid, $current_lang);

                    //$thumbnail_url = $this->getCategoryThumbnailUrl($item['infos']['id_category']);

                    $categories[$cid] = array(
                        'name'           => $item['infos']['name'],
                        'category_id'    => $item['infos']['id_category'],
                        'parent_id'      => $item['infos']['id_parent'],
                        'products_count' => 10,
                        'display_mode'   => 'PRODUCTS',
                        'children'       => count($child),
                        //'has_widgets'  => count($widgetCount)?true:false,
                        'has_widgets'    => false,
                        //'thumbnail_url'  => $thumbnail_url,
                        'thumbnail_url'  => '',
                        'banner_url'     => ''
                    );
                }
            }
        }

        $this->getProductQuantity($categories, $root);
        $this->getProductTotal($categories, $parent);
        $categories = $this->_assignCategoryThumbnail($categories);
        return array_values($categories);
    }

    /**
     * added by yash
     * to assign category thumbnail
     */
    protected function _assignCategoryThumbnail($categories)
    {
        $base_url = $this->getBaseUrl();
        //return $categories;
        $allcategories = array();
        $categoryIds = array();
        if(!empty($categories)){
            foreach ($categories as $key => $value) {
                $allcategories[$value['category_id']] = $value;
                $categoryIds[] = $value['category_id'];
            }
        }

        $sql = 'SELECT * FROM '._DB_PREFIX_.'mobicommerce_category_icon3';
        if ($results = Db::getInstance()->ExecuteS($sql))
        {
            foreach ($results as $row){
                if(array_key_exists($row['mci_category_id'], $allcategories)){
                    if($row['mci_thumbnail'])
                    {
                        $allcategories[$row['mci_category_id']]['thumbnail_url'] = $base_url.'modules/'.$this->module->name.'/media/mobi_commerce/category/'.$row['mci_thumbnail'];
                    }
                    if($row['mci_banner'])
                    {
                        $allcategories[$row['mci_category_id']]['banner_url'] = $base_url.'modules/'.$this->module->name.'/media/mobi_commerce/category/'.$row['mci_banner'];
                    }
                }
            }
        }

        return array_values($allcategories);
    }

    /**
     * get category info
     * @return type
     * @author hujs
     */
    public function getCategory($categoriesIds)
    {
        $root = Category::getRootCategory();
        $rows = $this->getCategoryInformations($categoriesIds, $this->context->cookie->id_lang);
        //print_r($rows);
        $categories = array();
        $parent = array();
        $postion = 0;
        foreach ($rows as $cid => $row) {
            //$image = _PS_CAT_IMG_DIR_.$cid.'.jpg';
            //$thumbnail_url = $this->getCategoryThumbnailUrl($cid);
            $categories[$cid] = array(
                'category_id'   => $cid,
                'name'          => $row['name'],
                'thumbnail_url' => '',
                'banner_url'    => ''
                );
        }
        $this->getProductQuantity($categories, $root);
        $this->getProductTotal($categories, $parent);
        $categories = $this->_assignCategoryThumbnail($categories);

        return array_values($categories);
    }

    /**
     * added by yash
     * 23-04-2016
     */
    public function getCategoryThumbnailUrl($id)
    {
        $image = _PS_CAT_IMG_DIR_.$id.'.jpg';
        $thumbnail_url = NULL;
        if(file_exists($image))
        {
            $_tmp_image = _PS_ROOT_DIR_ . '/img/tmp/cate_'.$id.'.jpg';
            if(!file_exists($_tmp_image)){
                $image_url = ImageManager::thumbnail($image, 'cate_'.$id.'.jpg', 350,"jpg", true, true);
                $xpath = new DOMXPath(@DOMDocument::loadHTML($image_url));
                $src = $xpath->evaluate("string(//img/@src)");
                $thumbnail_url = _PS_BASE_URL_ . DIRECTORY_SEPARATOR . $src;
            }
            else{
                $thumbnail_url = _PS_BASE_URL_ . DIRECTORY_SEPARATOR . 'img/tmp/cate_'.$id.'.jpg';
            }
        }

        return $thumbnail_url;
    }

    /**
     * create by yash
     * Date: 22-02-2016
     * because category sorting was not a part of base prestashop function so added here.
     */
    public function getCategoryInformations($ids_category, $id_lang = null)
    {
        if ($id_lang === null)
            $id_lang = Context::getContext()->language->id;

        if (!is_array($ids_category) || !count($ids_category))
            return;

        $id = Context::getContext()->shop->id;
        $id_shop = $id ? $id: Configuration::get('PS_SHOP_DEFAULT');

        $categories = array();
        $results = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('
        SELECT c.`id_category`, cl.`name`, cl.`link_rewrite`, cl.`id_lang`
        FROM `'._DB_PREFIX_.'category` c
        LEFT JOIN `'._DB_PREFIX_.'category_lang` cl ON (c.`id_category` = cl.`id_category`'.Shop::addSqlRestrictionOnLang('cl').')
        '.Shop::addSqlAssociation('category', 'c').'
        LEFT JOIN `'._DB_PREFIX_.'category_shop` cs
            ON (c.`id_category` = cs.`id_category` AND cs.`id_shop` = '.(int)$id_shop.')
        WHERE cl.`id_lang` = '.(int)$id_lang.' AND c.`active` = "1"
        AND c.`id_category` IN ('.implode(',', array_map('intval', $ids_category)).')
        ORDER BY c.`level_depth` ASC, category_shop.`position` ASC');

        foreach ($results as $category)
            $categories[$category['id_category']] = $category;

        return $categories;
    }

    /**
     * Calculation category include sub categroy product counts
     * @auth hujs
     * @staticvar array $children
     * @param type $cats
     * @return boolean
     */
    private function getProductTotal(&$cats, $pids)
    {
        if (!($count = sizeof($pids)))
        {
            return;
        }

        $parents = array();
        $newPids = array();
        foreach ($cats as $key => &$cat)
        {
            if (isset($pids[$key]))
            {
                $cat['is_parent'] = true;
                $parents[$key] = &$cat;
                $newPids[$cat['parent_cid']] = true;
            }
            elseif ($cat['parent_cid'] != -1)
            {
                if(isset($cats[$cat['parent_cid']]))
                {
                    $cats[$cat['parent_cid']]['count'] += intval($cat['count']);
                }
            }
        }
        $pcount = sizeof($newPids);

        while ($pcount > 1 && $count != $pcount)
        {
            //one parent or only children
            $count = $pcount;
            $pids = array();
            foreach ($parents as $key => &$parent)
            {
                if (!isset($newPids[$key]))
                {
                    if ($parent['parent_cid'] != -1) {
                        $parents[$parent['parent_cid']]['count'] += intval($parent['count']);
                    }
                    unset($parents[$key]);
                }
                else
                {
                    $pids[$parent['parent_cid']] = true;
                }
            }
            $pcount = sizeof($pids);
            $newPids = $pids;
        }
    }

    /**
     * get total of one category id
     * @param type $categoryId
     * @param type $subCategories
     * @return type
     * @author hujs
     */
    private function getProductQuantity(&$categories, $root)
    {
        foreach ($categories as $cid => &$category)
        {
            $root->id = $cid;
            $category['products_count'] = $root->getProducts($this->context->cookie->id_lang, 1, 10, null, null, true);
        }
    }
}
