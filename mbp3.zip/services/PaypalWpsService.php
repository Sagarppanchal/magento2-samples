<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE')) {
    header('HTTP/1.1 404 Not Found');
    die();
}

/**
 * Paypal Web Payment Standard , Utility
 * @package services 
 */
require _PS_MODULE_DIR_ . 'paypal/paypal.php';

class PaypalWpsService
{
    private $paypal;

    public function __construct()
    {
        $this->paypal = new Paypal();
    }

    public function getPaypalUrl()
    {
        return $this->paypal->getPaypalUrl();
    }

    public function buildWpsRedirectParams($return_url, $cancel_url)
    {
        $params = array('cookie' => $this->context->cookie, 'cart' => $this->context->cart);
        $matches = array();

        $output = $this->paypal->hookPayment($params);
        if (strpos($output, 'hidden') === FALSE) {
            if (preg_match('/href\s*=\"([^\"]+)/', $output, $matches)) {
                $fileName = Tools::substr($matches[1], strpos($matches[1], 'paypal'));
                $context = Tools::file_get_contents(_PS_MODULE_DIR_ . $fileName);
                $context = str_replace('include', '$this->includeFile', $context);
                $context = str_replace('<?php', '', $context);
                $context = str_replace('<?PHP', '', $context);
                $context = str_replace('?>', '', $context);
                ob_start();
                eval($context);
                $output = ob_get_clean();
            }
        }

        if (preg_match_all('/name\s*=\s*\"([^\"]+)\"\s*value\s*=\s*\"([^\"]+)\"/', $output, $matches)) {
            $options = array_combine($matches[1], $matches[2]);
        } else {
            $options = array($output);
        }
        
        $this->context->cookie->pay_currency = $options['currency_code'];

        $options['bn'] = 'Mobicommerce_SP_WPS';
        $options['return'] = $return_url;
        $options['cancel_return'] = $cancel_url;

        return array(true, $options);
    }

    private function includeFile($fileName)
    {
        $name = basename($fileName, '.php');
        $skip = array('config.inc', 'init', 'paypal');
        if (!in_array($name, $skip)) {
            include $fileName;
        }
    }
}
