<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

/**
 * Checkout utility
 * @package services
 * @author hujs
 */
class VoucherService extends BaseService
{
    private $errors = array();
    private $context;

    public function __construct()
    {
        parent::__construct();
        ServiceFactory::factory('Mobicommercehelper')->autoLoginMobileUser();

        include_once(_PS_ROOT_DIR_.'/modules/loyalty/LoyaltyModule.php');
        include_once(_PS_ROOT_DIR_.'/modules/loyalty/LoyaltyStateModule.php');

        $this->context = Context::getContext();
    }

    public function getVoucherPoints($p = 0, $n = 0)
    {
        $cart_rules = CartRule::getCustomerCartRules($this->context->language->id, $this->context->customer->id, true, false);

        $rules = array();
        if($cart_rules){
            foreach($cart_rules as $_rule){
                if($_rule['quantity'] > 0){
                    $_rule['status'] = 'Ready to use';
                }
                else{
                    $_rule['status'] = 'Already used';
                }
                $_rule['date_to'] = date('Y-m-d', strtotime($_rule['date_to']));
                $rules[] = $_rule;
            }
        }

        //echo '<pre>';print_r($cart_rules);exit;
        /*
        $count = LoyaltyModule::getAllByIdCustomer(
            (int)$this->context->customer->id,
            (int)$this->context->language->id, false, true,
            5000,
            $p
        );
        */

        $customer_points = (int)LoyaltyModule::getPointsByCustomer((int)$this->context->customer->id);
        $transformation_allowed = $customer_points > 0;
        $transformation_text = "";
        if($transformation_allowed){
            $transformation_text = $this->l("Transform my points into a voucher of", array(
                'mod' => 'loyalty',
                'modtpl' => 'loyalty',
                ));
            $transformation_text .= " ";
            $transformation_text .= LoyaltyModule::getVoucherValue($customer_points, (int)$this->context->currency->id);
        }
        /*
        $transformation_text = $this->l("The minimum order amount in order to use these vouchers is:", array(
                'mod' => 'loyalty',
                'modtpl' => 'loyalty',
                ));

        $minimalLoyalty = (float)Configuration::get('PS_LOYALTY_MINIMAL');
        $transformation_text = $transformation_text.' '. $minimalLoyalty;
        */
        $result = array(
            'list' => $rules,
            'count' => count($rules),
            'category_text' => $this->getCategoryText(),
            'transformation_text' => $transformation_text,
            //'minimalLoyalty' => $minimalLoyalty
            );
        return $result;
        //echo '<pre>';print_r($displayorders);exit;
    }

    public function getCategoryText()
    {
        $all_categories = Category::getSimpleCategories((int)$this->context->cookie->id_lang);
        $voucher_categories = Configuration::get('PS_LOYALTY_VOUCHER_CATEGORY');
        if ($voucher_categories != '' && $voucher_categories != 0)
            $voucher_categories = explode(',', Configuration::get('PS_LOYALTY_VOUCHER_CATEGORY'));
        else
            die(Tools::displayError());

        if (count($voucher_categories) == count($all_categories))
            $categories_names = null;
        else
        {
            $categories_names = array();
            foreach ($all_categories as $k => $all_category)
                if (in_array($all_category['id_category'], $voucher_categories))
                    $categories_names[$all_category['id_category']] = trim($all_category['name']);
            if (!empty($categories_names))
                $categories_names = Tools::truncate(implode(', ', $categories_names), 100).'.';
            else
                $categories_names = null;
        }

        $text = $this->l("Vouchers generated here are usable in the following categories : ", array(
            'mod' => 'loyalty',
            'modtpl' => 'loyalty',
            ));
        if($categories_names){
            $text .= $categories_names;
        }
        else{
            $text .= $this->l("All", array(
                'mod' => 'loyalty',
                'modtpl' => 'loyalty',
                ));
        }
        return $text;
    }

    public function processVoucherPoints($data)
    {
        $customer_points = (int)LoyaltyModule::getPointsByCustomer((int)$this->context->customer->id);
        if ($customer_points > 0)
        {
            /* Generate a voucher code */
            $voucher_code = null;
            do
                $voucher_code = 'FID'.rand(1000, 100000);
            while (CartRule::cartRuleExists($voucher_code));

            // Voucher creation and affectation to the customer
            $cart_rule = new CartRule();
            $cart_rule->code = $voucher_code;
            $cart_rule->id_customer = (int)$this->context->customer->id;
            $cart_rule->reduction_currency = (int)$this->context->currency->id;
            $cart_rule->reduction_amount = LoyaltyModule::getVoucherValue((int)$customer_points);
            $cart_rule->quantity = 1;
            $cart_rule->highlight = 1;
            $cart_rule->quantity_per_user = 1;
            $cart_rule->reduction_tax = (bool)Configuration::get('PS_LOYALTY_TAX');

            // If merchandise returns are allowed, the voucher musn't be usable before this max return date
            $date_from = Db::getInstance()->getValue('
            SELECT UNIX_TIMESTAMP(date_add) n
            FROM '._DB_PREFIX_.'loyalty
            WHERE id_cart_rule = 0 AND id_customer = '.(int)$this->context->cookie->id_customer.'
            ORDER BY date_add DESC');

            if (Configuration::get('PS_ORDER_RETURN'))
                $date_from += 60 * 60 * 24 * (int)Configuration::get('PS_ORDER_RETURN_NB_DAYS');

            $cart_rule->date_from = date('Y-m-d H:i:s', $date_from);
            $cart_rule->date_to = date('Y-m-d H:i:s', strtotime($cart_rule->date_from.' +1 year'));

            $cart_rule->minimum_amount = (float)Configuration::get('PS_LOYALTY_MINIMAL');
            $cart_rule->minimum_amount_currency = (int)$this->context->currency->id;
            $cart_rule->active = 1;

            $categories = Configuration::get('PS_LOYALTY_VOUCHER_CATEGORY');
            if ($categories != '' && $categories != 0)
                $categories = explode(',', Configuration::get('PS_LOYALTY_VOUCHER_CATEGORY'));
            else
                die (Tools::displayError());

            $languages = Language::getLanguages(true);
            $default_text = Configuration::get('PS_LOYALTY_VOUCHER_DETAILS', (int)Configuration::get('PS_LANG_DEFAULT'));

            foreach ($languages as $language)
            {
                $text = Configuration::get('PS_LOYALTY_VOUCHER_DETAILS', (int)$language['id_lang']);
                $cart_rule->name[(int)$language['id_lang']] = $text ? strval($text) : strval($default_text);
            }


            $contains_categories = is_array($categories) && count($categories);
            if ($contains_categories)
                $cart_rule->product_restriction = 1;
            $cart_rule->add();

            //Restrict cartRules with categories
            if ($contains_categories)
            {

                //Creating rule group
                $id_cart_rule = (int)$cart_rule->id;
                $sql = "INSERT INTO "._DB_PREFIX_."cart_rule_product_rule_group (id_cart_rule, quantity) VALUES ('$id_cart_rule', 1)";
                Db::getInstance()->execute($sql);
                $id_group = (int)Db::getInstance()->Insert_ID();

                //Creating product rule
                $sql = "INSERT INTO "._DB_PREFIX_."cart_rule_product_rule (id_product_rule_group, type) VALUES ('$id_group', 'categories')";
                Db::getInstance()->execute($sql);
                $id_product_rule = (int)Db::getInstance()->Insert_ID();

                //Creating restrictions
                $values = array();
                foreach ($categories as $category) {
                    $category = (int)$category;
                    $values[] = "('$id_product_rule', '$category')";
                }
                $values = implode(',', $values);
                $sql = "INSERT INTO "._DB_PREFIX_."cart_rule_product_rule_value (id_product_rule, id_item) VALUES $values";
                Db::getInstance()->execute($sql);
            }



            // Register order(s) which contributed to create this voucher
            if (!LoyaltyModule::registerDiscount($cart_rule))
                $cart_rule->delete();
        }
    }
}
