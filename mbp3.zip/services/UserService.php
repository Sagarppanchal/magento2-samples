<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class UserService extends BaseService
{
    private $addressFieldsMap = array(
        'id_address'   => 'address_book_id',
        'firstname'    => 'firstname',
        'lastname'     => 'lastname',
        'address1'     => 'address1',
        'address2'     => 'address2',
        'city'         => 'city',
        'state'        => 'state',
        'id_country'   => 'country_id',
        'postcode'     => 'postcode',
        'company'      => 'company',
        'phone'        => 'phone',
        'phone_mobile' => 'phone_mobile'
    );
    
    public function userTraslatore($customerInfo)
    {
       $userArray = array();
       $userArray['customer_id'] = $customerInfo->id;
       $userArray['autologinid'] = ServiceFactory::factory('Mobicommercehelper')->encrypt($customerInfo->id);
       $userArray['email'] = $customerInfo->email;
       $userArray['firstname'] = $customerInfo->firstname;
       $userArray['lastname'] = $customerInfo->lastname;
       $userArray['fullname'] = $customerInfo->firstname." ".$customerInfo->lastname;
       $userArray['billing_address'] = ServiceFactory::factory('Checkout')->getBillingAddress();
       $userArray['shipping_address'] = ServiceFactory::factory('Checkout')->getShippingAddress();
       $addresses = $this->getCustomerAddresses($customerInfo->id);
       $userArray['addresses'] = $addresses;
       return $userArray; 
    }

    /**
     * added by yash
     * to get customer addresses
     */
    public function getCustomerAddresses($customer_id)
    {
        $addresses = array();
        $sql = '
            SELECT a.*, c.iso_code AS country_code, cl.name AS country, s.name AS region FROM '._DB_PREFIX_.'address AS a
            LEFT JOIN '._DB_PREFIX_.'country AS c ON (c.id_country = a.id_country)
            LEFT JOIN '._DB_PREFIX_.'country_lang AS cl ON (cl.id_country = c.id_country AND cl.id_lang = '.$this->context->cookie->id_lang.')
            LEFT JOIN '._DB_PREFIX_.'state AS s ON (s.id_state = a.id_state)
            WHERE a.id_customer = "'.$customer_id.'" 
                AND a.active = "1" 
                AND a.deleted = "0"
            GROUP BY a.id_address
                ';
        if ($results = Db::getInstance()->ExecuteS($sql)){
            foreach($results as $row){
                $_address = $row;
                $_address['id']           = $row['id_address'];
                $_address['fullname']     = $row['firstname'].' '.$row['lastname'];
                $_address['street'][0]    = $row['address1'];
                $_address['street'][1]    = $row['address2'];
                $_address['phone']        = $row['phone'];
                $_address['phone_mobile'] = $row['phone_mobile'];
                $_address['country_id']   = $row['country_code'];
                $addresses[] = $_address;
            }
        }
        return $addresses;
    }
    
    /* changed  by yash */
    public function getUserInfo()
    {
        $customerInfo = array();
        if($this->context->cookie->id_customer) {
            $customer = new Customer((int)$this->context->cookie->id_customer);
            $customerInfo = $this->userTraslatore($customer->getByEmail($customer->email));
        }

        return $customerInfo;
    }
    
    /**
     * check address's integrity
     * @param type $address
     * @author hujs
     */
    public function checkAddressIntegrity($address)
    {
        if ($address) {
            return (int) $address['address_book_id'] > 0
                    && $address['firstname']
                    && $address['lastname']
                    && (int) $address['country_id'] > 0
                    && $address['city']
                    && $address['postcode'];
        }
        return false;
    }

    /**
     * translate the osCommerce's address to mobicommerce's address format
     * @param type $address
     * @return type
     * @author hujs
     */
    public function translateAddress($address)
    {
        $translatedAddress = array();
        $address['state'] = State::getNameById($address['id_state']);
        foreach ($this->addressFieldsMap as $key => $value) {
            $translatedAddress[$value] = $address[$key];
        }
        return $translatedAddress;
    }

    /**
     * Get user's addresses
     * @global type $customer_id
     * @return type
     * @author hujs
     */
    public function getAddresses()
    {
        $customer = new Customer($this->context->cookie->id_customer);
        if (!Validate::isLoadedObject($customer)) {
            return array();
        }

        $addressesInfo = $customer->getAddresses($this->context->cookie->id_lang);
        $addresses = array();
        foreach ($addressesInfo as $addresse) {
            $addresses[] = $this->translateAddress($addresse);
        }
        return $addresses;
    }

    public function checkEmailExists($email)
    {
        if (!empty($email)) {
            return Customer::customerExists($email, false, false);
        }
        return false;
    }
    
    public function update($userInfo)
    {
        $return = array(
            'status'  => true,
            'message' => $this->l('The account information has been saved.')
            );

        $customer = new Customer((int)$this->context->cookie->id_customer);
        //if(!empty($userInfo['email']))
        {
            $customer->email  = $userInfo['email'];
            $customer->firstname = $userInfo['firstname'];
            $customer->lastname = $userInfo['lastname'];

            $errors = $customer->validateController();
            if ($this->context->customer->email != $userInfo['email'] && Customer::customerExists($userInfo['email'], true)) {
                $errors[] = Tools::displayError('An account using this email address has already been registered.');
            }

            if(!empty($errors)){
                $return['status'] = false;
                $return['message'] = implode(',', $errors);
                return $return;
            }

            if($customer->update())
            {
                $this->context->cookie->id_customer = (int) ($customer->id);
                $this->context->cookie->customer_lastname = $customer->lastname;
                $this->context->cookie->customer_firstname = $customer->firstname;
                $this->context->cookie->passwd = $customer->passwd;
                $this->context->cookie->logged = 1;
                $this->context->cookie->email = $customer->email;
                $this->context->cookie->is_guest = $customer->is_guest;
                /* Update cart address */
                $this->context->cart->secure_key = $customer->secure_key;
                return $return;
            }
            else
            {
                $return['status'] = false;
                return $return;
            }
        }
        /*
        else
        {
            $return['status'] = false;
            return $return;
        }
        */
    }
    
    public function register($registerInfo) {
        $customer = new Customer();
        $customer->active = 1;
        $customer->is_guest = 0;
        $customer->email = $registerInfo['email'];
        $customer->passwd = md5(_COOKIE_KEY_.$registerInfo['password']);
        $name = explode('@', $registerInfo['email']);
        $registerInfo['firstname'] == $name[0] && !Validate::isName($registerInfo['firstname']) && $registerInfo['firstname'] = 'no';
        $customer->firstname = $registerInfo['firstname'];
        $customer->lastname = empty($registerInfo['lastname']) ? 'no' : $registerInfo['lastname'];

        $error = array();
        Validate::isEmail($customer->email) || $error[] = Tools::displayError('Invalid e-mail address');
        Validate::isName($customer->firstname) || $error[] = Tools::displayError('first name Invalid');
        Validate::isName($customer->lastname) || $error[] = Tools::displayError('lastname name Invalid');

        if (sizeof($error)) {
            return $error;
        }

        if(isset($registerInfo['customAttributes']) && !empty($registerInfo['customAttributes'])){
            foreach($registerInfo['customAttributes'] as $_attr_key => $_attr_value){
                $customer->$_attr_key = $_attr_value;
            }
        }

        /* Preparing address */
        /*
        $address = new Address();
        $address->firstname = $customer->firstname;
        $address->lastname = $customer->lastname;
        $address->id_customer = 1;
        $address->id_country = (int) _PS_COUNTRY_DEFAULT_;
        $address->alias = 'from mobile';
        $address->city = ' ';
        $address->address1 = ' ';
        $address->postcode = '94538';
        */
        if (!$customer->add()) {
            return false;
        } else {
            /*
            $address->id_customer = (int) ($customer->id);
            $address->add();
            */

            //<<<<<<<<<<<<<<< Added By Dharmendra For Lookatspain>>>>>>
            /*$params = $_REQUEST;
            $customer_id = $customer->id;
            $table = _DB_PREFIX_.'customer_custom_field_value';
            
            foreach ($params['customAttributes'] as $field_key => $field_value) {
                if (strpos($field_key, 'field') !== false) {
                    $field_key = explode('field', $field_key);
                    $field_key = $field_key[1];
                    Db::getInstance()->insert('customer_custom_field_value', array(
                        'id_customer' => (int)$customer_id,
                        'id_custom_field'  => $field_key,
                        'id_custom_field_section'  => 4,
                        'value'  => $field_value,
                    ));
                }
            }
            if (isset($_REQUEST['customAttributes']['chkRecargoEquivalencia']))
            {    
                $sql = "SELECT id_customer FROM "._DB_PREFIX_."customer WHERE email = '".$_REQUEST['email']."' AND id_shop = ".Context::getContext()->shop->id;
                $index = DB::getInstance()->executeS($sql);
                $sql = Configuration::get('NOHRE_clientesConRecargo');
                $sql .= '|'.$index[0]['id_customer'];
                $q = "UPDATE "._DB_PREFIX_."configuration SET value='".$sql."' WHERE name='NOHRE_clientesConRecargo' AND (id_shop = ".Context::getContext()->shop->id." OR id_shop IS NULL)";
                DB::getInstance()->execute($q);
                $q = "UPDATE "._DB_PREFIX_."customer SET note = 'El cliente ha solicitado que se le aplique recargo de equivalencia' WHERE id_customer = ".$index[0]['id_customer'];
                DB::getInstance()->execute($q);
                Configuration::updateValue('NOHRE_clientesConRecargo',$sql);
            }
            */
            //Added By Dharmendra End Upto here

            $welcome = method_exists('Mail', 'l') ? Mail::l('Welcome', $this->context->cookie->id_lang) : 'Welcome';
            if (!$customer->is_guest) {
                Mail::Send($this->context->cookie->id_lang, 'account', $welcome, array('{email}' => $customer->email,
                    '{lastname}'  => $customer->lastname,
                    '{firstname}' => $customer->firstname,
                    '{passwd}'    => $registerInfo['password']), $customer->email, $customer->firstname . ' ' . $customer->lastname);
            }

            $this->context->cookie->id_customer = (int) ($customer->id);
            $this->context->cookie->customer_lastname = $customer->lastname;
            $this->context->cookie->customer_firstname = $customer->firstname;
            $this->context->cookie->passwd = $customer->passwd;
            $this->context->cookie->logged = 1;
            $this->context->cookie->email = $customer->email;
            $this->context->cookie->is_guest = $customer->is_guest;
            /* Update cart address */
            $this->context->cart->secure_key = $customer->secure_key;
            
            $this->context->cart->update();
        }
        return true;
    }

    public function checkUser($email,$pwd)
    {
        $customer = new Customer();
        $authentication = $customer->getByEmail(trim($email), trim($pwd));
        
        if (!$authentication || !$customer->id) {
            /* Handle brute force attacks */
            sleep(1);
            return false;
        } else {
            return true;
        }    
    } 
             
    /**
     * $loginInfo required email and password
     * @global type $this->cart
     * @param type $loginInfo
     * @return type
     * @author hujs
     */
    public function login($loginInfo, $id = null)
    {
        if(empty($id)){
            $customer = new Customer();
            $authentication = $customer->getByEmail($loginInfo['email'], $loginInfo['password']);
        }
        else{
            $authentication = true;
            $customer = new Customer($id);
        }
        
        if($customer->active != 1){
            $authentication = false;
        }
        //print_r($customer); exit;
        
        if (!$authentication || !$customer->id) {
            /* Handle brute force attacks */
            sleep(1);
            return false;
        } else {
            /*
            $id_compare = file_exists(_PS_CLASS_DIR_ . '/CompareProduct.php') && method_exists('CompareProduct', 'getIdCompareByIdCustomer') ? CompareProduct::getIdCompareByIdCustomer($customer->id) : 0;
            $this->context->cookie->id_compare = isset($this->context->cookie->id_compare) ? $this->context->cookie->id_compare : $id_compare;
            $this->context->cookie->id_customer = (int) ($customer->id);
            $this->context->cookie->customer_lastname = $customer->lastname;
            $this->context->cookie->customer_firstname = $customer->firstname;
            $this->context->cookie->logged = 1;

            $this->context->cookie->is_guest = 0;
            $this->context->cookie->passwd = $customer->passwd;
            $this->context->cookie->email = $customer->email;

            if (Configuration::get('PS_CART_FOLLOWING') AND (empty($this->context->cookie->id_cart) OR Cart::getNbProducts($this->context->cookie->id_cart) == 0))
                $this->context->cookie->id_cart = (int) (Cart::lastNoneOrderedCart((int) ($customer->id)));
            /* Update cart address */
            /*
            $this->context->cart->id_carrier = 0;
            $this->context->cart->id_address_delivery = Address::getFirstCustomerAddressId((int) ($customer->id));
            $this->context->cart->id_address_invoice = Address::getFirstCustomerAddressId((int) ($customer->id));
            // If a logged guest logs in as a customer, the cart secure key was already set and needs to be updated
            $this->context->cart->secure_key = $customer->secure_key;
            $this->context->cart->update();

            if ($this->context) {
                $this->context->customer = $customer;
            }
            */

            if (_PS_VERSION_ < '1.7') {
                $this->context->cookie->id_compare = isset($this->context->cookie->id_compare) ? $this->context->cookie->id_compare: CompareProduct::getIdCompareByIdCustomer($customer->id);
            }
            $this->context->cookie->id_customer = (int)($customer->id);
            $this->context->cookie->customer_lastname = $customer->lastname;
            $this->context->cookie->customer_firstname = $customer->firstname;
            $this->context->cookie->logged = 1;
            $customer->logged = 1;
            $this->context->cookie->is_guest = $customer->isGuest();
            $this->context->cookie->passwd = $customer->passwd;
            $this->context->cookie->email = $customer->email;

            // Add customer to the context
            $this->context->customer = $customer;

            if (Configuration::get('PS_CART_FOLLOWING') && (empty($this->context->cookie->id_cart) || Cart::getNbProducts($this->context->cookie->id_cart) == 0) && $id_cart = (int)Cart::lastNoneOrderedCart($this->context->customer->id)) {
                $this->context->cart = new Cart($id_cart);
            } else {
                $id_carrier = (int)$this->context->cart->id_carrier;
                $this->context->cart->id_carrier = 0;
                $this->context->cart->setDeliveryOption(null);
                $this->context->cart->id_address_delivery = (int)Address::getFirstCustomerAddressId((int)($customer->id));
                $this->context->cart->id_address_invoice = (int)Address::getFirstCustomerAddressId((int)($customer->id));
            }
            $this->context->cart->id_customer = (int)$customer->id;
            $this->context->cart->secure_key = $customer->secure_key;

            if ($this->ajax && isset($id_carrier) && $id_carrier && Configuration::get('PS_ORDER_PROCESS_TYPE')) {
                $delivery_option = array($this->context->cart->id_address_delivery => $id_carrier.',');
                $this->context->cart->setDeliveryOption($delivery_option);
            }

            $this->context->cart->save();
            $this->context->cookie->id_cart = (int)$this->context->cart->id;
            $this->context->cookie->write();
            $this->context->cart->autosetProductAddress();

            Hook::exec('actionAuthentication', array('customer' => $this->context->customer));

            // Login information have changed, so we check if the cart rules still apply
            CartRule::autoRemoveFromCart($this->context);
            CartRule::autoAddToCart($this->context);

            /*
            if (!$this->ajax) {
                $back = Tools::getValue('back','my-account');

                if ($back == Tools::secureReferrer($back)) {
                    Tools::redirect(html_entity_decode($back));
                }

                Tools::redirect('index.php?controller='.(($this->authRedirection !== false) ? urlencode($this->authRedirection) : $back));
            }
            */

            $this->_loginFromMobile($this->context->cookie->id_customer);
            return true;
        }
    }

    protected function _loginFromMobile($customer_id)
    {
        $data = $_REQUEST;
        if(isset($data['push_devicetoken']) && isset($data['appcode'])){
            $_data = array(
                'appcode'     => $data['appcode'],
                'devicetoken' => $data['push_devicetoken'],
                'userid'      => $customer_id
                );
                
            ServiceFactory::factory('Pushnotification')->updateDeviceTokenUser($_data);
        }
    }

    /**
     * validateForm
     * @param type $address
     * @return type
     * @author hujs
     */
    private function prepareSqlDataArrayForAddress($address)
    {
        if (method_exists($address, 'validateController')) {
            return $address->validateController();
        } else {
            return $address->validateControler();
        }
    }

    /**
     * get address by id
     * @param type $addressBookId
     * @return type
     * @author hujs
     */
    public function getAddress($addressBookId)
    {
        if (Address::addressExists($addressBookId)) {
            $address = new Address((int) $addressBookId, $this->context->cookie->id_lang);
            $address = $this->translateAddress($address->getFields());
            $address['street'] = array($address['address1'], $address['address2']);

            if($address['state'])
            {
                $address['region'] = $address['state'];
            }
            return $address;
        } else {
            return array();
        }
    }

    /**
     * delete  an entry from address book
     * @global type $registry
     * @param type $addressId
     * @return type
     * @author hujs
     */
    public function deleteAddress($id_address)
    {
        $errorMessages = array();
        $id_address = (int) $id_address;
        $address = new Address($id_address);
        if (Validate::isLoadedObject($address) && Customer::customerHasAddress($this->context->customer->id, $id_address))
        {
            if ($address->delete())
            {
                if ($this->context->cart->id_address_invoice == $address->id)
                    unset($this->context->cart->id_address_invoice);
                if ($this->context->cart->id_address_delivery == $address->id)
                {
                    unset($this->context->cart->id_address_delivery);
                    $this->context->cart->updateAddressId($address->id, (int)Address::getFirstCustomerAddressId(Context::getContext()->customer->id));
                }
            }
            else {
                $errorMessages[] = Tools::displayError('This address cannot be deleted.');
            }
        }
        return sizeof($errorMessages) ? $errorMessages : true;
    }

    public function updateAddress($addressInfo)
    {
        $address = new Address();
        if($addressInfo['address_id'])
            $address = new Address($addressInfo['address_id']);

        $country_id = $addressInfo['country_id'];
        $id_country = Country::getByIso($country_id, true);

        $address->alias        = $addressInfo['alias'];
        $address->firstname    = $addressInfo['firstname'];
        $address->lastname     = $addressInfo['lastname'];
        $address->id_country   = $id_country;
        $address->city         = $addressInfo['city'];
        $address->address1     = $addressInfo['address_1'];
        $address->address2     = $addressInfo['address_2'];
        $address->postcode     = $addressInfo['postcode'];
        $address->phone        = $addressInfo['phone'];
        $address->phone_mobile = $addressInfo['phone_mobile'];
		
        if(is_numeric($addressInfo['id_state'])){
            $address->id_state = $addressInfo['id_state'];
        }

        $address->id_customer = $this->context->cookie->id_customer;

        $errorMessages = $this->prepareSqlDataArrayForAddress($address);

        if (Configuration::get('PS_ONE_PHONE_AT_LEAST') && !$addressInfo['phone'] && !$addressInfo['phone_mobile']) {
            $errorMessages[] = Tools::displayError('You must register at least one phone number.');
        }

        if (empty($errorMessages)) {
            if (!$country = new Country((int) $address->id_country) OR !Validate::isLoadedObject($country))
                $errorMessages[] = Tools::displayError();

            /* US customer: normalize the address */
            if ($address->id_country == Country::getByIso('US')) {
                if (file_exists(_PS_TAASC_PATH_ . 'AddressStandardizationSolution.php')) {
                    include_once(_PS_TAASC_PATH_ . 'AddressStandardizationSolution.php');
                    $normalize = new AddressStandardizationSolution;
                    $address->address1 = $normalize->AddressLineStandardization($address->address1);
                    $address->address2 = $normalize->AddressLineStandardization($address->address2);
                }
            }

            $zip_code_format = $country->zip_code_format;
            if ($country->need_zip_code) {
                if (($address->postcode) AND $zip_code_format) {
                    $zip_regexp0 = '/^' . $zip_code_format . '$/ui';
                    $zip_regexp1 = str_replace(' ', '( |)', $zip_regexp0);
                    $zip_regexp2 = str_replace('-', '(-|)', $zip_regexp1);
                    $zip_regexp3 = str_replace('N', '[0-9]', $zip_regexp2);
                    $zip_regexp4 = str_replace('L', '[a-zA-Z]', $zip_regexp3);
                    $zip_regexp = str_replace('C', $country->iso_code, $zip_regexp4);
                    if (!preg_match($zip_regexp, $address->postcode))
                        $errorMessages[] = '<strong>' . Tools::displayError('Zip/ Postal code') . '</strong> ' . Tools::displayError('is invalid.') . '<br />' . Tools::displayError('Must be typed as follows:') . ' ' . str_replace('C', $country->iso_code, str_replace('N', '0', str_replace('L', 'A', $zip_code_format)));
                }
                elseif ($zip_code_format)
                    $errorMessages[] = '<strong>' . Tools::displayError('Zip/ Postal code') . '</strong> ' . Tools::displayError('is required.');
                elseif ($address->postcode AND !preg_match('/^[0-9a-zA-Z -]{4,9}$/ui', $address->postcode))
                    $errorMessages[] = '<strong>' . Tools::displayError('Zip/ Postal code') . '</strong> ' . Tools::displayError('is invalid.') . '<br />' . Tools::displayError('Must be typed as follows:') . ' ' . str_replace('C', $country->iso_code, str_replace('N', '0', str_replace('L', 'A', $zip_code_format)));
            }

            if ((int) ($country->contains_states) AND !(int) ($address->id_state))
                $errorMessages[] = Tools::displayError('This country requires a state selection.');

            //if (!sizeof($this->errors)) {
            if (!sizeof($errorMessages)) {
                $country = new Country((int) ($address->id_country));
                if (Validate::isLoadedObject($country) AND !$country->contains_states)
                    $address->id_state = 0;
                $address_old = new Address($addressInfo['address_id']);
                
                if ($address->save()) {
                    $this->context->cart->id_address_invoice = (int) ($address->id);
                    $this->context->cart->update();
                }
            }
        }

        return sizeof($errorMessages) ? $errorMessages : $this->l('The address has been saved.');
    }

    public function logout()
    {
        $this->context->cart->delete();
        $context = Context::getContext();
        $context->cookie->mylogout();
        $context->customer->logout();
        $context->customer->mylogout();
    }
}
