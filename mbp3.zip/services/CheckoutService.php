<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

class CheckoutService extends BaseService
{
    private $errors = array();
    private $isFreeShipping = false;
    private $isVirtual = false;
    private $_cart = null;
    public $mod = 'blockcart';

    public function __construct()
    {
        parent::__construct();
        ServiceFactory::factory('Mobicommercehelper')->autoLoginMobileUser();
    }

    public function detail()
    {
        $detail = array();
        $detail['shipping_address'] = $this->getShippingAddress();
        $detail['billing_address'] = $this->getBillingAddress();
        $detail['review_orders'] = array($this->getReviewOrder());
        $detail['need_billing_address'] = defined('NEED_BILLING_ADDRESS') ? NEED_BILLING_ADDRESS : FALSE;
        $detail['need_shipping_address'] = !ServiceFactory::factory('Store')->checkAddressIntegrity($detail['shipping_address']);
        $detail['need_select_shipping_method'] = (!$this->isVirtual && !$detail['review_orders'][0]['selected_shipping_method_id']);
        $detail['billing_address_valid'] = ServiceFactory::factory('Store')->checkAddressIntegrity($detail['billing_address']);

        $detail['price_infos'] = $this->getCart()->getPriceInfo();
        $detail['is_virtual'] = $this->context->cart->isVirtualCart();
        $detail['messages'] = $this->errors;
        if (isset($this->context->cookie->guest_uname))
        {
            $detail['uname'] = $this->context->cookie->guest_uname;
            unset($this->context->cookie->guest_uname);
        }
        return $detail;
    }

    public function getReviewOrder()
    {
        $order = array();
        $carriers = array();
        $order['items'] = $this->getCart()->getProducts();
        $order['shipping_methods'] = $this->getOrderShippingMethods($carriers);
        $order['selected_shipping_method_id'] = $this->selectShippingMethod($carriers);
        $this->context->cookie->coupon && $order['coupon_code'] = $this->context->cookie->coupon;

        return $order;
    }

    private function getSendToAddressId()
    {
        if (!$this->context->cart->id_address_delivery)
        {
            $this->context->cart->id_address_delivery = Address::getFirstCustomerAddressId($this->context->cookie->id_customer);
        }

        return $this->context->cart->id_address_delivery;
    }

    public function getShippingAddress()
    {
        $sendTo = $this->getSendToAddressId();
        if ($sendTo)
        {
            $addr = ServiceFactory::factory('User')->getAddress($sendTo);
            $country = new Country($addr['country_id']);
            $addr['country_id'] = $country->iso2;
            return $addr;
        }
        return array();
    }

    public function getBillingAddress()
    {
        $billto = $this->getBillToAddressId();
        if ($billto)
        {
            $addr = ServiceFactory::factory('User')->getAddress($billto);
            $country = new Country($addr['country_id']);
            $addr['country_id'] = $country->iso2;
            return $addr;
        }
        else
        {
            return array('firstname' => '');
        }
        return array();
    }

    public function getBillToAddressId()
    {
        if (!$this->context->cart->id_address_invoice)
        {
            $this->context->cart->id_address_invoice = Address::getFirstCustomerAddressId($this->context->cookie->id_customer);
        }

        return $this->context->cart->id_address_invoice;
    }

    public function selectShippingMethod($carriers)
    {
        if ($this->isFreeShipping || $this->isVirtual)
        {
            $this->context->cart->id_carrier = false;
        }
        else
        {
            $this->context->cart->id_carrier = $this->getDefaultCarrierSelection($carriers, $this->context->cart->id_carrier);
        }
        $this->context->cart->update();
        $this->context->cookie->id_carrier = $this->context->cart->id_carrier;
        return $this->context->cart->id_carrier ? $this->context->cart->id_carrier : 'free';
    }

    /**
     * Return the default carrier to use
     *
     * @param array $carriers
     * @param array $defaultCarrier the last carrier selected
     * @return number the id of the default carrier
     */
    public function getDefaultCarrierSelection($carriers, $default_carrier = 0)
    {
        if (empty($carriers))
        {
            return 0;
        }

        if ((int) $default_carrier != 0)
        {
            foreach ($carriers as $carrier)
            {
                if ($carrier['id_carrier'] == (int) $default_carrier)
                {
                    return (int) $carrier['id_carrier'];
                }
            }
        }

        foreach ($carriers as $carrier)
        {
            if ($carrier['id_carrier'] == (int) Configuration::get('PS_CARRIER_DEFAULT'))
            {
                return (int) $carrier['id_carrier'];
            }
        }

        return (int) $carriers[0]['id_carrier'];
    }

    public function getOrderShippingMethods(&$carriers)
    {
        if ($this->context->cart->isVirtualCart())
        {
            //virtual cart
            $this->isVirtual = true;
            return array();
        }
        else if ($this->context->cart->getOrderTotal(true, ONLY_SHIPPING) == 0)
        {
            // Free fees
            /*
            return array(array(
                    'sm_id'       => 'free',
                    'title'       => $this->l('Free Shipping!'),
                    'price'       => 0,
                    'currency'    => $this->context->cookie->currency,
                    'description' => ''
                )
            );
            */
        }

        $availableShippingMethods = array();
        if ($this->context->cart->id_address_delivery)
        {
            $deliveryAddress = new Address($this->context->cart->id_address_delivery);
        }
        if ($this->context->cookie->id_customer)
        {
            $customer = new Customer((int) ($this->context->cookie->id_customer));
            $groups = $customer->getGroups();
        }
        else
        {
            $groups = array(1);
        }

        /*
        if (method_exists('Carrier', 'getCarriersForOrder'))
        {
            $carriers = Carrier::getCarriersForOrder((int) Country::getIdZone((isset($deliveryAddress) && (int) $deliveryAddress->id) ? (int) $deliveryAddress->id_country : (int) _PS_COUNTRY_DEFAULT_), $groups);
        }
        else
        */
        {
            /*
            $id_zone = (int) Address::getZoneById(intval($this->context->cart->id_address_delivery));
            $carriers = Carrier::getCarriers(intval($this->context->cookie->id_lang), true, false, $id_zone);
            foreach ($carriers as &$row) {
                $row['price'] = $this->context->cart->getOrderShippingCost(intval($row['id_carrier']));
            }
            */

            /*
            $address = new Address($this->context->cart->id_address_delivery);
            $id_zone = Address::getZoneById($address->id);
            $carriers = Carrier::getCarriersForOrder($id_zone, $groups);
            */

            $carriers = $this->context->cart->simulateCarriersOutput(null, true);
            foreach($carriers as &$_carrier)
            {
                $_carrier['id_carrier'] = Cart::desintifier($_carrier['id_carrier'], '');
            }
        }
        
        //Customization for jenil paramr ayurvedamart
        /*$supercheckoutdata = Tools::unSerialize(Configuration::get('VELOCITY_SUPERCHECKOUT_DATA'));
        */
        //Customization for jenil paramr ayurvedamart end

        foreach ($carriers as $carrier)
        {
            /*
            if ($carrier['img'] && file_exists(_PS_ROOT_DIR_ . $carrier['img']))
            {
                $title = '<img src="' . Tools::getHttpHost(true) . $carrier['img'] . '" alt="My carrier"> ' . $carrier['name'];
            }
            else
            {
                $title = $carrier['name'];
            }
            */
            $title = $carrier['name'];
            $logo = null;
            if(isset($carrier['img']) && $carrier['img'] && file_exists(_PS_ROOT_DIR_ . $carrier['img']))
            {
                $logo = Tools::getHttpHost(true) . $carrier['img'];
            }
            else if (Module::isInstalled('onepagecheckoutps') && Module::isEnabled('onepagecheckoutps'))
            {
                $logo = Tools::getHttpHost(true) . '/modules/onepagecheckoutps/views/img/shipping.png';
            }

            //Customization for jenil paramr ayurvedamart
            /*$id_lang = (int) $this->context->cookie->id_lang;
            if(isset($supercheckoutdata['delivery_method'][$id_carrier]['title'][$id_lang])){
                $title = $supercheckoutdata['delivery_method'][$id_carrier]['title'][$id_lang];
            }*/
            //Customization for jenil paramr ayurvedamart end

            $_method = array();
            $_method['sm_id'] = $carrier['id_carrier'];
            $_method['title'] = $title;
            $_method['logo']  = $logo;
            $_method['price'] = $carrier['price'];
            $_method['price_tax_exc'] = $carrier['price'];
            if(isset($carrier['price_tax_exc'])){
                $_method['price_tax_exc'] = $carrier['price_tax_exc'];
            }
            $_method['currency'] = $this->context->cookie->currency;
            $_method['instructions'] = $carrier['delay'];
            /*
            if($_method['sm_id'] == '27'){
                $range = RangePrice::getRanges(27);
                $t = $this->cart->getOrderTotal(true, Cart::ONLY_PRODUCTS);
                if($t < $range[0]['delimiter1'] || $t > $range[0]['delimiter2']){
                    continue;
                }
            }
            */

            $availableShippingMethods[] = $_method;
        }

        return $availableShippingMethods;
    }

    private function getCart()
    {
        if (is_null($this->_cart))
        {
            $this->_cart = ServiceFactory::factory('ShoppingCart');
        }

        return $this->_cart;
    }

    public function addAddress($address)
    {
        if ($this->context->cookie->isLogged())
        {
            $result = ServiceFactory::factory('User')->addAddress($address);

            if (is_numeric($result))
            {
                //for now,keep the two address same
                $this->context->cart->id_address_delivery = $result;
                $this->context->cart->id_address_invoice = $result;
            }

            return $result;
        }
    }

    public function updateAddress($address)
    {
        if ($this->context->cookie->isLogged())
        {
            if ($address)
            {
                $this->context->cart->id_address_invoice = $address['id_address_invoice'];
                $this->context->cart->id_address_delivery = $address['id_address_delivery'];

                CartRule::autoRemoveFromCart($this->context);
                CartRule::autoAddToCart($this->context);

                $this->context->cart->update();

                $this->context->cart->id_address_invoice = $address['id_address_invoice'];
                $this->context->cart->id_address_delivery = $address['id_address_delivery'];
                $this->context->cart->update();
            }
        }
    }

    public function updateShippingMethod($shippingMethod)
    {
        if (is_numeric($shippingMethod) && $shippingMethod > 0)
        {
            $this->context->cart->id_carrier = (int)$shippingMethod;  //affect cart shipping price calculate

            /**
             * added by tauseef 
             * 06-05-2016
             * as it was selecting only 1st shipping method for many clients
             */
            $this->context->cart->setDeliveryOption(array($this->context->cart->id_address_delivery => ''.$shippingMethod.','));
            /* added by tauseef - upto here */

            $this->context->cookie->id_carrier = $this->context->cart->id_carrier;   //save id_carrier
        }
    }

    public function updateCoupon($couponCode)
    {
        if (empty($couponCode))
        {
            if (Validate::isUnsignedId($this->context->cookie->id_coupon))
            {
                $this->context->cart->deleteDiscount($this->context->cookie->id_coupon);
                unset($this->context->cookie->coupon);
                unset($this->context->cookie->id_coupon);
            }
        }
        else
        {
            $errors = array();
            if (!Validate::isDiscountName($couponCode))
            {
                $errors[] = Tools::displayError('Voucher name invalid.');
            }
            else
            {
                $discount = new Discount((int) (Discount::getIdByName($couponCode)));
                if (Validate::isLoadedObject($discount))
                {
                    if (($tmpError = $this->context->cart->checkDiscountValidity($discount, $this->context->cart->getDiscounts(), $this->context->cart->getOrderTotal(), $this->context->cart->getProducts(), true)))
                        $errors[] = $tmpError;
                }
                else
                {
                    $errors[] = Tools::displayError('Voucher name invalid.');
                }

                if (!sizeof($errors))
                {
                    $this->context->cart->addDiscount((int) ($discount->id));
                    $this->context->cookie->coupon = $couponCode;
                    $this->context->cookie->id_coupon = $discount->id;
                    $this->context->cart->getDiscounts(false, true); //reflash cart discount
                }
            }
        }

        /* Is there only virtual product in cart */
        if ($this->context->cart->isVirtualCart())
        {
            $this->context->cart->id_carrier = 0;
            $this->context->cart->update();
        }

        return $errors;
    }
}
