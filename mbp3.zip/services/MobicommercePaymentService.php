<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

defined('_PS_OS_CHEQUE_') || define('_PS_OS_CHEQUE_', Configuration::get('PS_OS_CHEQUE'));
defined('_PS_OS_PAYMENT_') || define('_PS_OS_PAYMENT_', Configuration::get('PS_OS_PAYMENT'));
defined('_PS_OS_ERROR_') || define('_PS_OS_ERROR_', Configuration::get('PS_OS_ERROR'));
defined('PS_OS_PREPARATION') || define('PS_OS_PREPARATION', Configuration::get('PS_OS_PREPARATION'));

class FreeOrder extends PaymentModule
{
    public $active = 1;
    public $name = 'free_order';
    public $displayName = 'free_order';
}

class MobicommercePaymentService extends PaymentModule
{
    const STATE_NEW = 'new';
    const STATE_PENDING_PAYMENT = 'pending_payment';
    const STATE_PROCESSING = 'processing';
    const STATE_COMPLETE = 'complete';
    const STATE_CLOSED = 'closed';
    const STATE_CANCELED = 'canceled';
    const STATE_HOLDED = 'holded';
    const STATE_PAYMENT_REVIEW = 'payment_review';

    public function __construct() {
        parent::__construct();
        $this->active = true;
    }

    /**
     * payment from mobile
     * @param type $method
     * @return type\
     */
    public function placeOrder($method, $message = '')
    {
        if ($this->context->cart->getOrderTotal() <= 0)
        {
            $order = new FreeOrder();
            $order->free_order_class = true;
            $order->validateOrder($this->context->cart->id, Configuration::get('PS_OS_PAYMENT'), 0, Tools::displayError('Free order', false), null, array(), null, false, $this->context->cart->secure_key);
            $order_id = (int)Order::getOrderByCartId($this->context->cart->id);
            $order = new Order($order_id);
        }
        else
        {
            $id_cart = $this->context->cookie->id_cart;
            if(in_array($method, array("cashondelivery", "cashondeliveryplus")))
            {
                $id_order_state = PS_OS_PREPARATION;
                $id_order_state_string = 'PS_OS_PREPARATION';
            }
            else if($id_order_state = Configuration::get('PS_OS_'.strtoupper($method))){
                $id_order_state_string = 'PS_OS_'.strtoupper($method);
            }
            else
            {
                $id_order_state = _PS_OS_CHEQUE_;
                $id_order_state_string = 'PS_OS_CHEQUE';
            }

            if(in_array($method, array("codfee"))){
                $id_order_state_string = 'PS_OS_PREPARATION';
            }

            $extraVars = array();
            $amountPaid = (float) (Tools::ps_round((float) ($this->context->cart->getOrderTotal(true, BOTH)), 2));
            $total = $this->context->cart->getOrderTotal(true, Cart::BOTH);
            
            $method = Tools::getValue('payment_method_name', $method);
            $this->name = $method;
            
            //if(in_array($method, array("cashondelivery", "cashondeliveryplus", "cheque"))){
            if(Module::isInstalled($method)){
                $customer = new Customer((int)$this->context->cart->id_customer);
                $total = $this->context->cart->getOrderTotal(true, Cart::BOTH)+ Tools::convertPrice($this->getDobirecne());
                $this->module = Module::getInstanceByName($method);
                if($method == 'codfee') {
                    $cashOnDelivery = new CodFee();
                    $fee = (float)Tools::ps_round((float)$cashOnDelivery->getFeeCost($this->context->cart), 2);

                    $result = $this->module->validateOrder16((int)$this->context->cart->id, Configuration::get($id_order_state_string), $total, $fee, $this->module->displayName, null, array(), null, false, $customer->secure_key);
                }
                else
                {
                    $result = $this->module->validateOrder((int)$this->context->cart->id, Configuration::get($id_order_state_string), $total, $this->module->displayName, null, array(), null, false, $customer->secure_key);
                }
                $this->currentOrder = $this->module->currentOrder;
            }
            else{
                $result = $this->validateOrder($id_cart, $id_order_state, $total, $method, $message, $extraVars, NULL, false, $this->context->cart->secure_key);
            }
            
            if ($result === true) {
                unset($this->context->cookie->id_cart);
                unset($this->context->cookie->id_order);
                $order = new Order($this->currentOrder);
            }
            return array($result, $order, NULL);
        }
    }

    public function mobicommercePaymentDone($order_id, $custom_kc_comments, $payment_status)
    {
        $status = (Tools::strtolower($payment_status) == 'succeed') ? $this->getOrderState() : _PS_OS_ERROR_;
        $orderHistory = new OrderHistory();
        $orderHistory->id_order = (int) ($order_id);
        $orderHistory->changeIdOrderState($status, $order_id);
        $orderHistory->addWithemail();
        $msg = new Message();
        $message = strip_tags($custom_kc_comments, '<br>');
        if (Validate::isCleanHtml($message)) {
            $msg->message = $message;
            $msg->id_order = intval($order_id);
            $msg->private = 1;
            $msg->add();
        }
        $order = new Order($order_id);
        return array(TRUE, $order);
    }

    private function getOrderState()
    {
        if (!isset($_POST['order_state'])) {
            return _PS_OS_PAYMENT_;
        }

        $order_status_id = _PS_OS_PAYMENT_;
        switch ($_POST['order_state']) {
            case self::STATE_NEW:
                $order_status_id = defined('_PS_OS_PREPARATION_') ? _PS_OS_PREPARATION_ : Configuration::get('PS_OS_PREPARATION');
                break;
            case self::STATE_HOLDED:
                $order_status_id = _PS_OS_CHEQUE_;
                break;
            case self::STATE_PAYMENT_REVIEW:
                $order_status_id = defined('_PS_OS_REFUND_') ? _PS_OS_REFUND_ : Configuration::get('PS_OS_REFUND');
                break;
            case self::STATE_PENDING_PAYMENT:
                $order_status_id = defined('_PS_OS_PREPARATION_') ? _PS_OS_PREPARATION_ : Configuration::get('PS_OS_PREPARATION');
                break;
            case self::STATE_CANCELED:
                $order_status_id = defined('_PS_OS_CANCELED_') ? _PS_OS_CANCELED_ : Configuration::get('PS_OS_CANCELED');
                break;
            default:
                break;
        }

        return $order_status_id;
    }

    public function getDobirecne()
    {
        $dobirecne=Configuration::get('COD_FEE');
        if( Configuration::get('COD_FEEFREE') > 0 
        && $this->context->cart->getOrderTotal(false, Cart::BOTH_WITHOUT_SHIPPING) > Tools::convertPrice(Configuration::get('COD_FEEFREE'))  ) 
        $dobirecne=0;

        return $dobirecne;
    }

    public function getPaymentMethods()
    {
        $methods = array(
            'bankwire'            => '18',
            'cheque'              => '18',
            'cashondelivery'      => '18',
            'satispay'            => '18',
            'codfee'              => '18',
            'payu'                => '18',
            'paytm'               => '18',
            'ccavenue'            => '18',

            'parsianpayment'      => '9',
            'bankmellat'          => '9',
            'dmtbanks'            => '9',
            'paypal'              => '9',
            'paypalwithfee'       => '9',
            'paypalusa'           => '9',
            'mymodpayment'        => '9',
            'ktc'                 => '9',
            'sid'                 => '9',
            'setcomhf'            => '9',
            'bankwirethai'        => '9',
            'redsys'              => '9',
            'ebs'                 => '9',
            'pwapresta'           => '9',
            'payfortfort'         => '9',
            'payfast'             => '9',
            'multisafepayconnect' => '9',
            //'satispay'            => '9'
            );

        return $methods;
    }

    public function getExternalPaymentMethods()
    {
        $external_methods = array();
        $methods = $this->getPaymentMethods();
        foreach($methods as $_method_key => $_method_value)
        {
            if($_method_value == '9')
            {
                $external_methods[] = $_method_key;
            }
        }

        return $external_methods;
    }

    public function getType18PaymentMethods()
    {
        $external_methods = array();
        $methods = $this->getPaymentMethods();
        foreach($methods as $_method_key => $_method_value)
        {
            if($_method_value == '18')
            {
                $external_methods[] = $_method_key;
            }
        }

        return $external_methods;   
    }
}
