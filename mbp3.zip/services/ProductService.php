<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE')) {
    header('HTTP/1.1 404 Not Found');
    die();
}

class ProductService extends BaseService
{
    public function __construct()
    {
        parent::__construct();
        ServiceFactory::factory('Mobicommercehelper')->autoLoginMobileUser();
    }

    private function setDefaultFilterIfNeed(&$filter)
    {
        if (!$filter['page_size']) {
            $filter['page_size'] = 10;
        }
        if (!$filter['page_no']) {
            $filter['page_no'] = 1;
        }
        if (!$filter['sort_by']) {
            $filter['sort_by'] = 'id_product';
        }
        if (!$filter['sort_order']) {
            $filter['sort_order'] = 'desc';
        }
        
        $filter['page_no'] = Tools::getValue('p', $filter['page_no']);
        $filter['page_size'] = Tools::getValue('n', $filter['page_size']);
    }
    
    /**
     * Get the products,filter is specified by the $filter parameter
     * 
     * @param array $filter array
     * @return array
     * @author hujs
     */
    public function searchProducts($filter)
    {
        $this->setDefaultFilterIfNeed($filter);
        $products = array('total_results' => 0, 'items' => array());
        if (isset($filter['item_ids']) && !empty($filter['item_ids']))
        {
            $products = $this->getSpecifiedProducts($filter);
        }
        else if (isset($filter['q']) && $filter['q'])
        {
            $products = $this->getProductsByQuery($filter);
        } 

        $returnResult['filters'] = array(
            'message' => '',
            'data'    => array()
            );
        $returnResult['product_count'] = count($products['items']);
        if(isset($products['total_results'])){
            $returnResult['product_count'] = $products['total_results'];
        }
        $returnResult['products'] = $products['items'];
        
        return $returnResult;
    }
    
    /**
     * Get the products,filter is specified by the $filter parameter
     * 
     * @param array $filter array
     * @return array
     * @author hujs
     */
    public function getProducts($filter)
    {
        $this->setDefaultFilterIfNeed($filter);
        $products = array('total_results' => 0, 'items' => array());
        if (isset($filter['filters']) && !empty($filter['filters'])) {
            $products = $this->getProductFilterbased($filter);
        } else if (isset($filter['is_specials']) && intval($filter['is_specials'])) {
            $products = $this->getSpecialProducts($filter);
        } else if (isset($filter['query']) && $filter['query']) {
            $products = $this->getProductsByQuery($filter);
        } else if (isset($filter['category_id'])) {
            $products = $this->getProductsByCategory($filter, $filter['category_id']);
        } else {
            $products = $this->getProductsByCategory($filter);
        }

        $returnResult = array();
        $returnResult['products'] = $products['items'] ? $products['items'] : array();
        
        // added by yash
        $returnResult['filters'] = array(
            'message' => '',
            'data'    => $this->getProductFilters($filter)
            );
        $returnResult['product_count'] = count($products['items']);
        if(isset($products['total_results'])){
            $returnResult['product_count'] = $products['total_results'];
        }
        // added by yash - upto here
        
        return $returnResult;
    }
    
    public function getProductFilterbased($filter)
    {
        $proudctTranslator = ServiceFactory::factory('ProductTranslator');
        $selectedFilter = $this->convertFilterArray($filter['filters']);
        //for some clients, they use below module
        //$module_name = 'blocklayered_mod';
        $module_name = 'blocklayered';
        $_nb_products = 0;
        if (Module::isInstalled($module_name) && Module::isEnabled($module_name))
        {
            $mod = Module::getInstanceByName($module_name);
            if (method_exists($mod, 'getProducts'))
                $mod->getProducts($selectedFilter,$search, $_nb_products);
        }
        foreach ($search as $row) {
            $proudctTranslator->clear();
            $proudctTranslator->setProduct($row);
            $products['items'][] = $proudctTranslator->getListingItemInfo();
        }
        $products ['total_results'] = $_nb_products;
        return $products;
    }
    
    /**
     * get products by category,the category id is specified in the $filter array
     * @param type $filter
     * @return type
     * @author hujs
     */
    public function getProductsByCategory($filter, $categoryId = 0)
    {
        $proudctTranslator = ServiceFactory::factory('ProductTranslator');

        if ($categoryId > 0) {
            $category = new Category($categoryId, $this->context->cookie->id_lang);
            $rows = $category->getProducts($this->context->cookie->id_lang, $filter['page_no'], $filter['page_size'], $filter['sort_by'], $filter['sort_order'], false);
            $total = $category->getProducts($this->context->cookie->id_lang, $filter['page_no'], $filter['page_size'], $filter['sort_by'], $filter['sort_order'], true);
        } else if($filter['widget_type'] == "bestseller") {
            $rows = ProductSale::getBestSales($this->context->language->id, ($filter['page_no'] - 1), $filter['page_size'], 'sales', $filter['sort_order']);
            $total = count($rows);
            //$total = Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'product` p LEFT JOIN `' . _DB_PREFIX_ . 'category_product` cp ON (p.`id_product` = cp.`id_product`) WHERE  p.`active` = 1');
        }
        /**
         * added by yash
         * 2017-09-27
         * recently viewed arrivals products not comming as per user group
         */
        else if($filter['widget_type'] == "productviewed") {
            $productsViewed = (isset($this->context->cookie->viewed) && !empty($this->context->cookie->viewed)) ? array_slice(array_reverse(explode(',', $this->context->cookie->viewed)), ($filter['page_no'] - 1), $filter['page_size']) : array();

            if (count($productsViewed))
            {
                $result_with_product_id = array();
                $rows = array();
                
                $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('SELECT * FROM `' . _DB_PREFIX_ . 'product` p WHERE  p.`active` = 1 AND p.`id_product` IN ("'.implode('","', $productsViewed).'")');
                foreach($result as $_result) {
                    $result_with_product_id[$_result['id_product']] = $_result;
                }

                foreach($productsViewed as $_viewed) {
                    if(isset($result_with_product_id[$_viewed])) {
                        $rows[] = $result_with_product_id[$_viewed];
                    }
                }
                $total = count($rows);
            }
            else
            {
                $rows = array();
                $total = 0;
            }
            //$total = Product::getNewProducts($this->context->cookie->id_lang, ($filter['page_no'] - 1), $filter['page_size'], true);
        }
        /**
         * added by yash
         * 2017-09-27
         * new arrivals products not comming as per user group
         */
        else if($filter['widget_type'] == "newarrivals") {
            $rows = Product::getNewProducts($this->context->cookie->id_lang, ($filter['page_no'] - 1), $filter['page_size']);
            $total = count($rows);
            //$total = Product::getNewProducts($this->context->cookie->id_lang, ($filter['page_no'] - 1), $filter['page_size'], true);
        } else {
            $start = max(($filter['page_no'] - 1) * $filter['page_size'], 0);
            $rows = Product::getProducts($this->context->cookie->id_lang, $start, $filter['page_size'], $filter['sort_by'], $filter['sort_order'], false, true);
            $total = Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'product` p LEFT JOIN `' . _DB_PREFIX_ . 'category_product` cp ON (p.`id_product` = cp.`id_product`) WHERE  p.`active` = 1');
        }

        $products = array();
        $products['items'] = array();
        if($rows) {
            foreach ($rows as $row) {
                $proudctTranslator->clear();
                $proudctTranslator->setProduct($row);
                $products['items'][] = $proudctTranslator->getListingItemInfo();
            }
        }
        $products['total_results'] = $total;
        return $products;
    }

    /**
     * get product by name
     * @param type $filter
     * @return int
     * @author hujs
     */
    public function getProductsByQuery($filter)
    {
        if (is_null($filter['q']))
        {
            return array('total_results' => 0, 'items' => array());
        }

        $orderBy = Tools::getProductsOrder('by', $filter['sort_by']);
        $orderWay = Tools::getProductsOrder('way', $filter['sort_order']);
        $query = Tools::stripslashes(urldecode(preg_replace('/((\%5C0+)|(\%00+))/i', '', urlencode($filter['q']))));
        
        $search = Search::find($this->context->cookie->id_lang, $query, $filter['page_no'], $filter['page_size'], $orderBy, $orderWay);
        
        $proudctTranslator = ServiceFactory::factory('ProductTranslator');

        $products = array('items' => array(), 'total_results' => 0);

        foreach ($search['result'] as $row) {
            $proudctTranslator->clear();
            $proudctTranslator->setProduct($row);
            //$proudctTranslator->getItemBaseInfo();
            //$proudctTranslator->getItemPrices();
            //$proudctTranslator->getGroceryItems();
            //$products['items'][] = $proudctTranslator->getTranslatedItem();
            $products['items'][] = $proudctTranslator->getListingItemInfo();
        }
        $products['total_results'] = $search['total'];
        return $products;
    }

    /**
     * get special products
     * @global type $languages_id
     * @return type
     * @author hujs
     */
    public function getSpecialProducts($filter)
    {
        $pageNo = ($filter['page_no'] - 1 < 0 ? 0 : $filter['page_no'] - 1) * $filter['page_size'];

        $db = DB::getInstance();
        $resource = $db->ExecuteS("
			SELECT `id_product`
			FROM `" . _DB_PREFIX_ . "specific_price`
			LIMIT $pageNo, {$filter['page_size']}", false);
        $count = $db->getValue("SELECT count(*) count FROM `" . _DB_PREFIX_ . "specific_price`");

        $productTranslator = ServiceFactory::factory('ProductTranslator');
        while ($row = $db->nextRow($resource)) {
            $productTranslator->clear();
            $productTranslator->loadProductById($row['id_product']);
            //$productTranslator->getItemBaseInfo();
            //$productTranslator->getItemPrices();
            //$productTranslator->getGroceryItems();
            //$items[] = $productTranslator->getTranslatedItem();
            $items[] = $proudctTranslator->getListingItemInfo();
        }
        $returnResult['total_results'] = $count;
        $returnResult['items'] = $items;

        return $returnResult;
    }

    /**
     * 
     * @global type $registry
     * @global type $languages_id
     * @param array $productIds
     * @return type
     * @author hujs
     */
    public function getSpecifiedProducts($filter)
    {
        if (!is_array($filter['item_ids'])) {
            $filter['item_ids'] = explode(',', $filter['item_ids']);
        }
        $filter['item_ids'] = array_filter($filter['item_ids'], 'is_numeric');
        $count = count($filter['item_ids']);
        $start = max(($filter['page_no'] - 1) * $filter['page_size'], 0);
        $productIds = array_slice($filter['item_ids'], $start, $filter['page_size']);
        $productTranslator = ServiceFactory::factory('ProductTranslator');

        $items = array();
        foreach ($productIds as $productId) {
            $productTranslator->loadProductById($productId);
            //$productTranslator->getItemBaseInfo();
            //$productTranslator->getItemPrices();
            //$productTranslator->getGroceryItems();
            //$items[] = $productTranslator->getTranslatedItem();
            $items[] = $proudctTranslator->getListingItemInfo();
            $productTranslator->clear();
        }
        $returnResult = array();
        $returnResult['total_results'] = $count;
        $returnResult['items'] = $items;

        return $returnResult;
    }

    public function getProduct($productId)
    {
        if (is_numeric($productId)) {
            $productTranslator = ServiceFactory::factory('ProductTranslator');
            $productTranslator->loadProductById($productId);
            return $productTranslator->getListingItemInfo();
        }
        return array();
    }
    
    public function getProductFilters($filter)
    {
        //for some clients, they use below module
        //$module_name = 'blocklayered_mod';
        $module_name = 'blocklayered';
        $filters = array();    
        if (Module::isInstalled($module_name) && Module::isEnabled($module_name))
        {
            $mod = Module::getInstanceByName($module_name);
            $selectedFilter = array();
            if(isset($filter['filter']))
                $selectedFilter = $this->convertFilterArray($filter['filter']);
            
            if (method_exists($mod, 'getFilterBlock'))
                $filters =  $mod->getFilterBlock($selectedFilter);
        }
        $filterArrayToReturn = array();
        if(isset($filters['filters']))
        {
            foreach($filters['filters'] as $filter)
            {
                $type = $filter['type'];
                if(in_array($type, array('id_feature'))){
                    $type = "select";
                }
                else if(in_array($type, array('price'))){
                    $type = "price";
                }
                else{
                    $type = "select";
                }

                $f = array();
                $f['attributeCode'] = $filter['type'];
                $f['attributeCodePresta'] = $filter['type'].'_'.$filter['id_key'];
                $f['type'] = $type;
                $f['label'] = $filter['name'];
                $f['code'] = $filter['id_key'];

                if($type == 'price'){
                    $f['min'] = $filter['min'];
                    $f['max'] = $filter['max'];
                }
                
                $optionArray = array();
                foreach($filter['values'] as $ok => $o)
                {
                    $option['label'] = $o['name'];     
                    $option['count'] = $o['nbr'];
                    if(in_array($filter['type'],array('id_feature','id_attribute_group'))){
                        $option['value'] = $filter['id_key']."_".$ok;
                    }
                    else if(in_array($filter['type'],array('price'))) {
                        $option['label'] = $o;
                        $option['value'] = $ok;
                    }
                    else{
                        $option['value'] = $ok;
                    }
                    $optionArray[] = $option; 
                }
                $f['options'] = $optionArray;
                $filterArrayToReturn[] = $f;   
            }
        }
        return $filterArrayToReturn;
    }
   
    public function convertFilterArray($filters)
    {
        $selectedFilter = array();
        parse_str($filters,$filterArray);
        $filters = explode("&", $filters);
        $filters = array_filter($filters);

        foreach ($filters as $key => $filter) {
            $filterpart = explode("=",$filter);
            $filter_type = $filterpart[0];
            $filter_value = $filterpart[1];
            if($filter_value){                
                $filter_id = explode("_", $filter_value);
                $filter_id = $filter_id[1];
            }

            if(in_array($filter_type, array('layered_price_slider', 'price'))){
                $filter_type = 'layered_price_slider';
                $filter_value = str_replace('-', '_', $filter_value);
                $selectedFilter[$filter_type] = $filter_value;
				$selectedFilter['price'] = explode("_", $filter_value);
                continue;
            }  
            if(in_array($filter_type, array('quantity', 'manufacturer', 'category'))){
                $selectedFilter[$filter_type][] = $filter_value;
                continue;
            }
            if(in_array($filter_type, array('id_feature'))){
                $feature_value = explode("_", $filter_value);
                //$selectedFilter[$filter_value][] = $feature_value[2].'_'.$feature_value[2];
                $selectedFilter[$filter_type][$feature_value[1]] = $feature_value[0].'_'.$feature_value[1];
                continue;
            }
            $selectedFilter[$filter_type][$filter_id] = $filter_value;
        }
        //print_r($selectedFilter);exit;
        return $selectedFilter;
    }
}
