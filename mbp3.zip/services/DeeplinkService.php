<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class DeeplinkService extends BaseService
{
    public function __construct()
    {
        parent::__construct();
        ServiceFactory::factory('Mobicommercehelper')->autoLoginMobileUser();
    }

    public function getDeeplinkData()
    {
        $result = array();
        $found = false;
        $url = Tools::getValue('url');
        $url = str_replace('localhost.com', '192.168.0.137', $url);

        $products = Product::getProducts($this->context->language->id, 1, 5000, 'name', 'ASC');
        foreach($products as $_product) {
            //echo '<pre>';print_r($_product);exit;
            //$id_product = $_product['id_product'];
            $link = new Link();
            if($url == $link->getProductLink($_product))
            {
                $result['response'] = array(
                    'type' => 'product',
                    'id' => $_product['id_product']
                    );
                $found = true;
                break;
            }
        }

        if(!$found)
        {
            $categories = Category::getCategories((int)($this->context->cookie->id_lang), true, false);
            ;
            //echo '<pre>';print_r($categories);exit;
            foreach($categories as $_category) {
                $link = new Link();
                if($url == $link->getCategoryLink($_category['id_category']))
                {
                    $result['response'] = array(
                        'type' => 'category',
                        'id' => $_category['id_category']
                        );
                    $found = true;
                    break;
                }
            }
            //echo '<pre>';print_r($categories);exit;
        }

        if(!$found)
        {
            $cms = CMS::getCMSPages((int)($this->context->cookie->id_lang), true, false);
            ;
            //echo '<pre>';print_r($cms);exit;
            foreach($cms as $_cms) {
                $link = new Link();
                //echo $link->getCMSLink($_cms['id_cms']).'<br />';
                if($url == $link->getCMSLink($_cms['id_cms']))
                {
                    $result['response'] = array(
                        'type' => 'cms',
                        'id' => $_cms['id_cms']
                        );
                    $found = true;
                    break;
                }
            }
            //echo '<pre>';print_r($categories);exit;
        }

        if(!$found)
        {
            $result['response'] = array(
                'type' => 'unknown',
                'id' => false
                );
        }
        //exit;
        return $result;
        //echo '<pre>';print_r($row);exit;
    }
}
