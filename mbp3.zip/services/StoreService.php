<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

if (!defined('IN_MOBICOMMERCE'))
{
    header('HTTP/1.1 404 Not Found');
    die();
}

/**
 * @author hujs
 */
class StoreService extends BaseService
{
    public function __construct()
    {
        parent::__construct();
        ServiceFactory::factory('Mobicommercehelper')->autoLoginMobileUser();
    }

    /**
     * get store info
     * @author hujs
     */
    public function getStoreInfo()
    {
        $info = array();
        $info['currencies'] = $this->getCurrencies();
        $info['languages'] = $this->getLanguages();
        return $info;
    }

    /**
     * get Languages
     * @global type $languages
     * @return string
     * @author hujs
     */
    public function getLanguages()
    {
        $info = array();
        $position = 0;
        $languages = Language::getLanguages();

        foreach ($languages as $language) {
            if($language['active'] == '1') {
                $_info = array(
                    'base_url'   => '',
                    'website_id' => '1',
                    'group_id'   => $language['id_lang'],
                    'store_id'   => $language['id_lang'],
                    'name'       => $language['name'],
                    'sort_order' => $position,
                    'is_active'  => $language['active'],
                    'code'       => $language['iso_code'],
                    'config'     => array(
                        'default_country'            => '',
                        'display_state'              => '',
                        'web_secure_use_in_frontend' => '0',
                        'web_url_use_store'          => '0',
                        'no_image_url'               => '',
                        ),
                    'root_category_id'         => (string)Category::getRootCategory()->id,
                    'group_name'               => $language['name'],
                    'available_currency_codes' => $this->getLanguageCurrencies(),
                );

                if($language['is_rtl']) {
                    $_info['rtl'] = '1';
                }

                $currencies = array();
                $currencyResult = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('
                    SELECT *
                    FROM `'._DB_PREFIX_.'currency`
                    WHERE `deleted` = 0
                    AND `active` = 1');
                if($currencyResult){
                    foreach($currencyResult as $currencyRow){
                        $currency = new Currency($currencyRow['id_currency']);
                        $currencies[] = array(
                            'name'   => $currency->name,
                            'symbol' => $currency->sign,
                            'code'   => $currency->iso_code
                            );
                    }
                }
                $_info['currencies'] = $currencies;

                if($language['id_lang'] == $this->context->cookie->id_lang) {
                    $currency = new Currency($this->context->cookie->id_currency);
                    $_info['currency'] = array(
                        'name'   => $currency->name,
                        'symbol' => $currency->sign,
                        'code'   => $currency->iso_code
                        );
                }

                $info[] = $_info;
            }
        }

        return $info;
    }

    /**
     * Only one can use Depending on the installation options
     * @return type
     * @author hujs
     */
    public function getCountries()
    {
        if (Configuration::get('PS_RESTRICT_DELIVERED_COUNTRIES'))
        {
            $countries = Carrier::getDeliveredCountries($this->context->cookie->id_lang, true, true);
        }
        else
        {
            $countries = Country::getCountries($this->context->cookie->id_lang, true);
        }
        
        foreach ($countries as $country)
        {
            $states = array();
            if($country['contains_states'] == '1')
            {
                foreach($country['states'] as $state)
                {
                    $s = array();
                    $s['region_id'] = $state['id_state'];
                    $s['name']      = $state['name'];
                    $s['code']      = $state['iso_code'];
                    $states[]       = $s;
                }
            }
           
            $shopCountries[] = array(
                'country_id'      => $country['id_country'],
                'name'            => $country['name'],
                'iso2'            => $country['iso_code'],
                'contains_states' => $country['contains_states'],
                'need_zip_code'   => $country['need_zip_code'],
                'states'          => $states
            );
        }
        return $shopCountries;
    }

    /**
     * get zones
     * @return type
     * @author hujs
     */
    public function getZones()
    {
        global $languages_id;

        $shopZones = array();
        $zones = State::getStates($languages_id);
        foreach ($zones as $zone)
        {
            $shopZones[] = array(
                'zone_id'    => $zone['id_state'],
                'country_id' => $zone['id_country'],
                'zone_name'  => $zone['name'],
                'zone_code'  => $zone['iso_code']
            );
        }
        return $shopZones;
    }

    /**
     * get currencies
     * @return type
     * @author hujs
     */
    public function getCurrencies()
    {
        $currencies = Currency::getCurrencies();
        $shopCurencies = array();

        foreach ($currencies as $currency)
        {
            $format = (int) $currency['format'];
            $shopCurencies[] = array(
                'id_currency'           => $currency['id_currency'],
                'currency_code'         => $currency['iso_code'],
                'default'               => _PS_CURRENCY_DEFAULT_ == $currency['id_currency'],
                'currency_symbol'       => $currency['sign'],
                'currency_symbol_right' => $format & 0x01 ? false : true,
                'decimal_symbol'        => $format % 3 == 1 ? '.' : ',',
                'group_symbol'          => ($currency['blank'] ? ' ' : ($format % 3 == 1 ? ',' : '.')),
                'decimal_places'        => $currency['decimals'] * _PS_PRICE_DISPLAY_PRECISION_,
                'description'           => $currency['name'],
            );
        }

        return $shopCurencies;
    }

    /**
     * added by yash
     */
    public function getLanguageCurrencies()
    {
        $currencies = Currency::getCurrencies();
        $shopCurencies = array();

        foreach ($currencies as $currency) {
            $format = (int) $currency['format'];
            $shopCurencies[] = $currency['iso_code'];
        }

        return $shopCurencies;
    }

    public function getOrderStatauses()
    {
        $orderStatuses = array();
        return $orderStatuses;
    }

    /**
     * affect auto login after register
     * @return type
     */
    public function getGeneralInfo()
    {
        return array(
            'cart_type'                    => 'prestashop',
            'cart_version'                 => _PS_VERSION_,
            'plugin_version'               => MOBICOMMERCE_PLUGIN_VERSION,
            'support_mobicommerce_payment' => true,
            'support_promotion'            => _PS_VERSION_ < '1.5',
            'login_by_mail'                => true
        );
    }

    /**
     * get register fields
     * @return type
     * @author hujs
     */
    public function getRegisterFields()
    {
        $registerFields = array(
            array('type' => 'firstname', 'required' => true),
            array('type' => 'lastname', 'required' => true),
            array('type' => 'email', 'required' => true),
            array('type' => 'pwd', 'required' => true),
        );
        return $registerFields;
    }

    /**
     * get address fileds
     * @return array
     * @author hujs
     */
    public function getAddressFields()
    {
        $addressFields = array(
            array('type' => 'firstname', 'required' => true),
            array('type' => 'lastname', 'required' => true),
            array('type' => 'country', 'required' => true),
            array('type' => 'zone', 'required' => false),
            array('type' => 'city', 'required' => true),
            array('type' => 'address1', 'required' => true),
            array('type' => 'address2', 'required' => false),
            array('type' => 'postcode', 'required' => false),
            array('type' => 'telephone', 'required' => false),
        );
        return $addressFields;
    }

    /**
     * Verify the address is complete
     * @param type $address
     * @return boolean
     */
    public function checkAddressIntegrity($address)
    {
        if (empty($address) || !is_array($address))
        {
            return false;
        }

        $addressFields = $this->getAddressFields();
        foreach ($addressFields as $field)
        {
            if ($field['required'] === true)
            {
                $name = $field['type'];
                if ($name == 'country') {
                    if (!isset($address['country_id']) || empty($address['country_id']))
                    {
                        return false;
                    }
                }
                elseif ($name == 'zone')
                {
                    if (isset($address['zone_id']) && intval($address['zone_id']))
                    {
                        continue;
                    }
                    else if (isset($address['state']) && $address['state'])
                    {
                        continue;
                    }
                    else if (isset($address['zone_name']) && $address['zone_name'])
                    {
                        continue;
                    }
                    else
                    {
                        return false;
                    }
                }
                else if($name == 'city')
                {
                    if (isset($address['city_id']) && intval($address['city_id']))
                    {
                        continue;
                    }
                    else if (isset($address['city']) && $address['city'])
                    {
                        continue;
                    }
                    else
                    {
                        return false;
                    }
                }
                elseif(!isset($address[$name]) || empty($address[$name]))
                {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * get category sort options
     * @global type $language
     * @return string
     * @author hujs
     */
    public function getCategorySortOptions()
    {

        $PS_CATALOG_MODE = Configuration::get('PS_CATALOG_MODE');
        $categorySortOptions = array();
        $version = _PS_VERSION_ < '1.4';

        $categorySortOptions[] = array(array(
                'title' => $this->l('--   '),
                'code' => 'name:asc',
                'arrow_type' => ''
                ));

        if (!$PS_CATALOG_MODE)
        {
            $categorySortOptions[] = array(array(
                    'title' => $this->l($version ? 'price: lowest first' : 'Price: lowest first'),
                    'code' => 'price:asc',
                    'arrow_type' => ''
                    ));

            $categorySortOptions[] = array(array(
                    'title' => $this->l($version ? 'price: highest first' : 'Price: highest first'),
                    'code' => 'price:desc',
                    'arrow_type' => ''
                    ));
        }

        $categorySortOptions[] = array(array(
                'title' => $this->l($version ? 'name: A to Z' : 'Product Name: A to Z'),
                'code' => 'name:asc',
                'arrow_type' => ''
                ));

        $categorySortOptions[] = array(array(
                'title' => $this->l($version ? 'name: Z to A' : 'Product Name: Z to A'),
                'code' => 'name:desc',
                'arrow_type' => ''
                ));

        if (!$PS_CATALOG_MODE)
        {
            $categorySortOptions[] = array(array(
                    'title' => $this->l($version ? 'in-stock first' : 'In-Stock first'),
                    'code' => 'in-stock first',
                    'arrow_type' => ''
                    ));
        }

        return $categorySortOptions;
    }

    public function getSearchSortOptions()
    {
        return $this->getCategorySortOptions();
    }
}
