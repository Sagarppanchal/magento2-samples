<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class PushService extends BaseService
{
    public function updateBuild($data)
    {
        $appcode = isset($data['appcode']) ? $data['appcode'] : NULL;
        $appkey  = isset($data['appkey']) ? $data['appkey'] : NULL;
        $licence_key = isset($data['licence_key']) ? $data['licence_key'] : NULL;
        if(!empty($appcode) && !empty($appkey) && !empty($licence_key)){
            if($this->_validateLicenceKey($licence_key)){

                $collection = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('
                    SELECT *
                    FROM `'._DB_PREFIX_.'mobicommerce_applications3`
                    WHERE app_code = "'.$appcode.'"
                        AND app_key = "'.$appkey.'"');

                if($collection){
                    foreach($collection as $_collection){
                        $update = array();
                        if(isset($data['app_mode'])){
                            $update['app_mode'] = $data['app_mode'];
                        }
                        if(isset($data['android_status'])){
                            $update['android_status'] = $data['android_status'];
                        }
                        if(isset($data['android_url'])){
                            $update['android_url'] = $data['android_url'];
                        }
                        if(isset($data['udid'])){
                            $update['udid'] = $data['udid'];
                        }
                        if(isset($data['ios_status'])){
                            $update['ios_status'] = $data['ios_status'];
                        }
                        if(isset($data['ios_url'])){
                            $update['ios_url'] = $data['ios_url'];
                        }
                        if(isset($data['delivery_status'])){
                            $update['delivery_status'] = $data['delivery_status'];
                        }
                        if(isset($data['addon_parameters'])){
                            $update['addon_parameters'] = $data['addon_parameters'];
                        }

                        if(!empty($update)){
                            Db::getInstance()->update('mobicommerce_applications3', $update, 'id = '.$_collection['id'], false, false);
                            //print_r($update);print_r($_collection['id']);exit;
                        }
                    }
                }
                return array(
                    'status'  => true,
                    'message' => count($collection) . " apps updated"
                    );
            }
            else{
                return array(
                    'status'  => false,
                    'message' => "Invalid licence key"
                    );
            }
        }

        return array(
            'status'  => false,
            'message' => "Invalid licence key"
            );
    }

    public function removeapps($data)
    {
        $licence_key = isset($data['licence_key']) ? $data['licence_key'] : NULL;
        if($licence_key && isset($data['appstodelete']) && !empty($data['appstodelete'])){
            if($this->_validateLicenceKey($licence_key)){
                $appcodes = array();
                foreach($data['appstodelete'] as $_app){
                    $appcodes[] = $_app['appcode'];
                }
                $deletedAppsCount = $this->deleteapps($appcodes);
                return array(
                    'status' => true,
                    'message' => $deletedAppsCount . " Apps deleted"
                    );
            }
        }
        return array(
            'status' => false,
            'message' => "No records found"
            );
    }

    public function deleteapps($appcodes = array()) 
    {
        $deleteCount = 0;
        if(!empty($appcodes)){
            $appcodes = array_filter(array_unique(array_map('trim', $appcodes)));
            $deleteCount = count($appcodes);
            if(!empty($appcodes)){
                Db::getInstance()->delete('mobicommerce_applications_settings3', "app_code IN ('".implode("','", $appcodes)."')");
                Db::getInstance()->delete('mobicommerce_widget3', "widget_app_code IN ('".implode("','", $appcodes)."')");
                Db::getInstance()->delete('mobicommerce_devicetokens', "md_appcode IN ('".implode("','", $appcodes)."')");
                Db::getInstance()->delete('mobicommerce_applications3', "app_code IN ('".implode("','", $appcodes)."')");
                
                foreach($appcodes as $_appcode){
                    $dir = _PS_MODULE_DIR_.'mobicommerce/media/mobi_commerce/'.$_appcode;
                    if(file_exists($dir) && is_dir($dir)){
                        $this->rrmdir($dir);
                    }
                }
            }
        }
        return $deleteCount;
    }

    protected function _validateLicenceKey($key=null)
    {
        if(empty($key))
            return false;

        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('
            SELECT *
            FROM `'._DB_PREFIX_.'mobicommerce_licence`
            ORDER BY ml_id DESC LIMIT 1');
        if(!empty($result)){
            $serverLicenceKey = $result[0]['ml_licence_key'];
            if($key == $serverLicenceKey){
                return true;
            }
        }
        return false;
    }

    /* function to remove entire directory with all files in it */
    protected function rrmdir($dir, $include_basedir = true)
    {
        if (is_dir($dir)) {
            $objects = scandir($dir);
            foreach ($objects as $object) {
                if ($object != "." && $object != "..") {
                    if (filetype($dir."/".$object) == "dir") $this->rrmdir($dir."/".$object); else unlink($dir."/".$object);
                } 
            }
            reset($objects); 
            if($include_basedir)
              rmdir($dir); 
        } 
    }
}
