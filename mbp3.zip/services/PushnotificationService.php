<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class PushnotificationService extends BaseService
{
    public function __construct()
    {
        parent::__construct();
        //ServiceFactory::factory('Mobicommercehelper')->autoLoginMobileUser();
    }

    public function saveDeviceToken($data = array())
    {
        $appcode     = isset($data['appcode']) ? $data['appcode'] : NULL;
        $platform    = isset($data['platform']) ? $data['platform'] : NULL;
        $devicetoken = isset($data['devicetoken']) ? $data['devicetoken'] : NULL;

        if(empty($appcode) || empty($platform) || empty($devicetoken)){
            return false;
        }
        else{
            $sql = '
                SELECT *
                FROM `'._DB_PREFIX_.'mobicommerce_devicetokens`
                WHERE `md_appcode` = "'.$appcode.'" and `md_devicetype` = "'.$platform.'" and `md_devicetoken` = "'.$devicetoken.'"
                ';
            $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
            if(!$result){
                $_data = array(
                    'md_appcode'     => $appcode,
                    'md_devicetype'  => $platform,
                    'md_devicetoken' => $devicetoken
                    );
                if($this->context->customer->isLogged()){
                    $_data['md_userid'] = $this->context->cookie->id_customer;
                }

                Db::getInstance()->insert('mobicommerce_devicetokens', $_data, false, false);
            }
            else{
                if($this->context->customer->isLogged()){
                    $userid = $this->context->cookie->id_customer;
                    
                    foreach($result as $_collection){
                        $_data = array(
                            'md_userid' => $userid
                            );
                        Db::getInstance()->update('mobicommerce_devicetokens', $_data, "md_id = '".$_collection['md_id']."'", false);
                    }
                }
            }
            return true;
        }
    }

    public function updateDeviceTokenUser($data)
    {
        $appcode = $data['appcode'];
        $devicetoken = $data['devicetoken'];
        $userid = $data['userid'];
        $sql = '
            SELECT *
            FROM `'._DB_PREFIX_.'mobicommerce_devicetokens`
            WHERE `md_appcode` = "'.$appcode.'" and `md_devicetoken` = "'.$devicetoken.'"
            ';
        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
        if($result){
            foreach($result as $_collection){
                $_data = array(
                    'md_userid' => $userid
                    );
                
                Db::getInstance()->update('mobicommerce_devicetokens', $_data, "md_id = '".$_collection['md_id']."'", false);
            }
        }
    }

    public function updatePreference()
    {
        $appcode = Tools::getValue('appcode');
        $devicetoken = Tools::getValue('devicetoken');

        if($appcode && $devicetoken)
        {
            $id_customer = (int) $this->context->cookie->id_customer;
            if(!$id_customer)
                $id_customer = NULL;

            $sql = '
                SELECT *
                FROM `'._DB_PREFIX_.'mobicommerce_devicetokens`
                WHERE `md_appcode` = "'.$appcode.'" and `md_devicetoken` = "'.$devicetoken.'"
                ';
            $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
            if($result)
            {
                $_data = array(
                    'md_userid'      => $id_customer,
                    'md_store_id'    => $this->context->cookie->id_lang,
                    'md_enable_push' => (int) Tools::getValue('pushpreference'),
                    );
                Db::getInstance()->update('mobicommerce_devicetokens', $_data, "md_id = '".$result[0]['md_id']."'", false);
            }
        }
    }
}
