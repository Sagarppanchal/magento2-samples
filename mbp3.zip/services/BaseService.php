<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

abstract class BaseService
{
    protected $priceDisplay;
    protected $withTax;
    protected $link;
    protected $mod;
    protected $smarty;
    
    public $template_resource;
    public $currentTemplate;

    public $context;
    public $module;

    public function __construct()
    {
        $this->context = context::getContext();
        //echo '<pre>';print_r($this->context);exit;
        $this->module = (object) array('name' => '');
        $this->module->name = 'mobicommerce3';

        global $link, $smarty;
        global $_LANG;

        $this->priceDisplay = Product::getTaxCalculationMethod(isset($this->context->id_customer) ? $this->context->id_customer : null);
        $this->withTax = (int) Configuration::get('PS_TAX');
        $this->smarty = $smarty;

        if ($link)
        {
            $this->link = $link;
        }
        else if ($this->context && isset($this->context->link))
        {
            $this->link = $this->context->link;
        }
        else if (_PS_VERSION_ > '1.5')
        {
            $protocol_link = (Configuration::get('PS_SSL_ENABLED') OR Tools::usingSecureMode()) ? 'https://' : 'http://';
            $useSSL = ((isset($this->ssl) AND $this->ssl AND Configuration::get('PS_SSL_ENABLED')) OR Tools::usingSecureMode()) ? true : false;
            $protocol_content = ($useSSL) ? 'https://' : 'http://';
            $this->link = new Link($protocol_link, $protocol_content);
        }
        else
        {
            $this->link = new Link();
        }
    }

    public function getBaseUrl()
    {
        $base_url = _PS_BASE_URL_.__PS_BASE_URI__;
        if(Configuration::get('PS_SSL_ENABLED') && Configuration::get('PS_SSL_ENABLED_EVERYWHERE'))
        {
            $base_url = str_replace('http://', 'https://', $base_url);
        }

        return $base_url;
    }

    protected function l($string, $extra = null)
    {
        $params = array('mod' => $this->mod, 's' => $string);

        $mod = isset($extra['mod']) ? $extra['mod'] : NULL;
        $this->template_resource = $mod . '.php';
        $this->currentTemplate = $mod;

        if ($extra)
        {
            $params['mod'] = $mod;
            $this->mod = $mod;
            $this->template_resource = _PS_THEME_DIR_.'modules/'.$mod.'/views/templates/hook/'.$extra['modtpl'].'.tpl';
        }

        return smartyTranslate($params, $this);
    }

    protected function t($string, $group)
    {
        if(isset($_LANG[$group.'_'.md5($string)]))
        {
            return $_LANG[$group.'_'.md5($string)];
        }

        return $string;
    }

    protected function getProductImage($name, $ids, $type = null)
    {
        $url = $this->link->getImageLink($name, $ids, $type . PIC_NAME_SUFFIX);
        if (strpos($url, 'http') === false)
        {
            $url = _PS_BASE_URL_ . DIRECTORY_SEPARATOR . $url;
        }

        return $url;
    }
}
