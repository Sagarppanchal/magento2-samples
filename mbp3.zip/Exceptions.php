<?php
/**
 * MobiCommerce
 *
 * @author    MobiCommerce
 * @copyright Copyright (c) MobiCommerce 2017
 * @license   Free license
 */

class InvalidRequestException extends Exception
{

}

class EmptyMethodException extends Exception
{

}
